"""The lazy, Qt-free boundary to nml-tools' profile editor."""
import os
import shutil
from contextlib import contextmanager
from dataclasses import replace
from pathlib import Path
from tempfile import TemporaryDirectory


def read_namelists(folder, schemas_dir, *, lower=True, project=None) -> dict:
    """Read every profile file present in *folder* as ``{group: {key: value}}``.

    Values are typed by the schemas (arrays as lists). Group and key names are lower
    case, since Fortran namelist names are case-insensitive; ``lower=False`` keeps the
    schema's spelling, which initial values for the editor need. ``project`` names
    the nml-tools project profile (``paths.namelist_project``); ``None`` reads every
    file profile, which mixes v6's ``main`` and ``meta``.
    """
    from nml_tools.gui.model import load_profile, load_project, recover_dimensions

    try:
        project = load_project(schemas_dir, folder, project)
        dimensions = recover_dimensions(project)
        values = {}
        for profile in project.profiles:
            for group, fields in load_profile(project, profile, dimensions).items():
                if lower:
                    values[group.lower()] = {key.lower(): value for key, value in fields.items()}
                else:
                    values[group] = fields
    except (OSError, RuntimeError, ValueError) as error:
        raise ValueError(f"Could not read the namelists in {folder}: {error}") from error
    return values


def write_namelists(folder, schemas_dir, values, *, project=None) -> None:
    """Merge ``{file profile: {group: {key: value}}}`` into the saved files in *folder*;
    their other groups and keys stay as they are."""
    from nml_tools.gui.model import (
        load_profile,
        load_project,
        recover_dimensions,
        save_profiles,
    )

    try:
        project = load_project(schemas_dir, folder, project)
        dimensions = recover_dimensions(project)
        updates = []
        for profile in project.profiles:
            if profile.name in values:
                saved = load_profile(project, profile, dimensions)
                groups = {group: {**saved.get(group, {}), **fields} for group, fields in values[profile.name].items()}
                updates.append((profile, groups, dimensions))
        save_profiles(project, updates)
    except (OSError, RuntimeError, ValueError) as error:
        raise ValueError(f"Could not write the namelists in {folder}: {error}") from error


def launch_editor(schemas_dir, output_dir, project, *, namelists=None, initial_values=None,
                  initial_dimensions=None, log=None):
    """Open nml-tools' editor on one project profile (``classic``, ``combine``, ``v5``),
    or on some of its namelists (``{file profile: [namelist, ...]}``, ``[]`` = all).

    Modal inside QGIS; returns when the dialog closes, saved or not.
    """
    from nml_tools import gui

    from .mhm_tools_handler import capture_messages

    request = gui.GuiProjectRequest(
        project,
        output_dir,
        file_profiles=namelists,
        initial_values=initial_values or {},
        initial_dimensions=initial_dimensions or {},
    )
    with capture_messages(log, logger_names=("nml_tools",)), _editor_folder(
        schemas_dir, request, log
    ) as folder:
        config = Path(schemas_dir) / "nml-config.toml"
        return gui.launch_gui(config, [replace(request, output_dir=folder)])


@contextmanager
def _editor_folder(schemas, request, log=None):
    """Resize legacy namelists in scratch; commit only files the editor saves."""
    from nml_tools.gui.model import (
        load_profile,
        load_project,
        overlay_values,
        recover_dimensions,
        save_profiles,
        suggestion,
    )

    output = Path(request.output_dir)
    profiles = (
        request.project_profile
        if request.file_profiles is None
        else {request.project_profile: request.file_profiles}
    )
    initial = request.initial_values
    # nml-tools keys dimensions in lower case; v5 names them `nDomains`.
    dimensions = {key.lower(): size for key, size in request.initial_dimensions.items()}
    project = load_project(schemas, output, profiles)
    previous = recover_dimensions(project)
    shrunk = {key for key, size in dimensions.items() if size < previous.get(key, size)}
    if not shrunk or not any((output / p.default_file).is_file() for p in project.profiles):
        yield output
        return
    sizes = {**project.constants, **previous, **dimensions}
    with TemporaryDirectory(prefix=".namelist-edit-", dir=output) as temporary:
        folder = Path(temporary)
        for entry in output.iterdir():
            if entry == folder or entry.name.startswith(".namelist-edit-"):
                continue
            if entry.is_file() and entry.suffix == ".nml":
                shutil.copy2(entry, folder / entry.name)
            elif entry.is_dir():
                (folder / entry.name).symlink_to(entry.resolve(), target_is_directory=True)
        staged = load_project(schemas, folder, profiles)
        updates = []
        for profile in project.profiles:
            values = load_profile(project, profile, previous)
            for page in profile.pages:
                fields = values.get(page.name, {})
                for name, schema in page.schema.get("properties", {}).items():
                    shape = schema.get("x-fortran-shape", [])
                    shape = shape if isinstance(shape, list) else [shape]
                    if name in fields and shrunk.intersection(str(t).lower() for t in shape):
                        # A merged domain has no single predecessor: do not pick
                        # one old catchment's settings arbitrarily.
                        fields[name] = suggestion(schema, sizes)
            values = overlay_values(values, initial.get(profile.key, {}))
            updates.append((staged.profile(profile.name), values, {**previous, **dimensions}))
        save_profiles(staged, updates)
        before = {p: p.stat().st_mtime_ns for p in folder.glob("*.nml")}
        if log:
            log("Legacy domain arrays are reset in the editor preview; originals are preserved until Save.")
        yield folder
        for path in folder.glob("*.nml"):
            if before.get(path) == path.stat().st_mtime_ns:
                continue
            os.replace(path, output / path.name)


__all__ = ["launch_editor", "read_namelists"]

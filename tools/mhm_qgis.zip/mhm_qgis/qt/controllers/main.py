"""Input sources, outlets, domain definition and result display on the main form."""
from __future__ import annotations

import os
import traceback
from pathlib import Path

from qgis.PyQt.QtCore import Qt
from qgis.PyQt.QtWidgets import (
    QButtonGroup,
    QDialog,
    QMessageBox,
    QRadioButton,
)

from ...core.handlers.store.morphology import resolve_display_output
from ...core.morphology.hydrology.outlets import StationIdError, outlet_ids_from_layer
from ..dialogs.file_picker import open_file
from ..dialogs.input_selection import (
    INPUT_EXTENSIONS,
    InputComboAdapter,
    _populate_layer_combo,
    _restore_raster_details,
    is_point_layer,
    loaded_qgis_items,
    raster_details,
    raster_draft,
)
from ..reporting import error_detail
from ..workflows import hydrology
from .workflow_state import invalidate_meteo

# --- Input sources --------------------------------------------------------

def configure_input_adapters(dialog):
    """Wrap the DEM and pour-point combos in the layer-combo interface."""
    dialog._input_adapters = {
        "dem": InputComboAdapter(dialog.comboBox_demInput, "dem", dialog),
        "pour_points": InputComboAdapter(dialog.comboBox_pourPointInput, "pour_points", dialog),
    }


def input_layer_widgets(dialog):
    """Return persistent layer input widgets and their state keys."""
    return tuple(dialog._input_adapters.items())


def refresh_input_sources(dialog):
    """Populate input boxes from the layers loaded in QGIS."""
    for kind, adapter in dialog._input_adapters.items():
        combo = adapter.combo_box
        previous = combo.currentData()
        combo.blockSignals(True)
        combo.clear()
        for item in loaded_qgis_items(kind):
            adapter.addItem(item.label, item.data)
        index = _matching_input_index(combo, previous)
        if (
            index < 0
            and isinstance(previous, dict)
            and previous.get("origin") == "file"
            and previous.get("manual")
            and os.path.isfile(previous.get("path", "").split("|", 1)[0])  # a GeoPackage path names its layer
        ):
            combo.addItem(previous.get("label") or previous["path"], previous)
            index = combo.count() - 1
        combo.setCurrentIndex(index)
        combo.blockSignals(False)
        if isinstance(previous, dict) and index < 0:
            adapter.layerChanged.emit(adapter.currentLayer())
    for adapter in getattr(dialog, "_lookup_adapters", {}).values():  # the categorical layers keep their choice
        combo, draft = adapter.combo_box, raster_draft(adapter.combo_box)
        browsed = (combo.currentData() or {}).get("origin") == "file"
        combo.blockSignals(True)
        _populate_layer_combo(adapter, dialog.setup_folder, adapter.kind, draft["input_path"])
        if browsed:
            _restore_raster_details(combo, draft)
        combo.blockSignals(False)


def _matching_input_index(combo, previous):
    if not isinstance(previous, dict):
        return -1
    origin = previous.get("origin")
    identity = (
        previous.get("path")
        if origin == "file"
        else previous.get("layer_id") or previous.get("source")
    )
    for index in range(combo.count()):
        data = combo.itemData(index)
        if not isinstance(data, dict) or data.get("origin") != origin:
            continue
        candidate = (
            data.get("path")
            if origin == "file"
            else data.get("layer_id") or data.get("source")
        )
        if candidate == identity or (origin == "qgis" and previous.get("source")
                                     and data.get("source") == previous["source"]):
            return index
    return -1


def browse_input_file(dialog, kind):
    """Add a manually selected file to one input box."""
    extensions = sorted(INPUT_EXTENSIONS[kind])
    path, _ = open_file(
        dialog,
        f"Select {kind.replace('_', ' ').title()} Input",
        f"Supported files ({' '.join(f'*{suffix}' for suffix in extensions)});;All files (*)",
    )
    if not path:
        return
    path = os.path.abspath(path)
    if os.path.splitext(path)[1].lower() not in INPUT_EXTENSIONS[kind]:
        QMessageBox.warning(
            dialog,
            "Unsupported Input",
            f"Select a {kind.replace('_', ' ')} file with one of these "
            f"extensions: {', '.join(extensions)}.",
        )
        return
    details = raster_details(dialog, path)
    if details is None:
        return
    if kind == "pour_points":
        from ...qgis_bridge import layers

        if not is_point_layer(layers.open_layer(details.input_path, "gauges", is_raster=False)):
            QMessageBox.warning(dialog, "Unsupported Input", "Gauges need a point layer.")
            return
        path = details.input_path  # a GeoPackage's chosen layer
    add_file_input(dialog, kind, path, manual=True,
                   variable=details.variable, source_crs=details.source_crs)


def add_file_input(dialog, kind, path, *, manual, variable="", source_crs=""):
    """Select `path` in one input box, adding a file item when it is new."""
    combo = dialog._input_adapters[kind].combo_box
    for index in range(combo.count()):
        data = combo.itemData(index)
        if isinstance(data, dict) and data.get("path") == path:
            combo.setItemData(index, {**data, "variable": variable, "source_crs": source_crs})
            if combo.currentIndex() == index:
                combo.currentIndexChanged.emit(index)  # reopened, maybe with another CRS
            else:
                combo.setCurrentIndex(index)
            return
    label = str(path)
    combo.addItem(label, {
        "origin": "file", "kind": kind, "path": path, "label": label,
        "manual": manual, "variable": variable, "source_crs": source_crs,
    })
    combo.setCurrentIndex(combo.count() - 1)


def selected_input_file_paths(dialog):
    """Return local files already selected elsewhere in the plugin."""
    sources = [
        str(adapter.source_path() or "").split("|", 1)[0]
        for adapter in dialog._input_adapters.values()
    ]
    for configs in (
        dialog._categorical_lookup_configs,
        dialog._categorical_ready_configs,
        dialog._lai_input_config,
        {key: value.as_dict() if hasattr(value, "as_dict") else value
         for key, value in dialog._advanced_inputs.items()},
    ):
        sources.extend(_nested_strings(configs))
    sources.append(dialog._land_cover_ready_source)
    return {
        os.path.normcase(os.path.abspath(path))
        for path in sources
        if path and os.path.isfile(path)
    }


def _nested_strings(value):
    if isinstance(value, dict):
        for item in value.values():
            yield from _nested_strings(item)
    elif isinstance(value, (list, tuple)):
        for item in value:
            yield from _nested_strings(item)
    elif isinstance(value, str):
        yield value


def handle_model_input_changed(dialog, value=None):
    """Persist model inputs and invalidate a previously completed setup."""
    if dialog._loading_input_state:
        return
    from ...core.handlers.state import processing

    dialog.save_input_state()
    invalidate_meteo(dialog)
    if dialog.setup_folder:
        processing.mark_workflow(dialog.setup_folder, "execute_all_morphology", "pending")


# --- Outlets and domain definition ----------------------------------------

def populate_pour_point_outlet_fields(dialog, layer=None, preferred=None):
    """Populate the outlet ID field selector from the pour-point layer."""
    combo = dialog.comboBox_pourPointOutletID
    previous = str(preferred or combo.currentText() or "").strip()
    if layer is None:
        layer = dialog.input_combo("pour_points").currentLayer()
    if layer is None and dialog._preserve_missing_layer_state:
        return  # QGIS is removing its layers: the saved field stays
    names = list(layer.fields().names()) if layer is not None and layer.isValid() else []

    combo.blockSignals(True)
    combo.clear()
    combo.addItem("")
    combo.addItems(names)
    index = combo.findText(previous) if previous else -1
    for wanted in (previous, "station_id"):
        if index >= 0:
            break
        index = next(
            (candidate for candidate in range(1, combo.count())
             if combo.itemText(candidate).casefold() == wanted.casefold()),
            -1,
        )
    combo.setCurrentIndex(index if index >= 0 else 0)
    combo.blockSignals(False)


def selected_outlet_id_field(dialog):
    return dialog.comboBox_pourPointOutletID.currentText().strip()


def selected_outlet_ids(dialog):
    """Return validated unique outlet IDs from the selected field."""
    field_name = selected_outlet_id_field(dialog)
    if not field_name:
        raise StationIdError("Select the pour-point outlet ID field.")
    return outlet_ids_from_layer(dialog.input_combo("pour_points").currentLayer(), field_name)


def update_gauged_outlet_count(dialog, layer=None):
    """Show configured gauges, falling back to the layer feature count."""
    from ...core.morphology.hydrology.outlets import (
        configured_gauged_outlet_ids,
        feature_count_text,
    )

    if layer is None:
        layer = dialog.input_combo("pour_points").currentLayer()
    configured_ids = configured_gauged_outlet_ids(dialog.setup_folder)
    count = (
        str(len(configured_ids))
        if configured_ids is not None
        else feature_count_text(layer)
    )
    dialog.label_numberOfGaugedOutletsValue.setText(count)
    refresh_observation_stations(dialog)
    return count


DOMAIN_TYPES = ("Entire DEM extent as Domain", "Delineate Domain")  # saved for the radios, in order


def radios(dialog, name, chosen, modes=()):
    """Group the Designer radios `radioButton_<name>*`, wherever laid out; a click calls `chosen(text)`.
    With `modes`, the radios in order stand for those saved texts, so their labels may differ."""
    group = QButtonGroup(dialog)
    for radio in dialog.findChildren(QRadioButton):
        if radio.objectName().startswith(f"radioButton_{name}"):
            group.addButton(radio)
    if modes:
        for radio, mode in zip(group.buttons(), modes, strict=True):
            radio.setProperty("mode", mode)
    group.buttonClicked.connect(lambda button: chosen(mode_of(button)))
    setattr(dialog, f"buttonGroup_{name}", group)


def mode_of(button) -> str:
    """The saved text a radio stands for: its mode, else its label."""
    return button.property("mode") or button.text()


def check(dialog, name, text):
    """Check the radio for `text` (ignoring case, `_` as a space); none for another text."""
    group = getattr(dialog, f"buttonGroup_{name}")
    group.setExclusive(False)
    for button in group.buttons():
        button.setChecked(mode_of(button).lower() == str(text or "").lower().replace("_", " "))
    group.setExclusive(True)


def embed(dialog, name, child):
    """Show the dialog `child` (or nothing) in `widget_<name>Form`.

    The form it replaces is closed silently: its own close handling runs, but not the
    `rejected`/`finished` slots that would show a form again. False when that form refuses to
    close (the Domain Delineator while it saves): it stays, and `child` is dropped.
    """
    layout = getattr(dialog, f"verticalLayout_{name}Form")
    while layout.count():
        old = layout.takeAt(0).widget()
        if old is not None:
            old.blockSignals(True)
            if not old.close():
                old.blockSignals(False)
                layout.insertWidget(0, old)
                if child is not None:
                    child.deleteLater()
                return False
            old.deleteLater()
    if child is not None:
        child.setWindowFlags(Qt.WindowType.Widget)
        child.setMinimumSize(0, 0)  # a window's minimum: embedded, its layout's own minimum decides
        layout.addWidget(child)
        child.show()
    return True


def form_on(dialog, name):
    """The form embedded on page `name`, or None."""
    layout = getattr(dialog, f"verticalLayout_{name}Form")
    return layout.itemAt(0).widget() if layout.count() else None


def draftable(dialog, form, key):
    """Let `form` keep unsaved values as the draft `key`. A form built from a draft keeps it
    until a successful Set drops it; one built clean records a draft only once its values change."""
    form.draft_key = key
    form.draft_base = None if key in dialog._drafts else form.draft()
    form.accepted.connect(lambda: dialog._drafts.__setitem__(key, form.draft()))  # a failed Set keeps them


def stash(dialog, name):
    """Record the unsaved values of the form on page `name` (see `draftable`)."""
    form = form_on(dialog, name)
    key = getattr(form, "draft_key", None)
    if key is None:
        return
    values = form.draft()
    if values == form.draft_base:
        dialog._drafts.pop(key, None)
    else:
        dialog._drafts[key] = values


def handle_domain_definition_type(dialog, text):
    """Embed the chosen domain definition: the delineator, or the DEM-extent gauge assignment."""
    if text == DOMAIN_TYPES[1]:
        if open_domain_delineator(dialog):
            dialog._domain_definition_mode = text
            dialog.save_input_state()
        else:
            check(dialog, "domainDefinition", dialog._domain_definition_mode)
        return
    delineator = dialog.findChild(QDialog, "DomainDelineatorDialog")
    if delineator is not None and delineator._domain_jobs_busy():
        check(dialog, "domainDefinition", DOMAIN_TYPES[1])
        QMessageBox.information(dialog, "Domain Definition", "Wait for the active Domain Delineator task to finish.")
        return
    if not open_domain_assignment(dialog):
        check(dialog, "domainDefinition", dialog._domain_definition_mode)


def show_domain_definition(dialog):
    """The row's page: the checked type's form, unless one is already shown."""
    if dialog.verticalLayout_domainDefinitionForm.count():
        return
    if dialog.radioButton_domainDefinitionDelineator.isChecked():
        open_domain_delineator(dialog)
    elif dialog.radioButton_domainDefinitionDemExtent.isChecked():
        open_domain_assignment(dialog)


def _selected_outlets(dialog, title):
    """Return the outlet IDs, or None after telling the user what is missing."""
    if not dialog.setup_folder:
        QMessageBox.warning(dialog, title, "Select a project folder first.")
        return None
    try:
        outlet_ids = selected_outlet_ids(dialog)
    except StationIdError as error:
        QMessageBox.warning(dialog, title, str(error))
        return None
    if not outlet_ids:
        QMessageBox.warning(
            dialog, title, "The pour-point layer does not contain any outlet features."
        )
        return None
    return outlet_ids


def open_domain_assignment(dialog):
    """Embed the gauge assignment for the DEM-extent domain; Set applies it. False without outlets."""
    outlet_ids = _selected_outlets(dialog, "Domain Assignment")
    if outlet_ids is None:
        return False
    try:
        from ...core.handlers.state.domain_state import DOMAIN_MODE_DEM_EXTENT
        from ...qgis_bridge.layers.domain import DomainWorkflow
        from ..dialogs.discharge_assignment import DischargeTableAssignmentDialog

        workflow = DomainWorkflow(
            dialog.setup_folder,
            dialog.input_combo("pour_points").currentLayer(),
            selected_outlet_id_field(dialog),
            outlet_ids,
            prepare=lambda: hydrology.prepare_filled_dem(dialog),
            log=dialog.log_message,
        )
        state = workflow.load_synced_state(DOMAIN_MODE_DEM_EXTENT, True)
        assignment = DischargeTableAssignmentDialog(
            outlet_ids, dialog, initial_records=state.get("outlets", {}),
        )
    except Exception as error:
        _assignment_failed(dialog, error)
        return False
    assignment.accepted.connect(lambda: _assign(dialog, workflow, assignment))
    embed(dialog, "domainDefinition", assignment)
    from .. import project_tree

    project_tree.indicate(dialog, "domain_definition", assignment.label_setStatusDomainDefinitionDemExtent)
    return True


def _assign(dialog, workflow, assignment):
    from ...core.handlers.state.nml_settings import sync_domain_settings

    try:
        workflow.apply_dem_extent(assignment.selected_assignments())
        sync_domain_settings(dialog.setup_folder)
    except Exception as error:
        _assignment_failed(dialog, error)
        return
    dialog._domain_definition_mode = DOMAIN_TYPES[0]
    dialog.save_input_state()
    update_gauged_outlet_count(dialog)
    invalidate_meteo(dialog)
    open_domain_assignment(dialog)


def _assignment_failed(dialog, error):
    dialog.log_message(f"ERROR: Domain assignment failed: {error}")
    dialog.log_message(f"Traceback: {traceback.format_exc()}")
    QMessageBox.critical(dialog, "Domain Assignment", str(error))


def show_gauge_type(dialog):
    """The Point or Raster page of the gauge input."""
    dialog.stackedWidget_gaugeInput.setCurrentIndex(int(dialog.radioButton_gaugesRasterInput.isChecked()))


def _gauges_from_raster(dialog):
    """The gauge-ID raster as the pour-point input: one point per ID, field `id`."""
    from ...core.handlers.file.netcdf.raster import source
    from ...core.handlers.store.paths import temp_morphology_folder
    from ...core.morphology.hydrology.outlets import points_from_gauge_raster
    from ..dialogs.input_selection import (
        _combo_path,
        _combo_raster_details,
        _ensure_raster_details,
    )

    combo = dialog.comboBox_gaugeRaterInput
    path = _combo_path(combo)
    if not path or not os.path.isfile(path):
        QMessageBox.warning(dialog, "Gauges", "Browse to a gauge-ID raster first.")
        return False
    if not _ensure_raster_details(dialog, combo):
        return False
    details = _combo_raster_details(combo)
    try:
        output = points_from_gauge_raster(
            source(path, details.get("variable", "")),
            Path(temp_morphology_folder(dialog.setup_folder)) / "gauges_from_raster.gpkg",
            details.get("source_crs", ""))
    except (OSError, ValueError, RuntimeError) as error:
        QMessageBox.warning(dialog, "Gauges", str(error))
        return False
    add_file_input(dialog, "pour_points", f"{output}|layername=gauges", manual=True)
    dialog.comboBox_pourPointOutletID.setCurrentText("id")
    return True


def set_gauges(dialog):
    """Gauges' Set: build the drainage network and flow accumulation the Domain Delineator opens on."""
    if dialog.radioButton_gaugesRasterInput.isChecked() and (
            not dialog.setup_folder or not _gauges_from_raster(dialog)):
        return
    if _selected_outlets(dialog, "Gauges") is None:
        return

    box = QMessageBox(QMessageBox.Icon.Information, "Set Gauges", "Preparing the channel network and flow "
                      "accumulation…\nThis closes when they are ready.", parent=dialog)
    box.setModal(False)

    def ready(_context):
        box.close()
        dialog.log_message("The drainage network and flow accumulation are ready.")
        dialog.save_input_state()
        from .. import project_tree

        project_tree.refresh(dialog)

    def failed(message):
        box.close()
        _domain_delineator_preflight_failed(dialog, message)

    prepared = hydrology.domain_prepared(dialog)
    if hydrology.start_domain_preflight(dialog, (dialog.page_gauges,), ready, failed):
        dialog.log_message("Creating the drainage network and flow accumulation…")
        if not prepared:
            box.show()


def open_domain_delineator(dialog):
    """Open the delineation dialog on what Set Gauges prepared; False if not started."""
    outlet_ids = _selected_outlets(dialog, "Domain Delineator")
    if outlet_ids is None:
        return False
    if not hydrology.domain_prepared(dialog):
        QMessageBox.information(dialog, "Domain Delineator", "Press Set on the Gauges page first: "
                                "it creates the drainage network and flow accumulation.")
        return False
    layer = dialog.input_combo("pour_points").currentLayer()
    field = selected_outlet_id_field(dialog)
    started = hydrology.start_domain_preflight(
        dialog,
        (dialog.page_domainDefinition,),
        lambda context: _show_domain_delineator(dialog, context, layer, field, outlet_ids),
        lambda message: _domain_delineator_preflight_failed(dialog, message),
    )
    if not started:
        QMessageBox.information(
            dialog, "Domain Delineator", "Domain Delineator preparation is already running."
        )
    return bool(started)


def _show_domain_delineator(dialog, context, pour_points_layer, outlet_id_field, outlet_ids):
    """The delineator below the Domain Definition radios, until another type replaces it."""
    from ..dialogs.domain_delineator import DomainDelineatorDialog

    if not dialog.radioButton_domainDefinitionDelineator.isChecked():
        return  # switched away while it was being prepared
    try:
        delineator = DomainDelineatorDialog(
            dialog, pour_points_layer, outlet_id_field, outlet_ids, prepared_context=context,
        )
    except Exception as error:
        dialog.log_message(f"ERROR: Domain delineator failed: {error}")
        dialog.log_message(f"Traceback: {traceback.format_exc()}")
        QMessageBox.critical(dialog, "Domain Delineator", str(error))
        return
    embed(dialog, "domainDefinition", delineator)
    from .. import project_tree

    project_tree.indicate(dialog, "domain_definition", delineator.label_setStatusDomainDefinition)


def _domain_delineator_preflight_failed(dialog, message):
    dialog.log_message(f"ERROR: Drainage network preparation failed: {message}")
    QMessageBox.critical(dialog, "Gauges", error_detail(message))


# --- Result display -------------------------------------------------------

def display_morphology(dialog, key) -> str:
    """Show the prepared output for a `resolve_display_output` key: its layer name, "" when there is none."""
    output = resolve_display_output(dialog.setup_folder, key) if dialog.setup_folder else None
    if output is None:
        return ""
    from ...qgis_bridge.display.morphology import show_output

    show_output(dialog, output)
    return output.name


def refresh_observation_stations(dialog):
    from ...core.post.graph import stations

    combo = dialog.comboBox_displayOutletStation
    selected = combo.currentText()
    blocked = combo.blockSignals(True)
    try:
        combo.clear()
        for station in stations(dialog.setup_folder):
            combo.addItem(station["id"], station["path"])
        index = combo.findText(selected)
        if index >= 0:
            combo.setCurrentIndex(index)
    finally:
        combo.blockSignals(blocked)
    combo.setEnabled(combo.count() > 0)
    dialog.pushButton_observationDisplay_discharge.setToolTip(
        "Plot discharge observations for the selected station"
    )
    dialog.pushButton_observationDisplay_discharge.setEnabled(combo.count() > 0)


def display_observation_discharge(dialog):
    from ...core.post.graph import discharge_series

    combo = dialog.comboBox_displayOutletStation
    if not combo.currentData():
        QMessageBox.warning(dialog, "Discharge", "Save a gauged outlet in the domain delineator first.")
        return
    try:
        timestamps, values = discharge_series(combo.currentData())
        from ..dialogs.discharge_plot import DischargePlotDialog

        if dialog._discharge_plot is None:
            dialog._discharge_plot = DischargePlotDialog(dialog)
        dialog._discharge_plot.show_series(combo.currentText(), timestamps, values)
    except (OSError, ValueError, ImportError) as error:
        dialog.log_message(f"ERROR: Discharge plot failed: {error}")
        QMessageBox.warning(dialog, "Discharge", str(error))


def on_page_changed(dialog, page):
    """Refresh results when their page is shown."""
    dialog.log_message(f"Switched to '{dialog.tabWidget_steps.tabText(0)}'.")
    # mHM reports nothing when it finishes, so the Outputs page re-reads the
    # runs each time it is shown.
    if page is dialog.page_outputs:
        from . import post_context

        post_context.populate(dialog)

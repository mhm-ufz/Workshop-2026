"""Combine prepared single-domain setups into one multi-domain mHM run (Qt-free).

Domains are read, never written. v6 lists them in `combine.nml` (`config_domain`);
mHM then reads each domain's own `mhm.nml`, but takes `config_processes`,
`parameters.nml` and `outputs.nml` from the multi folder. v5.13 has one `mhm.nml`
whose per-domain arrays are filled from each domain's saved namelist, with input
paths rebased to point into the domain and outputs kept in the multi folder.
"""
from __future__ import annotations

import os
import shutil
from functools import cache
from pathlib import Path

import yaml

from .handlers.file import json as jsonio
from .handlers.store import layout
from .handlers.store.paths import (
    MULTI_FOLDER_NAME,
    domain_folder,
    namelist_project,
    schemas_folder,
    version_key,
)

try:
    import tomllib
except ModuleNotFoundError:  # Python 3.10
    import tomli as tomllib

SECTION = "multi_domain"
SHARED_FILES = {"v6": ("parameters.nml", "outputs.nml"),
                "v5.13": ("mhm_parameter.nml", "mhm_outputs.nml", "mrm_outputs.nml")}
# v5.13 per-domain outputs stay in the multi folder; only inputs point into domains.
_OUTPUT_PATHS = {"dir_Out": "output/{name}/", "mhm_file_RestartOut": "restart/{name}/mhm_restart_out.nc",
                 "mrm_file_RestartOut": "restart/{name}/mrm_restart_out.nc", "dirConfigOut": "output/"}
_NOT_REBASED = {"LCoverfName"}  # file names inside dir_LCover(i), not paths from the run folder


def multi_folder(project_directory, name) -> Path:
    return domain_folder(project_directory, name, MULTI_FOLDER_NAME)


def multi_folders(project_directory) -> tuple[Path, ...]:
    return layout.domain_folders(project_directory, MULTI_FOLDER_NAME)


def is_multi(folder) -> bool:
    return jsonio.read_mapping(layout.input_state_path(folder)).get("setup") == "multi"


def store_paths(root, paths) -> list[str]:
    """Domain paths as saved: relative to the multi folder, absolute across drives."""
    stored = []
    for path in paths:
        try:
            stored.append(Path(os.path.relpath(Path(path).resolve(), Path(root).resolve())).as_posix())
        except ValueError:
            stored.append(str(Path(path).resolve()))
    return stored


def resolve(root, stored) -> list[Path]:
    return [(Path(root) / path).resolve() for path in stored]


def _read(folder, version, lower=False) -> dict:
    from ..externals.nml_tools_handler import read_namelists

    return read_namelists(folder, schemas_folder(version), lower=lower, project=namelist_project(version))


@cache
def _registry(version) -> tuple[dict, dict]:
    """(group -> schema properties, profile -> its namelist names) from nml-config.toml."""
    root = schemas_folder(version)
    config = tomllib.loads((root / "nml-config.toml").read_text(encoding="utf-8"))
    properties = {
        item["name"]: yaml.safe_load((root / item["schema"]).read_text(encoding="utf-8")).get("properties", {})
        for item in config.get("namelists", [])
    }
    profiles = {item["name"]: item.get("namelists", []) for item in config.get("file_profiles", [])}
    return properties, profiles


def validate_domain(path, version, root, existing=()) -> str | None:  # noqa: PLR0911
    """Why `path` cannot join this multi setup, or None."""
    path = Path(path).resolve()
    if path == Path(root).resolve():
        return "That is this multi-domain setup itself."
    if not Path(layout.input_state_path(path)).is_file():
        return f"{path} is not a domain setup (it has no .temp/mhm_qgis_input_state.json)."
    if is_multi(path):
        return f"{path.name} is a multi-domain setup; add its domains instead."
    if any(Path(other).resolve() == path for other in existing):
        return f"{path.name} is already in the list."
    domain_version = layout.project_version(path)
    if domain_version != version_key(version):
        return f"{path.name} uses mHM {domain_version}; this setup uses {version_key(version)}."
    if not (path / "mhm.nml").is_file():
        return f"{path.name} has no saved mhm.nml: open it and save its namelists first."
    return None


def _common_table(path, name) -> str | None:
    file = Path(layout.morph_folder(path)) / name
    return file.read_text(encoding="utf-8").strip() if file.is_file() else None


# mHM 5.13 reads these from dirCommonFiles: one copy serves every domain
SOIL_TABLES = ("soil_classdefinition_iFlag_soilDB_1.txt", "soil_classdefinition.txt")
COMMON_TABLES = ("geology_classdefinition.txt", "LAI_classdefinition.txt")
PROCESSES = ("interception", "snow", "soil moisture", "direct runoff", "PET", "interflow", "percolation",
             "routing", "baseflow", "cosmic-ray neutrons", "river-temperature routing")


def _first(value):
    return value[0] if isinstance(value, list) and value else value


def _folders(path, value) -> tuple[Path, Path, Path]:
    """The morph, land-cover and common-files folders one domain's mhm.nml reads."""
    general = value.get("directories_general", {})
    return tuple(Path(path, _first(general.get(key)) or "data/static/morph/")
                 for key in ("dir_Morpho", "dir_LCover", "dirCommonFiles"))


def _soil_table(path, value) -> Path | None:
    common = _folders(path, value)[2]
    return next((common / name for name in SOIL_TABLES if (common / name).is_file()), None)


def _combination(paths, values) -> dict:
    """What a v5.13 combined run needs beyond the domains' own files; {} when nothing.

    `offsets`: each domain's soil classes moved up past the domains before it (one soil table
    serves all domains, but each numbers its classes 1..N). `lcover`: the shared land-cover
    periods, the first from the earliest domain and the last to the latest (each domain fits them
    to its own run). `own`: the domains that need a folder of their own in the multi folder.
    """
    plan, names = {}, [Path(path).name for path in paths]
    tables = [_soil_table(path, value) for path, value in zip(paths, values, strict=True)]
    if all(tables) and len({table.read_bytes() for table in tables}) > 1:
        counts = [int(table.read_text(encoding="utf-8").split()[1]) for table in tables]
        plan.update(offsets=[sum(counts[:index]) for index in range(len(counts))], tables=tables)
    scenes = [value.get("LCover", {}) for value in values]
    starts, ends, files = ([scene.get(key) or [] for scene in scenes]
                           for key in ("LCoverYearStart", "LCoverYearEnd", "LCoverfName"))
    if any((start, end, file) != (starts[0], ends[0], files[0])
           for start, end, file in zip(starts, ends, files, strict=True)):
        if len({len(file) for file in files}) > 1 or any(
                start[1:] != starts[0][1:] or end[:-1] != ends[0][:-1] for start, end in zip(starts, ends, strict=True)):
            raise ValueError("Land-cover periods differ: " + "; ".join(
                f"{name} " + ", ".join(f"{a}-{b}" for a, b in zip(start, end, strict=True))
                for name, start, end in zip(names, starts, ends, strict=True))
                + ". Give the domains time periods within the same land-cover scenes.")
        start = [min(start[0] for start in starts), *starts[0][1:]]
        end = [*ends[0][:-1], max(end[-1] for end in ends)]
        plan["lcover"] = {"nLCoverScene": len(start), "LCoverYearStart": start, "LCoverYearEnd": end,
                          "LCoverfName": [f"lc_{a}_{b}.asc" for a, b in zip(start, end, strict=True)]}
    offsets = plan.get("offsets", [0] * len(paths))
    plan["own"] = [index for index, file in enumerate(files)
                   if offsets[index] or ("lcover" in plan and file != plan["lcover"]["LCoverfName"])]
    return plan if plan["own"] or "offsets" in plan or "lcover" in plan else {}


def _link(source, target) -> None:
    try:
        os.symlink(source, target)
    except OSError:  # Windows without the symlink privilege
        shutil.copy2(source, target)


def _shift_classes(source, target, offset) -> None:
    """An ASCII class grid with every class moved up by `offset`, no data kept."""
    import numpy as np

    with open(source, encoding="utf-8") as stream:
        header = [next(stream) for _ in range(6)]
        classes = np.array(stream.read().split(), dtype=float).astype(np.int64)
    field = {line.split()[0].lower(): line.split()[1] for line in header}
    nodata = int(float(field["nodata_value"]))
    classes = np.where(classes == nodata, nodata, classes + offset).reshape(-1, int(field["ncols"]))
    with open(target, "w", encoding="utf-8") as stream:
        stream.writelines(header)
        np.savetxt(stream, classes, fmt="%d")


def combined_inputs(root) -> list[str]:
    """Write what `_combination` asks for into the multi folder (`common/`, `morph/<domain>/`),
    skipping a domain whose folder is still current; returns what it did, for the log."""
    from .handlers.state.nml_settings import load_settings

    root = Path(root)
    paths = resolve(root, load_settings(root).get(SECTION, {}).get("domains", []))
    values = [_read(path, "5.13") for path in paths]
    plan, notes = _combination(paths, values), []
    if "offsets" in plan:
        common = root / "common"
        common.mkdir(exist_ok=True)
        lines = [table.read_text(encoding="utf-8").splitlines() for table in plan["tables"]]
        rows = [f"{int(row.split(None, 1)[0]) + offset}\t{row.split(None, 1)[1]}"
                for offset, table in zip(plan["offsets"], lines, strict=True) for row in table[2:] if row.strip()]
        total = sum(int(table[0].split()[1]) for table in lines)
        (common / plan["tables"][0].name).write_text(
            "\n".join([f"nSoil_Types {total}", lines[0][1], *rows]) + "\n", encoding="utf-8")
        for name in COMMON_TABLES:
            source = _folders(paths[0], values[0])[2] / name
            if source.is_file():
                shutil.copy2(source, common / name)
    for index in plan.get("own", []):
        path, value = paths[index], values[index]
        morph, lcover, _common = _folders(path, value)
        offset = plan.get("offsets", [0] * len(paths))[index]
        scenes = list(zip(value.get("LCover", {}).get("LCoverfName") or [], plan["lcover"]["LCoverfName"],
                          strict=True)) if "lcover" in plan else []
        sources = [file for file in morph.iterdir() if file.is_file()] + [lcover / old for old, _new in scenes]
        stamp = repr((offset, scenes, max(file.stat().st_mtime_ns for file in sources)))
        target = root / "morph" / Path(path).name
        if (target / ".combined").is_file() and (target / ".combined").read_text(encoding="utf-8") == stamp:
            continue
        if target.exists():
            shutil.rmtree(target)
        target.mkdir(parents=True)
        for file in morph.iterdir():
            if not file.is_file():
                continue
            if offset and file.name.startswith("soil_class") and file.suffix == ".asc":
                _shift_classes(file, target / file.name, offset)
            else:
                _link(file, target / file.name)
        for old, new in scenes:
            (target / new).unlink(missing_ok=True)
            _link(lcover / old, target / new)
        (target / ".combined").write_text(stamp, encoding="utf-8")
        notes.append(f"{Path(path).name}: " + ", ".join(
            ([f"soil classes +{offset}"] if offset else []) + (["land cover renamed"] if scenes else [])))
    return notes


def validate_set(paths, version, root) -> tuple[list[str], list[str]]:
    """Errors that block the combined run, and warnings that do not."""
    errors, warnings = [], []
    if len(paths) < 2:
        errors.append("Combine at least two domains.")
    for path in paths:
        reason = validate_domain(path, version, root)
        if reason:
            errors.append(reason)
    if errors:
        return errors, warnings
    try:
        values = [_read(path, version) for path in paths]
    except ValueError as error:
        return [str(error)], warnings
    names = [Path(path).name for path in paths]

    def compare(label, get, into):
        found = [get(value) for value in values]
        if any(item != found[0] for item in found[1:]):
            into.append(f"Different {label}: " + "; ".join(f"{n}: {f}" for n, f in zip(names, found, strict=True)))

    geology = [_common_table(path, "geology_classdefinition.txt") for path in paths]
    if None not in geology and len(set(geology)) > 1:
        errors.append("Different geology class definitions (geology_classdefinition.txt); "
                      "the shared parameter file needs one classification.")
    if version_key(version) == "v6":
        compare("process cases (config_processes)", lambda v: v.get("config_processes"), errors)
        compare("time periods (config_time)", lambda v: v.get("config_time"), warnings)
        for name, value in zip(names, values, strict=True):
            project = value.get("config_project", {})
            if project.get("n_domains", 1) != 1 or project.get("read_domains_from_dirs"):
                errors.append(f"{name}: its mhm.nml must describe one domain "
                              "(n_domains = 1, read_domains_from_dirs = .false.).")
        warnings.append("mHM 6 writes each domain's outputs to its own output_path, inside the "
                        "domain folder, replacing that domain's single-run outputs.")
        return errors, warnings
    cases = [value.get("processSelection", {}).get("processCase") or [] for value in values]
    for index, process in enumerate(PROCESSES):
        found = [case[index] if index < len(case) else None for case in cases]
        if len(set(found)) > 1:  # one processCase serves every domain
            errors.append(f"{process} (processCase {index + 1}): " + ", ".join(
                f"{name} {case}" for name, case in zip(names, found, strict=True))
                + ". Set the same process cases in each domain and prepare its inputs again.")
    compare("LAI input (timeStep_LAI_input)",
            lambda v: v.get("LAI_data_information", {}).get("timeStep_LAI_input"), errors)
    lai = [_common_table(path, "LAI_classdefinition.txt") for path in paths]
    if None not in lai and len(set(lai)) > 1:
        errors.append("Different LAI class definitions (LAI_classdefinition.txt); mHM reads one for all domains.")
    compare("soil horizons", lambda v: {k: v.get("soildata", {}).get(k) for k in (
        "nSoilHorizons_mHM", "soil_Depth", "iFlag_soilDB")}, errors)
    compare("time periods", lambda v: v.get("time_periods"), warnings)
    try:
        v5_values(paths, root, values)
    except ValueError as error:
        errors.append(str(error))
    return errors, warnings


def v6_values(paths, root, values=None) -> tuple[dict, dict]:
    """The `meta` profile (combine.nml) and the dimensions for a v6 combined run."""
    values = values or [_read(path, "6") for path in paths]
    first, count = values[0], len(paths)
    projects = [value.get("config_project", {}) for value in values]
    project = {**projects[0], "n_domains": count, "read_domains_from_dirs": True}
    dimensions = {"n_domains": count}
    for key in ("n_geo_units", "max_layers"):
        sizes = [p[key] for p in projects if p.get(key)]
        if sizes:  # each domain's value must be <= the combined one
            project[key] = dimensions[key] = max(sizes)
    meta = {"config_project": project,
            "config_domain": {"domain_dirs": store_paths(root, paths), "domain_nmls": ["mhm.nml"] * count}}
    for group in ("config_processes", "config_optimize"):
        if group in first:
            meta[group] = first[group]
    return {"meta": meta}, dimensions


def _per_domain(spec) -> bool:
    shape = spec.get("x-fortran-shape")
    return (shape[0] if isinstance(shape, list) and shape else shape) == "nDomains"


def _rebase(value, domain, root):
    if isinstance(value, list):
        return [_rebase(item, domain, root) for item in value]
    if not isinstance(value, str) or not value or os.path.isabs(value):
        return value
    target = os.path.normpath(os.path.join(domain, value))
    try:
        rebased = Path(os.path.relpath(target, root)).as_posix()
    except ValueError:
        rebased = Path(target).as_posix()
    return rebased + "/" if value.endswith("/") else rebased


def _rectangular(rows):
    """Pad per-domain rows (gauges) to the widest, as the single-domain builder does."""
    if not all(isinstance(row, list) for row in rows):
        return rows
    widest = max(len(row) for row in rows)
    sample = next((row[0] for row in rows if row), 0)
    return [row + [type(sample)()] * (widest - len(row)) for row in rows]


def _is_path(spec) -> bool:
    return (spec.get("format") or spec.get("items", {}).get("format")) in ("directory-path", "file-path")


def v5_values(paths, root, values=None) -> tuple[dict, dict]:
    """One `main` profile whose per-domain arrays come from each domain's mhm.nml."""
    properties, profiles = _registry("5.13")
    values = values or [_read(path, "5.13") for path in paths]
    names = [Path(path).name for path in paths]
    count, main = len(paths), {}
    for group in profiles.get("main", []):
        datas = [value.get(group) or {} for value in values]
        if not any(datas):
            continue
        props, combined = properties.get(group, {}), {}
        for key in dict.fromkeys(k for data in datas for k in data):
            spec = props.get(key, {})
            rebase = _is_path(spec) and key not in _NOT_REBASED
            if key in _OUTPUT_PATHS:
                template = _OUTPUT_PATHS[key]
                combined[key] = ([template.format(name=n) for n in names] if _per_domain(spec)
                                 else template.format(name=names[0]))
            elif _per_domain(spec):
                items = []
                for name, path, data in zip(names, paths, datas, strict=True):
                    value = data.get(key)
                    if not isinstance(value, list) or not value:
                        raise ValueError(f"{name}: {group}.{key} is not set; save its namelists again.")
                    items.append(_rebase(value[0], path, root) if rebase else value[0])
                combined[key] = _rectangular(items)
            else:
                value = datas[0].get(key)
                combined[key] = _rebase(value, paths[0], root) if rebase else value
        main[group] = combined
    plan = _combination(paths, values)  # combined_inputs writes the folders these point at
    general = main.setdefault("directories_general", {})
    if "offsets" in plan:
        general["dirCommonFiles"] = "common/"
    for index in plan.get("own", []):
        for key in ("dir_Morpho", "dir_LCover"):
            if key in general:
                general[key][index] = f"morph/{names[index]}/"
    if "lcover" in plan:
        main.setdefault("LCover", {}).update(plan["lcover"])
    main.setdefault("mainconfig", {}).update(nDomains=count, L0Domain=list(range(1, count + 1)))
    gauges = sum(main.get("evaluation_gauges", {}).get("NoGauges_domain") or [0])
    if "evaluation_gauges" in main:
        main["evaluation_gauges"]["nGaugesTotal"] = gauges
    if "NoInflowGauges_domain" in main.get("inflow_gauges", {}):
        main["inflow_gauges"]["nInflowGaugesTotal"] = sum(main["inflow_gauges"]["NoInflowGauges_domain"])
    first = values[0]
    dimensions = {
        "nDomains": count,
        # The editor sizes the gauge arrays by the widest row; the namelist value
        # nGaugesTotal is the sum (mHM sizes its discharge buffers from it).
        "nGaugesTotal": max((len(row) for row in main.get("evaluation_gauges", {}).get("Gauge_id") or []),
                            default=0) or 1,
        "nGeoUnits": len(first.get("geoparameter", {}).get("GeoParam") or []) or 1,
        "nSoilHorizons": int(first.get("soildata", {}).get("nSoilHorizons_mHM") or 1),
        "nLcoverScene": int(first.get("LCover", {}).get("nLCoverScene") or 1),
    }
    return {"main": main}, dimensions


def prepare(paths, version, root) -> list[str]:
    """Create the multi folder's output and restart folders and seed its shared namelists.

    Each parameter or output namelist is copied from the first domain that has it
    when the multi folder has none yet; afterwards it is edited there only.
    Returns the copied file names.
    """
    layout.ensure_multi_structure(root)
    for path in paths:
        name = Path(path).name
        (Path(root) / "output" / name).mkdir(parents=True, exist_ok=True)
        (Path(root) / "restart" / name).mkdir(parents=True, exist_ok=True)
    copied = []
    for file in SHARED_FILES[version_key(version)]:
        source = next((Path(path) / file for path in paths if (Path(path) / file).is_file()), None)
        target = Path(root) / file
        if source is not None and not target.exists():
            shutil.copy2(source, target)
            copied.append(file)
    return copied

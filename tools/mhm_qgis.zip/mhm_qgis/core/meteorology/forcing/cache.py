"""Cache the meteorology folder inspection between sessions.

`read_meteo_metadata` (mhm-tools) opens every NetCDF in a folder twice: once for its
spatial signature and once to validate its time axis. On a multi-decade
ERA5-Land record that is over a thousand file opens per folder, which froze the
plugin for around half a minute on every project load. The result only depends
on the files themselves, so it is fingerprinted and reused.
"""
from __future__ import annotations

from dataclasses import asdict
from pathlib import Path

from ....externals.mhm_tools_handler import (
    MeteoFolderSpec,
    SpatialMetadata,
    about_variable,
    get_meteo_files,
    read_meteo_metadata,
)
from ...handlers.state.cache import cached_payload, fingerprint, store_payload

SECTION = "meteo_inspection"


# Inspection selects the first and last complete output periods. Aggregation
# remains a preparation-only choice.
_INSPECTED_FIELDS = (
    "kind", "source", "crs", "pattern",
    "temporal_resolution", "output_temporal_resolution", "unit",
    "cumulative", "cumulative_resolution", "variable",
)


def inspection_fingerprint(spec: MeteoFolderSpec) -> tuple[str, list[Path]]:
    """Return the inspection fingerprint and the file list it was taken from.

    Listing the folder is cheap; opening the files is not, so the fingerprint is
    built from the listing plus each file's size and modification time.
    """
    values = asdict(spec)
    files = get_meteo_files(spec)
    digest = fingerprint(files, {
        **{name: values[name] for name in _INSPECTED_FIELDS},
        "folder": str(spec.folder),
        "inspection_version": 6,
    })
    return digest, files


def preparation_fingerprint(spec: MeteoFolderSpec) -> str:
    """Return a digest covering every option the prepared forcing depends on."""
    values = asdict(spec)
    values.pop("clip_negative")  # clipping only lets a run finish; it never changes a finished output
    for name, default in (("variable", ""), ("cumulative_reset", None)):
        if values[name] == default:  # forcing prepared before these options existed stays reusable
            del values[name]
    return fingerprint(get_meteo_files(spec), {**values, "folder": str(spec.folder), "preparation_version": 3})


def _as_payload(metadata: SpatialMetadata) -> dict:
    payload = asdict(metadata)
    payload["files"] = [str(path) for path in metadata.files]
    payload["shape"] = list(metadata.shape)
    payload["bounds"] = list(metadata.bounds)
    return payload


def _from_payload(payload) -> SpatialMetadata | None:
    if not isinstance(payload, dict):
        return None
    try:
        values = dict(payload)
        values["files"] = tuple(Path(path) for path in values.get("files", ()))
        values["shape"] = tuple(values["shape"])
        values["bounds"] = tuple(values["bounds"])
        return SpatialMetadata(**values)
    except (KeyError, TypeError, ValueError):
        return None


def inspect_meteo_folder_cached(setup_folder, spec, log=None, cancelled=None):
    """Inspect one configured variable, reusing identical metadata options."""
    spec = spec.normalized()
    if not setup_folder:
        return read_meteo_metadata(spec, cancelled=cancelled)
    digest, _files = inspection_fingerprint(spec)
    metadata = _from_payload(cached_payload(setup_folder, SECTION, spec.kind, digest))
    if metadata is not None:
        return metadata
    metadata = read_meteo_metadata(spec, cancelled=cancelled)
    store_payload(setup_folder, SECTION, spec.kind, digest, _as_payload(metadata))
    return metadata


def inspect_meteo_inputs_cached(setup_folder, inputs, log=None, cancelled=None):
    """Inspect selected variables without preparing forcing."""
    options = {"cancelled": cancelled} if cancelled is not None else {}
    inspected = {}
    for spec in inputs:
        with about_variable(spec.normalized().kind):
            inspected[spec.normalized().kind] = inspect_meteo_folder_cached(setup_folder, spec, log=log, **options)
    return inspected

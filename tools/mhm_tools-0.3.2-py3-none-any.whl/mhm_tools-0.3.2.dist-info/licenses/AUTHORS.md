# mHM-Tools developers

The mHM-Tools project was created by the following people.

## Core developers

- Sebastian Müller (E-mail: <sebastian.mueller@ufz.de>)
- Simon Lüdke (E-mail: <simon.luedke@ufz.de>)

## Working Group members

- Sanjeev Bashyal (E-mail: <sanjeev.bashyal@ufz.de>)
- Jeisson Javier Leal Rojas (E-mail: <jeisson-javier.leal-rojas@ufz.de>)
- Carla Peter (E-mail: <carla.peter@ufz.de>)
- Matthias Kelbling (E-mail <matthias.kelbling@ufz.de>)
- Lennart Schüler (E-mail: <lennart.schueler@ufz.de>)

## Supervisors

- Stephan Thober (E-mail: <stephan.thober@ufz.de>)
- Luis Samaniego (E-mail: <luis.samaniego@ufz.de>)
- Sabine Attinger (E-mail: <sabine.attinger@ufz.de>)

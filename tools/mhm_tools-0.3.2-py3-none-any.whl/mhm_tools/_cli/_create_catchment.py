"""Create mHM/mRM catchment files from flow direction or DEM data.

The tool delineates global or local domains, either as full-domain basin maps
or as one or multiple gauge catchments. Gauge outlets can be selected from
coordinates and reference area, from catchment shapes, or from both. It writes
the basin ID file, optional idgauges files, a domain mask, and optional gauge
metadata and basin shapes.

Authors
-------
- Simon Lüdke
"""

import csv
import logging

logger = logging.getLogger(__name__)


def add_args(parser):
    """Add cli arguments for the create_catchment subcommand.

    Parameters
    ----------
    parser : argparse.ArgumentParser
        the main argument parser
    """
    required_args = parser.add_argument_group("required arguments")
    flags = parser.add_argument_group("flags")
    required_args.add_argument(
        "-i",
        "--input-file",
        required=True,
        help=(
            "Path to the input file. This is usually a flow direction file, but can also be a digital elevation model. In the latter case --input-type must be set to 'dem'."
        ),
    )
    required_args.add_argument(
        "-o",
        "--output-dir",
        "--output-path",
        dest="output_path",
        required=True,
        help=("Directory the catchment files are written to."),
    )
    # optional
    optional_args = parser.add_argument_group("optional arguments")
    optional_args.add_argument(
        "--input-var",
        "--vn",
        "--varname",
        dest="vn",
        default="fdir",
        help=("Name of the flow direction or DEM variable in the input file."),
    )
    optional_args.add_argument(
        "-v",
        "--input-type",
        "--var",
        dest="var",
        default="fdir",
        help=("Type of the input file, use 'fdir' or 'dem'"),
    )
    optional_args.add_argument(
        "--ftype",
        "--ftp",
        dest="ftp",
        default="d8",
        help=("ftype of input variable, use 'nextxy', 'ldd' or 'd8'"),
    )
    optional_args.add_argument(
        "--gauge-coords",
        default=None,
        help=(
            "Gauge coordinates in the form 'lat,lon' or multiple pairs like "
            "'lat1,lon1;lat2,lon2' (quote the value)."
        ),
    )
    optional_args.add_argument(
        "--gauges-csv",
        default=None,
        help=(
            "Path to CSV with gauge definitions. Required columns: id, lat, lon. "
            "Optional column: area (km2)."
        ),
    )
    optional_args.add_argument(
        "--lonlatbox",
        required=False,
        default=None,
        help=(
            """coordinates in the form of 'lon_min,lon_max,lat_min,lat_max', optionally followed by ',resolution_l0'"""
        ),
    )
    optional_args.add_argument(
        "--l0-resolution",
        required=False,
        type=float,
        default=None,
        help=("""Resolution of the morphological input grid."""),
    )
    optional_args.add_argument(
        "--l1-resolution",
        required=False,
        type=float,
        default=None,
        help=("""Resolution of the mHM target grid."""),
    )
    optional_args.add_argument(
        "--l11-resolution",
        required=False,
        type=float,
        default=None,
        help=(
            """Resolution of the mRM routing resolution. Only used to extend the grid to cleanly fit this data."""
        ),
    )
    optional_args.add_argument(
        "--l2-resolution",
        required=False,
        type=float,
        default=None,
        help=(
            """Resolution of the mHM meteo input resolution. Only used to extend the grid to cleanly fit this data."""
        ),
    )
    optional_args.add_argument(
        "--meteo-file",
        required=False,
        type=str,
        default=None,
        help=(
            """Path to a meteo file to extract the l2 resolution from. Overwrites the l2_resolution argument."""
        ),
    )
    flags.add_argument(
        "--upscale",
        action="store_true",
        default=False,
        help=("""Upscale to l1_resolution."""),
    )
    optional_args.add_argument(
        "--coords-are-not-latlon",
        action="store_true",
        default=False,
        help=("""Set this flag if the coordinates are in m not degree."""),
    )
    optional_args.add_argument(
        "--mask-file",
        default="mask.nc",
        help=(
            "Path where to save the mask file. A bare file name is saved into --output-dir (default: mask.nc)."
        ),
    )
    optional_args.add_argument(
        "--frame",
        default=0,
        type=int,
        help=(
            "Width in cells of a frame of non-flow cells around the output grid "
            "(default: 0, no frame). Ulysses mRM joins the eastern and western grid "
            "edges; the frame stops a regional domain from routing across them. "
            "Frame cells are pits in flwdir and no data in all other variables and "
            "in the mask. Caution: the frame replaces the outermost cells, it does "
            "not add cells. A single-gauge run pads the basin by the frame width "
            "first, so only a basin closer than that to the input edge loses cells. "
            "A region or multi-gauge run has no padding, so the frame overwrites "
            "the outer cells of the requested extent, basin cells included. Global "
            "runs that write basin ids ignore the frame; on other global runs it "
            "cuts the east-west connection, so don't use it there."
        ),
    )
    optional_args.add_argument(
        "--gauge-optimization-method",
        default="basinex",
        help=(
            "Selection of the gauge optimization method. There are two methods implemented: "
            "1. basinex: with increaing error (steps of 0.1) it selects all cells in the allowed radius and chooses the one closest to original gauge location. If none is found the allowed error is inceased up to max_error"
            "2. burek: Based on Burek et. al. 2023 this calculates the metric as (distance_error + 2*facc_error) and chooses the minimum error"
            "3. all: Uses both loggs comparison and then uses the one with lower error value usually basinex"
        ),
    )
    optional_args.add_argument(
        "--ref-catchment-area",
        default=None,
        help=(
            "Reference catchment area in km^2 used to identify the outlet cell near the gauge coordinates. "
            "For multiple gauges, pass a comma-separated list."
            "Shape-based matching takes precedence; area matching only runs if it finds no candidate. "
            "Without a shapefile or --lonlatbox, the input is cropped to a box 6 x sqrt(area) wide around the gauge, enlarged if the basin reaches its edge."
        ),
    )
    distance_args = optional_args.add_mutually_exclusive_group()
    distance_args.add_argument(
        "--max-distance-cells",
        default=None,
        type=int,
        help="Maximum square distance in cells to search for the outlet cell.",
    )
    distance_args.add_argument(
        "--max-distance-m",
        default=None,
        type=float,
        help="Maximum radial cell-center distance in meters for outlet candidates.",
    )
    distance_args.add_argument(
        "--max-distance-auto",
        action="store_true",
        help="Derive the maximum outlet distance per gauge as 0.15 x the perimeter "
        "of its reference shape, or of 1.5 x 4 x sqrt(area) without a shape, "
        "limited to 2-10 km.",
    )
    optional_args.add_argument(
        "--no-max-error",
        "--no-area-delimiter",
        action="store_false",
        dest="use_max_error",
        help="Do not disqualify outlet candidates by catchment-area error, or by "
        "shape overlap where a reference shape is used, and always take the best "
        "ranked candidate instead.",
    )
    optional_args.add_argument(
        "--max-error",
        default=0.05,
        type=float,
        help=("""Maximum error allowed when searching for the outlet cell."""),
    )
    optional_args.add_argument(
        "--shape-dir",
        "--shape-folder",
        dest="shape_folder",
        default=None,
        help=(
            "Directory with gauge shapefiles used for shape-based outlet matching. "
            "Files are matched by gauge id contained in the filename. Providing a shape file disables the area-based outlet matching. If both are provided, the shape-based matching is used."
        ),
    )
    optional_args.add_argument(
        "--gauge-id",
        required=False,
        default=None,
        help=(
            "If Gauge id is provided in addition to the other output a id_gauges file is created in the output_folder. "
            "For multiple gauges, pass a comma-separated list."
        ),
    )
    optional_args.add_argument(
        "--gauge-info-csv",
        required=False,
        default="gauges_info.csv",
        help=(
            "Output gauge info csv (default: gauges_info.csv). "
            "Columns: id, lon, lat, lon_old, lat_old, distance, area, old_area, "
            "area_error, score, shape_error, method."
        ),
    )
    optional_args.add_argument(
        "--id-gauges-output-dir",
        "--id-gauges-out-path",
        dest="id_gauges_out_path",
        required=False,
        default=None,
        help=(
            "Directory where idgauges.asc, idgauges.nc and gauge information files "
            "(gauges_info.csv/.nc) are written. Default is --output-dir."
        ),
    )
    optional_args.add_argument(
        "--output-vars",
        default="all",
        help=(
            "Comma-separated list of variables to output in the catchment file. "
            "Default is 'all', which outputs all variables. "
            "Variables include: 'flwdir', 'basin', 'uparea_grid', 'upgrid', 'grdare', 'elevtn'"
        ),
    )
    optional_args.add_argument(
        "--available-mem",
        required=False,
        type=str,
        default=None,
        help=("""Available memory per cpu in Gb or Mb (default Gb)"""),
    )
    optional_args.add_argument(
        "--ncpus",
        required=False,
        default=1,
        type=int,
        help=(
            "Number of cores used for parallelisation. Only needed if multiple gauges are created. 0 or -1 uses all cores."
        ),
    )


def run(args):  # noqa: PLR0912,PLR0915
    """Create the catchment file.

    Parameters
    ----------
    args : argparse.Namespace
        parsed command line arguments
    """
    from pathlib import Path

    from mhm_tools.common.cli_utils import get_available_mem_in_unit, parse_lonlatbox
    from mhm_tools.common.logger import ErrorLogger
    from mhm_tools.common.parallel import resolve_ncpus
    from mhm_tools.common.resolution_handler import Resolution

    from ..pre import create_catchment

    gauge_coords = None
    coordinate_slices = None
    gauge_ids = None
    ref_catchment_area = None

    if args.gauges_csv is not None:
        csv_path = Path(args.gauges_csv)
        if not csv_path.is_file():
            msg = f"Gauge CSV file not found: {csv_path}"
            with ErrorLogger(logger):
                raise FileNotFoundError(msg)
        with csv_path.open("r", encoding="utf-8", newline="") as fp:
            reader = csv.DictReader(fp)
            if reader.fieldnames is None:
                msg = f"Gauge CSV '{csv_path}' has no header."
                with ErrorLogger(logger):
                    raise ValueError(msg)
            field_map = {name.strip().lower(): name for name in reader.fieldnames}
            required = ("id", "lat", "lon")
            missing = [col for col in required if col not in field_map]
            if missing:
                msg = (
                    f"Gauge CSV '{csv_path}' is missing required column(s): {missing}. "
                    "Required columns are: id, lat, lon."
                )
                with ErrorLogger(logger):
                    raise ValueError(msg)
            area_col = field_map.get("area")
            gauge_coords = []
            gauge_ids = []
            areas = []
            for row_no, row in enumerate(reader, start=2):
                try:
                    gid = str(row[field_map["id"]]).strip()
                    if not gid:
                        empty_id_msg = "empty gauge id"
                        raise ValueError(empty_id_msg)
                    lat = float(str(row[field_map["lat"]]).strip())
                    lon = float(str(row[field_map["lon"]]).strip())
                except Exception as exc:
                    msg = f"Invalid id/lat/lon at row {row_no} in '{csv_path}': {exc}"
                    with ErrorLogger(logger):
                        raise ValueError(msg) from exc
                gauge_ids.append(gid)
                gauge_coords.append((lat, lon))
                if area_col is not None:
                    raw_area = str(row[area_col]).strip()
                    areas.append(float(raw_area) if raw_area else None)
            if not gauge_coords:
                msg = f"Gauge CSV '{csv_path}' does not contain any gauge rows."
                with ErrorLogger(logger):
                    raise ValueError(msg)
            if area_col is not None and any(area is not None for area in areas):
                ref_catchment_area = areas
            else:
                ref_catchment_area = None
        if (
            args.gauge_coords is not None
            or args.gauge_id is not None
            or args.ref_catchment_area is not None
        ):
            logger.warning(
                "Using gauges from --gauges-csv and ignoring --gauge-coords, --gauge-id and --ref-catchment-area."
            )
        logger.info(
            f"Loaded {len(gauge_coords)} gauges from CSV '{csv_path}'. "
            f"Area column {'found' if ref_catchment_area is not None else 'not provided'}."
        )

    if args.gauge_coords is not None and args.gauges_csv is None:

        def _parse_gauge_coords(raw_coords):
            if ";" in raw_coords:
                pairs = [p.strip() for p in raw_coords.split(";") if p.strip()]
                coords = []
                for pair in pairs:
                    lat_str, lon_str = map(str.strip, pair.split(","))
                    coords.append((float(lat_str), float(lon_str)))
                return coords
            parts = [p.strip() for p in raw_coords.split(",") if p.strip()]
            if len(parts) == 2:
                lat, lon = map(float, parts)
                return (lat, lon)
            if len(parts) % 2 != 0:
                error_msg = "gauge_coords must be 'lat,lon' or a list of lat,lon pairs."
                with ErrorLogger(logger):
                    raise ValueError(error_msg)
            coords = []
            for lat_str, lon_str in zip(parts[0::2], parts[1::2]):
                coords.append((float(lat_str), float(lon_str)))
            return coords

        if args.lonlatbox is not None:
            logger.warning(
                "You are using --gauge_coords and --lonlatbox at the same time. Make sure this is intendet and the lonlatbox contains the whole catchment area."
            )
        gauge_coords = _parse_gauge_coords(args.gauge_coords)
        if isinstance(gauge_coords, list):
            logger.info(
                f"using gauge coordinates (n={len(gauge_coords)}): {gauge_coords}"
            )
        else:
            logger.info(f"using gauge coordinates {gauge_coords}")
    if args.lonlatbox is not None:
        lonmin, lonmax, latmin, latmax, resl0 = parse_lonlatbox(args.lonlatbox)
        coordinate_slices = {"lat": slice(latmax, latmin), "lon": slice(lonmin, lonmax)}
        logger.info(
            f"using lonlatbox with extends: lat=({latmax}, {latmin}); lon=({lonmin}, {lonmax})"
        )
    if args.gauge_id is not None and args.gauges_csv is None:
        raw_ids = str(args.gauge_id)
        if "," in raw_ids:
            gauge_ids = [val.strip() for val in raw_ids.split(",") if val.strip()]
        else:
            gauge_ids = raw_ids.strip()
    if args.ref_catchment_area is not None and args.gauges_csv is None:
        raw_areas = str(args.ref_catchment_area)
        if "," in raw_areas:
            ref_catchment_area = [
                float(val.strip()) for val in raw_areas.split(",") if val.strip()
            ]
        else:
            ref_catchment_area = float(raw_areas)
    list_lengths = {
        name: len(val)
        for name, val in (
            ("gauge_coords", gauge_coords),
            ("gauge_ids", gauge_ids),
            ("ref_catchment_area", ref_catchment_area),
        )
        if isinstance(val, list)
    }
    if list_lengths and not isinstance(gauge_coords, list):
        error_msg = "gauge_coords must be a list when gauge_ids or ref_catchment_area is a list."
        with ErrorLogger(logger):
            raise ValueError(error_msg)
    if list_lengths and len(set(list_lengths.values())) > 1:
        error_msg = "gauge_coords, gauge_ids and ref_catchment_area lists must have the same length."
        with ErrorLogger(logger):
            raise ValueError(error_msg)
    if args.upscale and not args.l1_resolution:
        msg = "If upscaling is enabled l1_resolution must be provided."
        with ErrorLogger(logger):
            raise ValueError(msg)
    available_mem = get_available_mem_in_unit(args.available_mem)
    if Path(args.mask_file).name == str(Path(args.mask_file)):
        mask_file = str(Path(args.output_path) / Path(args.mask_file))
    else:
        mask_file = args.mask_file
    l0_resolution = args.l0_resolution
    if l0_resolution is None and args.lonlatbox is not None:
        l0_resolution = resl0
    coarse_resolutions = Resolution(
        l0=l0_resolution if l0_resolution is not None else None,
        l1=args.l1_resolution,
        l11=args.l11_resolution,
        l2=args.l2_resolution,
        l2_file=args.meteo_file,
    )
    ncpus = resolve_ncpus(args.ncpus)
    if ncpus > 1:
        logger.info(f"Using {ncpus} cpus for catchment creation.")
    create_catchment(
        input_file=args.input_file,
        output_path=args.output_path,
        var_name=args.vn,
        var=args.var,
        ftype=args.ftp,
        gauge_coords=gauge_coords,
        coordinate_slices=coordinate_slices,
        mask_file=mask_file,
        resolutions=coarse_resolutions,
        frame=args.frame,
        upscale=args.upscale,
        latlon=not args.coords_are_not_latlon,
        available_mem=available_mem,
        ref_catchment_area=ref_catchment_area,
        max_distance_cells=args.max_distance_cells,
        max_distance_m=args.max_distance_m,
        max_distance_auto=args.max_distance_auto,
        max_error=args.max_error,
        use_max_error=args.use_max_error,
        gauge_ids=gauge_ids,
        ncpus=ncpus,
        output_vars=(
            None if str(args.output_vars).strip().lower() == "all" else args.output_vars
        ),
        gauge_opti_method=args.gauge_optimization_method,
        shape_folder=args.shape_folder,
        gauge_info_file=args.gauge_info_csv,
        id_gauges_out_path=(
            args.id_gauges_out_path
            if args.id_gauges_out_path is not None
            else args.output_path
        ),
    )

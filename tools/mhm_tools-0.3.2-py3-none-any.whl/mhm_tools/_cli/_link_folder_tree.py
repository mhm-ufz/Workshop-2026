"""Create a symlinked copy of a folder tree.

The tool recreates the input directory structure under a new output directory
and links matching files instead of copying their contents. Existing links can
optionally be overwritten, and the linked files can be restricted by a filename
pattern.

Authors
-------
- Simon Lüdke
"""

import logging
from pathlib import Path

logger = logging.getLogger("mhm_tools.link_folder_tree")


def add_args(parser):
    """Add cli arguments for the link_folder_tree subcommand.

    Parameters
    ----------
    parser : argparse.ArgumentParser
        the main argument parser

    """
    optional = parser.add_argument_group("optional arguments")
    flags = parser.add_argument_group("flags")
    optional.add_argument(
        "-i",
        "--input-dir",
        required=True,
        help="The path to input directory.",
    )
    optional.add_argument(
        "-o", "--output-dir", required=True, help="The name of the output directory."
    )
    flags.add_argument(
        "--overwrite",
        action="store_true",
        required=False,
        help=("overwrite existing symlinks"),
    )
    optional.add_argument(
        "--input-file-name",
        "--file-name",
        dest="file_name",
        type=str,
        default="*.*",
        required=False,
        help=("File name pattern to link, default is '*.*'"),
    )
    optional.add_argument(
        "--exclude-pattern",
        dest="exclude_patterns",
        action="append",
        default=None,
        required=False,
        help=(
            "Pattern of files that are not linked. A pattern without '/' is "
            "matched against the file name, e.g. 'mRM_Fluxes*', a pattern with '/' "
            "against the path relative to the input directory, e.g. "
            "'*/domain_evaluation/*', where '*' also matches '/'. "
            "Can be given multiple times."
        ),
    )
    optional.add_argument(
        "--include-pattern",
        dest="include_patterns",
        action="append",
        default=None,
        required=False,
        help=(
            "Pattern of the only files to link, matched like --exclude-pattern, "
            "e.g. '*.nml' or '*/mhm_setup/*'. Can be given multiple times. "
            "--exclude-pattern takes precedence."
        ),
    )


def run(args):
    """Create a symlinked copy of a folder tree.

    Parameters
    ----------
    args : argparse.Namespace
        parsed command line arguments
    """
    from mhm_tools.pre.link_folder_tree import link_folder_tree

    input_dir = Path(args.input_dir)
    output_dir = Path(args.output_dir)
    link_folder_tree(
        input_dir=input_dir,
        output_dir=output_dir,
        overwrite=args.overwrite,
        file_name=args.file_name,
        exclude_patterns=args.exclude_patterns,
        include_patterns=args.include_patterns,
    )

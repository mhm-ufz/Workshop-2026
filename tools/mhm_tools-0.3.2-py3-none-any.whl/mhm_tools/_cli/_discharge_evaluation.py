"""Evaluate simulated discharge against observed gauge discharge.

The tool matches model and observation time series, optionally optimizes gauge
locations with flow-accumulation data, filters by domain, date range, or gauge
list, and computes discharge metrics with optional bootstrap sampling. It can
write processed hydrographs, metric tables, and diagnostic hydrograph plots.

Authors
-------
- Simon Lüdke
"""

from mhm_tools.common.cli_utils import add_netcdf_compression_args


def add_args(parser):
    """Add CLI arguments for the grdc_validation subcommand."""
    required_args = parser.add_argument_group("required arguments")
    required_args.add_argument(
        "--output-dir", help="Path for the output dir.", required=True
    )
    output_names = parser.add_argument_group("output file names")
    output_names.add_argument(
        "--results-file-name",
        default="discharge_eval_results.csv",
        help="Name of the per-station results CSV inside --output-dir. "
        "By default `discharge_eval_results.csv`.",
    )
    output_names.add_argument(
        "--overview-pdf-name",
        default="discharge_eval_overview.pdf",
        help="Name of the overview PDF inside --output-dir. "
        "By default `discharge_eval_overview.pdf`.",
    )
    optional = parser.add_argument_group("optional arguments")
    flags = parser.add_argument_group("flags")
    # the names follow the other evaluation tools, the former model/observed
    # names stay as hidden aliases
    optional.add_argument(
        "--ref-path",
        "--observed-data-path",
        dest="ref_path",
        required=False,
        help=("Path to the observation data file."),
    )
    optional.add_argument(
        "--input-path",
        "--model-data-path",
        dest="input_path",
        required=False,
        help=("Path to the model data."),
    )
    optional.add_argument(
        "--input-file-name",
        "--model-file-name",
        dest="input_file_name",
        required=False,
        default="mrm_node_output.nc",
        help=("File name pattern for model data files."),
    )
    optional.add_argument(
        "--ref-var",
        "--ref-variable",
        "--observed-variable",
        dest="ref_variable",
        required=False,
        default="runoff_mean",
        help=(""),
    )
    optional.add_argument(
        "--input-var",
        "--input-variable",
        "--model-variable",
        dest="input_variable",
        required=False,
        default=None,
        help=("Variable name of the simulation data."),
    )
    optional.add_argument(
        "--facc-file",
        "--mrm-restart",
        dest="facc_file",
        required=False,
        default=None,
        help=(
            "Flow-accumulation file (mRM v5 style): gauges are relocated to the cell "
            "best matching their reference catchment area (methods basinex, burek)."
        ),
    )
    optional.add_argument(
        "--facc-var",
        "--facc-variable",
        dest="facc_variable",
        required=False,
        default="L11_fAcc",
        help=("Variable name in --facc-file containing flow accumulation."),
    )
    optional.add_argument(
        "--scc-gauges-file",
        required=False,
        default=None,
        help=(
            "scc gauges file for river node output (mRM v6+): gauges are matched to "
            "the nodes by station id."
        ),
    )
    optional.add_argument(
        "--gauge-coordinate-file",
        required=False,
        default=None,
        help=(
            "Gauge coordinates for gridded model output: a NetCDF with 'station' ids "
            "and x/y (or lon/lat) in the CRS of the model grid, e.g. a corrected scc "
            "gauges file. Gauges are paired with the reference by id and read from "
            "the nearest grid cell without relocation (methods nearest, mean-flow). "
            "Alternative to --scc-gauges-file and --facc-file."
        ),
    )
    optional.add_argument(
        "--evaluation-gauges",
        required=False,
        default=None,
        help=(
            "Path to a file containing the gauge ids to be used for the evaluation. If not provided, all gauges will be used."
        ),
    )
    optional.add_argument(
        "--ncpus",
        required=False,
        default=1,
        type=int,
        help="Number of CPUs used to read the model files and evaluate the gauges. 0 or -1 uses all cores.",
    )
    optional.add_argument(
        "--lonlatbox",
        required=False,
        default=None,
        help=(
            """coordinates in the form of 'lon_min,lon_max,lat_min,lat_max', a fifth L0 resolution value is ignored"""
        ),
    )
    optional.add_argument(
        "--mask-file",
        required=False,
        default=None,
        help=(
            """path to the mask file, a .nc file with a variable 'mask' containing the grid mask at l0 resolution
            required unless --lonlatbox is provided"""
        ),
    )
    optional.add_argument(
        "--shape-dir",
        "--shape-folder",
        dest="shape_folder",
        required=False,
        default=None,
        help="Directory with catchment shapefiles matched by gauge ID.",
    )
    optional.add_argument(
        "--mask-dir",
        "--mask-folder",
        dest="mask_folder",
        required=False,
        default=None,
        help="Directory with catchment mask NetCDF files matched by gauge ID.",
    )
    optional.add_argument(
        "--mask-var",
        required=False,
        default=None,
        help="Variable in catchment mask files used for median maps.",
    )
    optional.add_argument(
        "--catchment-map-variables",
        nargs="+",
        required=False,
        default=None,
        help="Metric columns to plot on catchment median maps.",
    )
    optional.add_argument(
        "--metric-plot-types",
        nargs="+",
        required=False,
        default=["cdf", "map", "catchment-map"],
        choices=["cdf", "violin", "map", "catchment-map"],
        help="Metric plot types to create. Violin plots are only made on request.",
    )
    optional.add_argument(
        "--max-mean-factor",
        required=False,
        default=30.0,
        type=float,
        help=(
            "Leave stations whose beta (mean sim / mean obs) is above this factor or "
            "below its inverse out of the region table and the PDF summary table; the "
            "plots keep them. Use inf to keep all stations."
        ),
    )
    optional.add_argument(
        "--n-bootstrap-years",
        "--n-boostrap-years",
        dest="n_boostrap_years",
        required=False,
        default=None,
        type=int,
        help=("""Number of years to draw for each bootstrap experiment"""),
    )
    optional.add_argument(
        "--n-bootstrap-selections",
        required=False,
        default=None,
        type=int,
        help=("Number of boostrap experiments"),
    )
    optional.add_argument(
        "--start-date",
        required=False,
        default=None,
        type=str,
        help=("""First year allowed in the analysis."""),
    )
    optional.add_argument(
        "--end-date",
        required=False,
        default=None,
        type=str,
        help=("Lates year that is allowed in the analysis."),
    )
    optional.add_argument(
        "--min-overlapping-years",
        required=False,
        default=None,
        type=int,
        help=("Minimum number of overlapping years for evaluation."),
    )
    optional.add_argument(
        "--gauge-optimization-method",
        "--gauge-location-method",
        dest="gauge_location_method",
        required=False,
        default=None,
        choices=["basinex", "burek", "nearest", "mean-flow"],
        help=(
            "Gauge location method. With --facc-file: basinex (default) or burek "
            "relocate gauges by catchment area. With --gauge-coordinate-file: nearest "
            "(default) reads the cell of the gauge, mean-flow the cell within "
            "--gauge-max-distance-cells whose 12 monthly mean discharges are closest "
            "to the observed ones; mean-flow uses the observations to choose the cell, "
            "so the bias (beta) looks better than it is."
        ),
    )
    optional.add_argument(
        "--gauge-max-distance-cells",
        required=False,
        default=None,
        type=int,
        help=(
            "Maximum number of grid cells gauge location may be shifted. "
            "Default: 3 with --facc-file, 1 (3 x 3 cells) for mean-flow."
        ),
    )
    optional.add_argument(
        "--gauge-max-error",
        required=False,
        default=0.1,
        type=float,
        help=("Maximum allowed relative catchment-area error (fraction; 0.1 = 10%)."),
    )
    optional.add_argument(
        "--hydrograph-plots",
        default="tysc",
        required=False,
        help="specifies which graphics are generated."
        "t model timestep, y yearly, s seasonality, p flow duration, c scatter e.g. "
        "all with out seasonality (advised for performance) = typc",
    )
    flags.add_argument(
        "--use-cached-input-data",
        action="store_true",
        dest="use_cached_input_data",
        required=False,
        help=(
            "Use cached input data if available. Otherwise, process the input data from scratch."
        ),
    )
    flags.add_argument(
        "--save-hydrograph",
        help="Set flag if the calculated hydrographs should be saved and not just the metrics calculated.",
        action="store_true",
        required=False,
    )
    flags.add_argument(
        "--only-plot",
        help="Set Flag if existing output file should be used to create plot",
        action="store_true",
        required=False,
    )
    add_netcdf_compression_args(parser)
    flags.add_argument(
        "--no-input-data-cache",
        help=(
            "Set flag to not write the processed input data to file. This avoids unnecessary file I/O but may slow down subsequent runs with the same input data. If file is written overwriting is controlled by the --overwrite flag."
        ),
        action="store_true",
        required=False,
    )


def run(args):
    """Evaluate GRDC discharge data against model output.

    Parameters
    ----------
    args : argparse.Namespace
        parsed command line arguments
    """
    from mhm_tools.common.cli_utils import (
        get_coords,
        get_netcdf_compression,
        normalize_cli_sequence,
    )
    from mhm_tools.common.parallel import resolve_ncpus
    from mhm_tools.post.discharge_evaluation import (
        _resolve_gauge_location_method,
        evaludate_discharge_data,
    )

    # refuse competing gauge sources and methods without their source early
    gauge_location_method, gauge_max_distance_cells = _resolve_gauge_location_method(
        args.gauge_location_method,
        args.gauge_max_distance_cells,
        facc_file=args.facc_file,
        scc_gauges_file=args.scc_gauges_file,
        gauge_coordinate_file=args.gauge_coordinate_file,
    )
    lon_min, lon_max, lat_min, lat_max, _mask = get_coords(
        args.lonlatbox, args.mask_file, raise_exception=False
    )
    evaludate_discharge_data(
        args.input_path,
        args.ref_path,
        model_file_name=args.input_file_name,
        facc_file=args.facc_file,
        facc_variable=args.facc_variable,
        scc_gauges_file=args.scc_gauges_file,
        gauge_coordinate_file=args.gauge_coordinate_file,
        output_path=args.output_dir,
        evaluation_gauges=args.evaluation_gauges,
        n_jobs=resolve_ncpus(args.ncpus),
        sim_variable=args.input_variable,
        observed_variable=args.ref_variable,
        lon_min=lon_min,
        lon_max=lon_max,
        lat_min=lat_min,
        lat_max=lat_max,
        n_boostrap_selections=args.n_bootstrap_selections,
        n_bootstrap_years=args.n_boostrap_years,
        direct_comparison=args.n_bootstrap_selections is None
        or args.n_boostrap_years is None,
        start_date=args.start_date,
        end_date=args.end_date,
        overwrite=not args.use_cached_input_data,
        only_plot=args.only_plot,
        save_hydrograph=args.save_hydrograph,
        min_overlapping_years=args.min_overlapping_years,
        write_input_data_cache=not args.no_input_data_cache,
        gauge_location_method=gauge_location_method,
        gauge_max_distance_cells=gauge_max_distance_cells,
        gauge_max_error=args.gauge_max_error,
        hydrograph_plots=args.hydrograph_plots,
        shape_folder=args.shape_folder,
        mask_folder=args.mask_folder,
        mask_var=args.mask_var,
        catchment_map_variables=normalize_cli_sequence(args.catchment_map_variables),
        metric_plot_types=args.metric_plot_types,
        max_mean_factor=args.max_mean_factor,
        results_file_name=args.results_file_name,
        overview_pdf_name=args.overview_pdf_name,
        compression=get_netcdf_compression(args),
    )

"""Pre processing routines for mHM.

Files
=====

.. autosummary::
   :toctree:

   ~mhm_tools.pre.catchment
   ~mhm_tools.pre.create_id_gauges
   ~mhm_tools.pre.create_mhm_restart_file
   ~mhm_tools.pre.create_mhm_restart_from_setup
   ~mhm_tools.pre.create_wmo_region_masks
   ~mhm_tools.pre.crop_mhm_setup
   ~mhm_tools.pre.fill_nearest
   ~mhm_tools.pre.format_geology
   ~mhm_tools.pre.format_lai
   ~mhm_tools.pre.format_lc_data
   ~mhm_tools.pre.format_soil
   ~mhm_tools.pre.landcover_ascii_to_nc
   ~mhm_tools.pre.latlon
   ~mhm_tools.pre.link_folder_tree
   ~mhm_tools.pre.merge
   ~mhm_tools.pre.pet_calc
   ~mhm_tools.pre.prepare_mhm_forcings
   ~mhm_tools.pre.rasterize_map
   ~mhm_tools.pre.regrid
   ~mhm_tools.pre.subdomain_masks
   ~mhm_tools.pre.topography_upscaling
"""

import importlib
import sys
import types

_MODULE_EXPORTS = {
    "catchment": "catchment",
    "create_mhm_restart_from_setup": "create_mhm_restart_from_setup",
    "create_mhm_restart_file": "create_mhm_restart_file",
    "fill_nearest": "fill_nearest",
    "format_geology": "format_geology",
    "format_lai": "format_lai",
    "format_soil": "format_soil",
    "latlon": "latlon",
    "rasterize_map": "rasterize_map",
    "subdomain_masks": "subdomain_masks",
}

_ATTR_EXPORTS = {
    "create_catchment": ("catchment", "create_catchment"),
    "merge_catchment": ("catchment", "merge_catchment"),
    "create_id_gauges": ("create_id_gauges", "create_id_gauges"),
    "Grid": ("create_mhm_restart_file", "Grid"),
    "LatLon": ("create_mhm_restart_file", "LatLon"),
    "MHMRestartFile": ("create_mhm_restart_file", "MHMRestartFile"),
    "MHMRunner": ("create_mhm_restart_from_setup", "MHMRunner"),
    "MorphFiles": ("create_mhm_restart_file", "MorphFiles"),
    "crop_mhm_setup": ("crop_mhm_setup", "crop_mhm_setup"),
    "create_latlon": ("latlon", "create_latlon"),
    "xy_to_latlon": ("latlon", "xy_to_latlon"),
    "link_folder_tree": ("link_folder_tree", "link_folder_tree"),
    "create_subdomain_masks": ("subdomain_masks", "create_subdomain_masks"),
    "create_wmo_region_masks": ("create_wmo_region_masks", "create_wmo_region_masks"),
    "fill_nearest": ("fill_nearest", "fill_dataarray_with_nearest"),
    "format_geology_data": ("format_geology", "format_geology_data"),
    "write_geology_classdefinition": (
        "format_geology",
        "write_geology_classdefinition",
    ),
    "format_lai_data": ("format_lai", "format_lai_data"),
    "format_lai_netcdf_data": ("format_lai", "format_lai_netcdf_data"),
    "format_lai_netcdf_file": ("format_lai", "format_lai_netcdf_file"),
    "copy_lai_netcdf_to_grid": ("format_lai", "copy_lai_netcdf_to_grid"),
    "lai_time_step": ("format_lai", "lai_time_step"),
    "write_lai_classdefinition": (
        "format_lai",
        "write_lai_classdefinition",
    ),
    "format_soil_data": ("format_soil", "format_soil_data"),
    "format_soil_horizons": ("format_soil", "format_soil_horizons"),
    "write_soil_classdefinition": (
        "format_soil",
        "write_soil_classdefinition",
    ),
    "rasterize_map_data": ("rasterize_map", "rasterize_map_data"),
    "format_lc_data": ("format_lc_data", "format_lc_data"),
    "format_lc_periods": ("format_lc_data", "format_lc_periods"),
}

__all__ = [
    "Grid",
    "LatLon",
    "MHMRestartFile",
    "MHMRunner",
    "MorphFiles",
    "catchment",
    "copy_lai_netcdf_to_grid",
    "create_catchment",
    "create_id_gauges",
    "create_latlon",
    "create_mhm_restart_file",
    "create_mhm_restart_from_setup",
    "create_subdomain_masks",
    "create_wmo_region_masks",
    "crop_mhm_setup",
    "fill_nearest",
    "format_geology",
    "format_geology_data",
    "format_lai",
    "format_lai_data",
    "format_lai_netcdf_data",
    "format_lai_netcdf_file",
    "format_lc_data",
    "format_lc_periods",
    "format_soil",
    "format_soil_data",
    "format_soil_horizons",
    "lai_time_step",
    "latlon",
    "link_folder_tree",
    "merge_catchment",
    "rasterize_map",
    "rasterize_map_data",
    "subdomain_masks",
    "write_geology_classdefinition",
    "write_lai_classdefinition",
    "write_soil_classdefinition",
    "xy_to_latlon",
]


def __getattr__(name):
    if name in _MODULE_EXPORTS:
        module = importlib.import_module(f".{_MODULE_EXPORTS[name]}", __name__)
        globals()[name] = module
        return module
    if name in _ATTR_EXPORTS:
        module_name, attr_name = _ATTR_EXPORTS[name]
        module = importlib.import_module(f".{module_name}", __name__)
        attr = getattr(module, attr_name)
        globals()[name] = attr
        return attr
    error_msg = f"module '{__name__}' has no attribute '{name}'"
    raise AttributeError(error_msg)


def __dir__():
    return sorted(set(globals().keys()) | set(__all__))


# formerly imported eagerly, so the package attribute was always the function
_FUNCTION_EXPORTS_OVER_SUBMODULE = ("format_lc_data",)


class _PrePackage(types.ModuleType):
    """Package module keeping ``format_lc_data`` as function export."""

    def __setattr__(self, name, value):
        """Set an attribute unless it binds a submodule over a function export.

        Importing a submodule binds it on the package; ``format_lc_data`` is
        exported as the function of the module with the same name and keeps it.
        """
        if (
            isinstance(value, types.ModuleType)
            and name in _FUNCTION_EXPORTS_OVER_SUBMODULE
        ):
            return
        super().__setattr__(name, value)


sys.modules[__name__].__class__ = _PrePackage

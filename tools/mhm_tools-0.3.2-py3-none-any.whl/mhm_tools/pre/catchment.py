"""Delineate catchments and basin maps for mHM/mRM setups.

The module builds hydrologic grids from flow direction or DEM data, supports
global and local domains, single- and multi-gauge delineation, outlet matching
by area or shape, and writes basin ID, idgauges, mask, gauge metadata, and
basin shape outputs.

Authors
-------
- Simon Lüdke
"""

import csv
import functools
import logging
from pathlib import Path
from typing import Optional

import numpy as np
import pyflwdir
import xarray as xr
from joblib import Parallel, delayed
from scipy.ndimage import binary_dilation

from mhm_tools.common.constants import (
    EARTH_RADIUS_KM,
    FDIR_FILLVALUE,
    FDIR_SINKVALUE,
    NC_ENCODE_MASK,
    NO_DATA,
)
from mhm_tools.common.file_handler import (
    get_coord_values,
    get_xarray_ds_from_file,
    write_xarray_to_file,
)
from mhm_tools.common.logger import ErrorLogger, log_arguments
from mhm_tools.common.netcdf import add_variable_hard_link, generate_bounds
from mhm_tools.common.provenance import apply_output_provenance
from mhm_tools.common.resolution_handler import (
    Resolution,
    calculate_coordinate_resolution,
)
from mhm_tools.common.utils import (
    convert_meters_to_degrees,
    coord_to_index,
    cut_to_filled_area,
    distance_100m_units,
    find_best_gauge_location_by_area,
    get_candidate_search_window,
    get_upscaling_factor,
)
from mhm_tools.common.xarray_utils import (
    get_dtype,
)
from mhm_tools.pre.create_id_gauges import write_gauge_id

logger = logging.getLogger(__name__)


# GLOBAL VARIABLES
# accumulated values are at least one cell or above 0 km2 on valid cells, so 0
# is their fill value, unlike the -9999 of the other outputs
FACC_FILLVALUE = 0
FILLVALUE = int(NO_DATA)
OUTPUT_VARIABLES = ("flwdir", "basin", "uparea_grid", "upgrid", "grdare", "elevtn")
GAUGE_INFO_COLUMNS = (
    "id",
    "lon",
    "lat",
    "lon_old",
    "lat_old",
    "distance",
    "area",
    "old_area",
    "area_error",
    "score",
    "shape_error",
    "method",
)
# use d8 for basinex, ldd for mRM version in Ulysses
OUTPUT_FTYPE = "ldd"
CUTOFF_THRESHOLD = 175
# an outlet candidate has to drain a plausible fraction/multiple of the
# reference catchment area, which keeps hillslope and main-stem cells out
CANDIDATE_AREA_AGREEMENT_FACTOR = 0.1
# a reference shape can disagree with the flow direction data, so the crop for
# the delineation keeps room for a catchment reaching beyond the shape bounds
SHAPE_BUFFER_EXTENT_FACTOR = 1.5
# without a reference shape the crop around a gauge is a box centred on it,
# this many times the square root of the reference catchment area wide; 6 reaches
# 3 sqrt(A) from the gauge, which covers basins down to an elongation ratio of ~0.4
AREA_CROP_WIDTH_FACTOR = 6
# an automatic crop a basin reaches the edge of is enlarged by this factor in
# width and height and the delineation is repeated, at most this many times
CROP_GROWTH_FACTOR = 2
CROP_RETRY_LIMIT = 2
CROP_SIDES = ("north", "south", "west", "east")
# the automatic outlet search distance is a fraction of the catchment
# perimeter, approximated from the area as 1.5 times the perimeter of a square
AUTO_MAX_DISTANCE_PERIMETER_FACTOR = 0.15
AUTO_MAX_DISTANCE_LIMITS_M = (2000.0, 10000.0)
AREA_PERIMETER_FACTOR = 1.5 * 4


# every numeric gauge info column reports an unknown value as nan
GAUGE_INFO_NUMERIC_COLUMNS = (
    "lon",
    "lat",
    "lon_old",
    "lat_old",
    "distance",
    "area",
    "old_area",
    "area_error",
    "score",
    "shape_error",
)


def _fill_missing_numbers(row):
    """Replace missing numeric gauge info values with nan, in place."""
    for column in GAUGE_INFO_NUMERIC_COLUMNS:
        if row.get(column) is None:
            row[column] = np.nan
    return row


def _format_area(area):
    """Return an area in km2 for a log message, "unknown" if there is none."""
    return "unknown" if area is None else f"{area:.0f} km2"


def _shape_crs(is_latlon):
    """Return a CRS string for shapefile operations based on lat/lon usage."""
    crs = "EPSG:4326" if is_latlon else None
    logger.debug(f"Resolved shape CRS to {crs}")
    return crs


def _find_shape_file(shape_folder, gauge_id):
    """Find a shapefile in a folder that contains the gauge_id in its name."""
    if not shape_folder or gauge_id is None:
        return None
    shape_dir = Path(shape_folder)
    if not shape_dir.is_dir():
        return None
    matching_shapes = sorted(shape_dir.glob(f"*{gauge_id}*.shp"))
    if not matching_shapes:
        return None
    if len(matching_shapes) > 1:
        logger.warning(
            f"Multiple shapefiles matched gauge_id {gauge_id} in {shape_dir}. "
            f"Using {matching_shapes[0].name}"
        )
    logger.debug(f"Using shapefile {matching_shapes[0]} for gauge_id {gauge_id}")
    return matching_shapes[0]


def _read_reference_shape(shape_folder, gauge_id, latlon):
    """Read a reference catchment shape and normalize its CRS."""
    shape_path = _find_shape_file(shape_folder, gauge_id)
    if shape_path is None:
        return None, None
    try:
        import geopandas as gpd
    except Exception as exc:
        error_msg = "geopandas is required for shape-based gauge correction."
        with ErrorLogger(logger):
            raise ImportError(error_msg) from exc
    reference_shape = gpd.read_file(shape_path)
    crs = _shape_crs(latlon)
    if crs is not None:
        if reference_shape.crs is None:
            reference_shape = reference_shape.set_crs(crs)
        elif str(reference_shape.crs) != str(crs):
            reference_shape = reference_shape.to_crs(crs)
    logger.debug(f"Loaded reference shape {shape_path}")
    return reference_shape, shape_path


def _as_affine(affine_transform):
    try:
        from rasterio.transform import Affine
    except Exception as exc:
        error_msg = "rasterio is required for basin shapefile operations."
        with ErrorLogger(logger):
            raise ImportError(error_msg) from exc
    if isinstance(affine_transform, Affine):
        return affine_transform
    try:
        return Affine(*affine_transform)
    except Exception:
        return Affine.from_gdal(*affine_transform)


def _rasterize_shape_to_mask(reference_shape, grid_shape, affine_transform):
    """Rasterize a reference catchment shape to the active grid."""
    try:
        from rasterio import features
    except Exception as exc:
        error_msg = "rasterio is required for shape-based gauge correction."
        with ErrorLogger(logger):
            raise ImportError(error_msg) from exc
    if reference_shape is None or reference_shape.empty:
        return None
    geometries = [
        geom
        for geom in reference_shape.geometry
        if geom is not None and not getattr(geom, "is_empty", False)
    ]
    if not geometries:
        return None
    mask = features.rasterize(
        ((geom, 1) for geom in geometries),
        out_shape=grid_shape,
        transform=_as_affine(affine_transform),
        fill=0,
        dtype="uint8",
        all_touched=True,
    )
    return mask.astype(bool)


def _cell_polygon(affine_transform, row_idx, col_idx):
    """Create a polygon for one raster cell from an affine transform."""
    try:
        from shapely.geometry import Polygon
    except Exception as exc:
        error_msg = "shapely is required for shape/grid overlap calculation."
        with ErrorLogger(logger):
            raise ImportError(error_msg) from exc

    corners = [
        affine_transform * (col_idx, row_idx),
        affine_transform * (col_idx + 1, row_idx),
        affine_transform * (col_idx + 1, row_idx + 1),
        affine_transform * (col_idx, row_idx + 1),
    ]
    return Polygon(corners)


def _calculate_shape_area_on_grid(
    reference_shape, cell_area, grid_shape, affine_transform
):
    """Calculate shape-covered area on a grid in km2.

    Fractional cell overlap is used when shapely operations are available. If that
    fails, fall back to summing cells from the existing rasterized shape mask.
    """
    if reference_shape is None or reference_shape.empty or cell_area is None:
        return None

    cell_area = np.asarray(cell_area)
    if cell_area.shape != tuple(grid_shape):
        msg = (
            f"cell_area shape {cell_area.shape} does not match grid shape "
            f"{tuple(grid_shape)} for shape area calculation."
        )
        with ErrorLogger(logger):
            raise ValueError(msg)

    affine_transform = _as_affine(affine_transform)
    shape_mask = _rasterize_shape_to_mask(
        reference_shape,
        grid_shape,
        affine_transform,
    )
    if shape_mask is None or not np.any(shape_mask):
        return None

    try:
        reference_geom = _geometry_union(reference_shape.geometry)
        if reference_geom.is_empty:
            return None

        area = 0.0
        for row_idx, col_idx in zip(*np.where(shape_mask)):
            cell_geom = _cell_polygon(affine_transform, int(row_idx), int(col_idx))
            cell_geom_area = cell_geom.area
            if cell_geom_area <= 0:
                continue
            overlap_area = reference_geom.intersection(cell_geom).area
            overlap_fraction = np.clip(overlap_area / cell_geom_area, 0.0, 1.0)
            area += float(cell_area[row_idx, col_idx]) * float(overlap_fraction)
        if area > 0:
            return float(area)
    except Exception as exc:
        logger.debug(
            "Could not calculate fractional shape/grid overlap; falling back to "
            f"rasterized-cell area sum: {exc}"
        )

    area = float(np.sum(cell_area[shape_mask]))
    return area if area > 0 else None


def _vectorize_mask_to_gdf(basin_mask, affine_transform, crs, value_name="basin"):
    """Vectorize a basin mask into a GeoDataFrame."""
    try:
        import geopandas as gpd
        from rasterio import features
    except Exception as exc:
        error_msg = (
            "geopandas and rasterio are required for basin shapefile operations."
            "Please install them using `conda install geopandas`"
        )
        with ErrorLogger(logger):
            raise ImportError(error_msg) from exc

    affine_transform = _as_affine(affine_transform)

    data = basin_mask.astype(np.uint8)
    # Extract polygons for non-zero cells
    feats_gen = features.shapes(
        data,
        mask=data.astype(bool),
        transform=affine_transform,
        connectivity=8,
    )
    features_list = [
        {"geometry": geom, "properties": {value_name: 1}} for geom, _ in feats_gen
    ]
    if not features_list:
        logger.debug("No vectorizable features found in basin mask.")
        return gpd.GeoDataFrame(
            columns=[value_name, "geometry"], geometry="geometry", crs=crs
        )
    gdf = gpd.GeoDataFrame.from_features(features_list, crs=crs)
    gdf[value_name] = gdf[value_name].astype(np.uint8)
    logger.debug(f"Vectorized basin mask into {len(gdf)} features.")
    return gdf


def _shape_iou(reference_gdf, candidate_gdf):
    """Compute intersection-over-union for two GeoDataFrames."""
    if (
        reference_gdf is None
        or candidate_gdf is None
        or reference_gdf.empty
        or candidate_gdf.empty
    ):
        return 0.0
    reference_geom = _geometry_union(reference_gdf.geometry)
    candidate_geom = _geometry_union(candidate_gdf.geometry)
    if reference_geom.is_empty or candidate_geom.is_empty:
        return 0.0
    union_area = reference_geom.union(candidate_geom).area
    if union_area == 0:
        return 0.0
    intersection_area = reference_geom.intersection(candidate_geom).area
    iou = float(intersection_area / union_area)
    logger.debug(f"Computed shape IoU: {iou:.4f}")
    return iou


def _geometry_union(geometry):
    if hasattr(geometry, "union_all"):
        return geometry.union_all()
    return geometry.unary_union


def _coords_from_transform(affine_transform, grid_shape):
    """Derive coordinate arrays from an affine transform and grid shape."""
    try:
        from rasterio.transform import Affine, xy
    except Exception as exc:
        error_msg = "rasterio is required to derive coordinates from transform."
        with ErrorLogger(logger):
            raise ImportError(error_msg) from exc

    if not isinstance(affine_transform, Affine):
        try:
            affine_transform = Affine(*affine_transform)
        except Exception:
            affine_transform = Affine.from_gdal(*affine_transform)
    n_rows, n_cols = grid_shape
    col_indices = np.arange(n_cols)
    row_indices = np.arange(n_rows)
    x_coords = np.array(
        [xy(affine_transform, 0, col, offset="center")[0] for col in col_indices]
    )
    y_coords = np.array(
        [xy(affine_transform, row, 0, offset="center")[1] for row in row_indices]
    )
    logger.debug(
        f"Derived coordinate arrays from transform with lengths {len(x_coords)} "
        f"(x) and {len(y_coords)} (y)."
    )
    return x_coords, y_coords


def _combine_shape_bounds(bounds_list):
    """Combine multiple (minx, miny, maxx, maxy) tuples into a single bounding box."""
    if not bounds_list:
        return None
    min_x = min(b[0] for b in bounds_list)
    min_y = min(b[1] for b in bounds_list)
    max_x = max(b[2] for b in bounds_list)
    max_y = max(b[3] for b in bounds_list)
    return min_x, min_y, max_x, max_y


def _buffer_bounds(bounds, min_buffer=0.0, extent_factor=SHAPE_BUFFER_EXTENT_FACTOR):
    """Enlarge bounds to leave room for a catchment reaching beyond the shape.

    The buffer scales with the bounds themselves, because a shape that
    disagrees with the flow direction data is off by a fraction of the
    catchment it describes rather than by a fixed distance. It is derived from
    the half extent of the bounds, so it compares to a search radius.

    Args:
        bounds: Bounding box as (min_x, min_y, max_x, max_y) or None.
        min_buffer (float): Lower limit for the length that is scaled, in the
            unit of the bounds, so the buffer never falls below
            min_buffer * extent_factor.
        extent_factor (float): Multiple of that length added on every side.

    Returns
    -------
        The buffered bounds as tuple, or None if no bounds were given.
    """
    if bounds is None:
        return None
    min_x, min_y, max_x, max_y = bounds
    buffer = max(max(max_x - min_x, max_y - min_y) / 2, min_buffer) * extent_factor
    logger.debug(
        f"Buffering shape bounds by {buffer} "
        f"(extent factor {extent_factor}, minimum scaled length {min_buffer})."
    )
    return (
        min_x - buffer,
        min_y - buffer,
        max_x + buffer,
        max_y + buffer,
    )


def _scale_bounds(bounds, factor):
    """Scale bounds around their centre.

    Args:
        bounds (tuple): Bounding box as (min_x, min_y, max_x, max_y).
        factor (float): Factor applied to width and height.

    Returns
    -------
        The scaled bounds as (min_x, min_y, max_x, max_y).
    """
    min_x, min_y, max_x, max_y = bounds
    centre_x, centre_y = (min_x + max_x) / 2, (min_y + max_y) / 2
    half_width = (max_x - min_x) * factor / 2
    half_height = (max_y - min_y) * factor / 2
    return (
        centre_x - half_width,
        centre_y - half_height,
        centre_x + half_width,
        centre_y + half_height,
    )


def _get_domain_edge_values(grid, sides=None):
    """Get the unique values in the outermost rows and columns of a 2D grid.

    Args:
        grid (np.ndarray): 2D north-up grid, e.g. a basin mask or basin ids.
        sides (iterable of str): Edges to read, any of ``CROP_SIDES``; None
            reads all four.

    Returns
    -------
        np.ndarray of the unique values along the requested grid edges.
    """
    edges = {
        "north": grid[0, :],
        "south": grid[-1, :],
        "west": grid[:, 0],
        "east": grid[:, -1],
    }
    sides = CROP_SIDES if sides is None else list(sides)
    if not sides:
        return np.array([], dtype=grid.dtype)
    return np.unique(np.concatenate([edges[side] for side in sides]))


class _CropTooSmallError(Exception):
    """Signal that the automatic crop cuts off a basin and has to be enlarged.

    Raised inside ``create_catchment``, so the input is closed before
    ``_retry_with_larger_crop`` reruns it with ``larger_bounds``.
    """

    def __init__(self, gauge_ids, larger_bounds, crop_retries_left):
        """Store the gauges cut off by the crop and the bounds of the next crop.

        Args:
            gauge_ids (list): Ids of the gauges whose basin the crop cuts off.
            larger_bounds (tuple): Enlarged crop as (min_x, min_y, max_x, max_y).
            crop_retries_left (int): Retries left for the rerun.
        """
        super().__init__(f"The crop cuts off the basins of gauges {gauge_ids}.")
        self.gauge_ids = gauge_ids
        self.larger_bounds = larger_bounds
        self.crop_retries_left = crop_retries_left


def _retry_with_larger_crop(create_function):
    """Rerun a delineation with a larger crop while it raises _CropTooSmallError.

    Args:
        create_function (callable): ``create_catchment``.

    Returns
    -------
        The wrapped function.
    """

    @functools.wraps(create_function)
    def wrapper(*args, **kwargs):
        while True:
            try:
                return create_function(*args, **kwargs)
            except _CropTooSmallError as crop_error:
                logger.warning(
                    f"Basin of gauge(s) {crop_error.gauge_ids} reaches the edge of "
                    "the cropped domain and may be cut off; repeating the "
                    f"delineation with the crop bounds {crop_error.larger_bounds}."
                )
                kwargs = {
                    **kwargs,
                    "crop_bounds": crop_error.larger_bounds,
                    "crop_retries_left": crop_error.crop_retries_left,
                }

    return wrapper


def _outlet_search_buffer(max_distance_m, max_distance_cells, l0_resolution, latlon):
    """Split the outlet search distance into a grid-unit and a metric buffer.

    The selected outlet may sit that far from the given gauge coordinates, so
    the crop has to reach at least as far to keep every candidate available. A
    distance in cells is already in the unit of the grid, while a distance in
    meters only becomes degrees once the latitude is known.

    Args:
        max_distance_m (float): Maximum radial outlet distance in meters.
        max_distance_cells (int): Maximum outlet distance in grid cells.
        l0_resolution (float): L0 grid resolution.
        latlon (bool): Whether the grid is geographic.

    Returns
    -------
        Tuple of the buffer in the unit of the grid and the buffer in meters,
        both 0 if no distance limit is known.
    """
    if max_distance_m is not None:
        return (0.0, max_distance_m) if latlon else (max_distance_m, 0.0)
    if max_distance_cells is not None and l0_resolution is not None:
        return max_distance_cells * l0_resolution, 0.0
    return 0.0, 0.0


def _slices_from_bounds(bounds, lat_values):
    """Create lon/lat slices from bounds, respecting latitude ordering."""
    if bounds is None:
        return None
    min_x, min_y, max_x, max_y = bounds
    if lat_values[0] > lat_values[-1]:
        lat_slice = slice(max_y, min_y)
    else:
        lat_slice = slice(min_y, max_y)
    lon_slice = slice(min_x, max_x)
    return {"lat": lat_slice, "lon": lon_slice}


def _shape_bounds_from_folder(
    shape_folder, gauge_ids, min_buffer=0.0, min_buffer_m=0.0
):
    """Compute the buffered bounding box of the available gauge shapefiles.

    Args:
        shape_folder: Folder holding the gauge shapefiles.
        gauge_ids: Gauge id or list of gauge ids to look for.
        min_buffer (float): Lower limit for the buffer added around the
            combined bounds, in the unit of the shapefile coordinates.
        min_buffer_m (float): Same lower limit given in meters, converted with
            the latitude of the shape, so it also holds along longitude.

    Returns
    -------
        The bounds as (min_x, min_y, max_x, max_y), or None if none were found.
    """
    if not shape_folder or gauge_ids is None:
        logger.warning(
            f"No shape_folder or gauge_ids provided; cannot compute shape bounds. {shape_folder}, {gauge_ids}"
        )
        return None
    try:
        import geopandas as gpd
    except Exception as exc:
        logger.warning(f"geopandas missing; cannot use shapefile bounds: {exc}")
        return None

    gauge_id_list = [gauge_ids] if not isinstance(gauge_ids, list) else gauge_ids

    bounds_list = []
    logger.debug(
        f"Looking for shapefiles in {shape_folder} for gauge_ids: {gauge_id_list}"
    )
    for gauge_id in gauge_id_list:
        logger.info(f"Looking for shapefile for gauge_id {gauge_id} in {shape_folder}")
        shape_path = _find_shape_file(shape_folder, gauge_id)
        logger.debug(f"Found shapefile {shape_path} for gauge_id {gauge_id}")
        if shape_path is None:
            continue
        try:
            gdf = gpd.read_file(shape_path)
        except Exception as exc:
            logger.warning(f"Failed to read shapefile {shape_path}: {exc}")
            continue
        bounds_list.append(tuple(gdf.total_bounds))

    combined_bounds = _combine_shape_bounds(bounds_list)
    if combined_bounds is None:
        return None
    if min_buffer_m:
        # the shape sits at the latitude where the metric distance has to fit,
        # and its edge further from the equator needs the largest degree span
        shape_latitude = max(abs(combined_bounds[1]), abs(combined_bounds[3]))
        min_buffer = max(
            min_buffer, convert_meters_to_degrees(min_buffer_m, shape_latitude)
        )
    buffered_bounds = _buffer_bounds(combined_bounds, min_buffer)
    logger.info(f"Using buffered shapefile bounds for slicing: {buffered_bounds}")
    return buffered_bounds


def _get_gauge_lists(gauge_ids, gauge_coords, ref_catchment_area):
    """Expand single or listed gauge ids, coordinates and areas to equal-length lists.

    Args:
        gauge_ids: Gauge id, list of gauge ids or None.
        gauge_coords: (lat, lon) tuple, list of tuples or None.
        ref_catchment_area: Area in km2, list of areas or None.

    Returns
    -------
        Tuple of the lists of gauge ids, coordinates and areas, one entry per gauge.
    """
    if isinstance(gauge_coords, list):
        n_gauges = len(gauge_coords)
    elif isinstance(gauge_ids, list):
        n_gauges = len(gauge_ids)
    else:
        n_gauges = 1
    return tuple(
        value if isinstance(value, list) else [value] * n_gauges
        for value in (gauge_ids, gauge_coords, ref_catchment_area)
    )


def _get_area_crop_bounds(
    gauge_coords, ref_area, latlon, min_buffer=0.0, min_buffer_m=0.0
):
    """Create a crop box centred on a gauge and sized from its catchment area.

    Args:
        gauge_coords (tuple): Gauge coordinates as (lat, lon), or (y, x) on
            projected grids.
        ref_area (float): Reference catchment area in km2.
        latlon (bool): Whether the grid is geographic.
        min_buffer (float): Buffer added on every side, in the unit of the grid.
        min_buffer_m (float): Buffer added on every side, in meters.

    Returns
    -------
        The bounds as (min_x, min_y, max_x, max_y), or None without coordinates
        or area.
    """
    if gauge_coords is None or ref_area is None or not np.isfinite(ref_area):
        return None
    lat, lon = gauge_coords
    half_width_m = AREA_CROP_WIDTH_FACTOR * np.sqrt(ref_area) * 1000.0 / 2
    half_width_m += min_buffer_m
    if latlon:
        half_height = convert_meters_to_degrees(half_width_m) + min_buffer
        # a degree of longitude is shortest at the box edge furthest from the equator
        half_width = (
            convert_meters_to_degrees(half_width_m, abs(lat) + half_height) + min_buffer
        )
    else:
        half_height = half_width = half_width_m + min_buffer
    return lon - half_width, lat - half_height, lon + half_width, lat + half_height


def _get_gauge_crop_bounds(
    shape_dir,
    gauge_ids,
    gauge_coords,
    ref_catchment_area,
    latlon,
    min_buffer=0.0,
    min_buffer_m=0.0,
):
    """Compute the crop bounds covering all gauges.

    Gauges with a shapefile use the buffered shape bounds, all others a box
    around their coordinates sized from their reference catchment area.

    Args:
        shape_dir: Directory holding the gauge shapefiles, or None.
        gauge_ids: Gauge id, list of gauge ids or None.
        gauge_coords: (lat, lon) tuple, list of tuples or None.
        ref_catchment_area: Area in km2, list of areas or None.
        latlon (bool): Whether the grid is geographic.
        min_buffer (float): Lower limit for the buffer, in the unit of the grid.
        min_buffer_m (float): Lower limit for the buffer, in meters.

    Returns
    -------
        The bounds as (min_x, min_y, max_x, max_y), or None if any gauge has
        neither a shapefile nor coordinates and an area.
    """
    gauge_id_list, gauge_coord_list, area_list = _get_gauge_lists(
        gauge_ids, gauge_coords, ref_catchment_area
    )
    shape_ids = [
        gauge_id
        for gauge_id in gauge_id_list
        if _find_shape_file(shape_dir, gauge_id) is not None
    ]
    bounds_list = []
    if shape_ids:
        shape_bounds = _shape_bounds_from_folder(
            shape_dir, shape_ids, min_buffer=min_buffer, min_buffer_m=min_buffer_m
        )
        if shape_bounds is not None:
            bounds_list.append(shape_bounds)
    for gauge_id, coords, area in zip(gauge_id_list, gauge_coord_list, area_list):
        if gauge_id is not None and gauge_id in shape_ids:
            continue
        area_bounds = _get_area_crop_bounds(
            coords, area, latlon, min_buffer=min_buffer, min_buffer_m=min_buffer_m
        )
        if area_bounds is None:
            logger.warning(
                f"Gauge {gauge_id} has neither a shapefile nor coordinates and an "
                "area; not cropping the input, which may need a lot of memory."
            )
            return None
        logger.info(
            f"Using a box of {AREA_CROP_WIDTH_FACTOR} x sqrt(area) around gauge "
            f"{gauge_id} for slicing: {area_bounds}"
        )
        bounds_list.append(area_bounds)
    return _combine_shape_bounds(bounds_list)


def _calculate_shape_perimeter_m(reference_shape, latlon):
    """Calculate the perimeter of a reference catchment shape in meters.

    Args:
        reference_shape (geopandas.GeoDataFrame): Reference catchment shape.
        latlon (bool): Whether the shape coordinates are in degrees, used only
            when the shape has no CRS.

    Returns
    -------
        The perimeter of the merged shape geometries in meters.
    """
    # on a projected grid the shape keeps its own CRS, which may be geographic
    is_geographic = (
        reference_shape.crs.is_geographic if reference_shape.crs is not None else latlon
    )
    if is_geographic:
        # degrees have no fixed length, so measure in the local UTM zone
        reference_shape = reference_shape.to_crs(reference_shape.estimate_utm_crs())
    return float(_geometry_union(reference_shape.geometry).length)


def _calculate_auto_max_distance_m(gauge_id, shape_dir, ref_area, latlon):
    """Derive the maximum outlet distance of a gauge from its catchment size.

    The distance is a fraction of the perimeter of the reference shape, or of a
    perimeter approximated from the reference area, clipped to fixed limits.

    Args:
        gauge_id: Gauge id used to find the reference shape, or None.
        shape_dir: Directory holding the gauge shapefiles, or None.
        ref_area (float): Reference catchment area in km2, or None.
        latlon (bool): Whether the shape coordinates are in degrees.

    Returns
    -------
        The maximum outlet distance in meters.
    """
    reference_shape, _ = _read_reference_shape(shape_dir, gauge_id, latlon)
    if reference_shape is not None and not reference_shape.empty:
        perimeter_m = _calculate_shape_perimeter_m(reference_shape, latlon)
        source = "shape perimeter"
    elif ref_area is not None and np.isfinite(ref_area):
        perimeter_m = AREA_PERIMETER_FACTOR * np.sqrt(ref_area) * 1000.0
        source = "perimeter approximated from the area"
    else:
        logger.warning(
            f"Gauge {gauge_id} has neither a shapefile nor an area; using the "
            f"upper limit of {AUTO_MAX_DISTANCE_LIMITS_M[1]:.0f} m as max distance."
        )
        return AUTO_MAX_DISTANCE_LIMITS_M[1]
    max_distance_m = float(
        np.clip(
            AUTO_MAX_DISTANCE_PERIMETER_FACTOR * perimeter_m,
            *AUTO_MAX_DISTANCE_LIMITS_M,
        )
    )
    logger.info(
        f"Derived max outlet distance {max_distance_m:.0f} m for gauge {gauge_id} "
        f"from the {source} of {perimeter_m / 1000.0:.1f} km."
    )
    return max_distance_m


def create_cell_area(ds, lat_name="lat", lon_name="lon"):
    """Create a cell area data array in km2."""
    logger.info("Create cell area data array.")
    lat = ds[lat_name].data
    lon = ds[lon_name].data
    # calculate cellsize in kilometers
    R = EARTH_RADIUS_KM
    lat_rad = np.deg2rad(lat)
    lon_rad = np.deg2rad(lon)
    dlat = np.abs(np.gradient(lat_rad))
    dlon = np.abs(np.gradient(lon_rad))
    # create 2D arrays for lat and lon
    dlat_2d, dlon_2d = np.meshgrid(dlat, dlon, indexing="ij")
    lat_2d = np.tile(lat_rad[:, np.newaxis], (1, len(lon)))
    # calculate area
    cell_areas = R**2 * dlat_2d * dlon_2d * np.cos(lat_2d)
    return xr.DataArray(
        cell_areas,
        coords={lat_name: lat, lon_name: lon},
        dims=[lat_name, lon_name],
        name="cell_area",
        attrs={
            "title": "cell area",
            "units": "km2",
            "creator": "Department of Computational Hydrosystems",
            "institution": "Helmholtz Centre for Environmental Research - UFZ",
        },
    )


def _normalize_output_vars(output_vars):
    if output_vars is None:
        return set(OUTPUT_VARIABLES)
    if isinstance(output_vars, str):
        output_vars = [val.strip() for val in output_vars.split(",") if val.strip()]
    selected = {val.strip() for val in output_vars if str(val).strip()}
    if not selected:
        msg = "output_vars must contain at least one variable name."
        with ErrorLogger(logger):
            raise ValueError(msg)
    unknown = selected - set(OUTPUT_VARIABLES)
    if unknown:
        msg = (
            "Unknown output vars: "
            f"{sorted(unknown)}. Valid options: {', '.join(OUTPUT_VARIABLES)}."
        )
        with ErrorLogger(logger):
            raise ValueError(msg)
    return selected


def _to_numeric_gauge_ids(raw_ids, context="output"):
    """Convert gauge IDs to integers, generating surrogate IDs when needed."""
    if isinstance(raw_ids, (str, bytes)):
        raw_ids = [raw_ids]
    elif not isinstance(raw_ids, list):
        raw_ids = list(raw_ids)
    key_to_numeric = {}
    used_numeric = {}
    surrogate_candidates = []

    for raw in raw_ids:
        key = "" if raw is None else str(raw).strip()
        if key in key_to_numeric:
            continue
        try:
            numeric_id = int(key)
        except (TypeError, ValueError):
            surrogate_candidates.append(key)
            continue
        if numeric_id in used_numeric and used_numeric[numeric_id] != key:
            logger.warning(
                f"Gauge id '{key}' collides with '{used_numeric[numeric_id]}' "
                f"after int conversion for {context}; using surrogate id."
            )
            surrogate_candidates.append(key)
            continue
        key_to_numeric[key] = numeric_id
        used_numeric[numeric_id] = key

    next_surrogate = max(used_numeric) + 1 if used_numeric else 1
    for key in surrogate_candidates:
        if key in key_to_numeric:
            continue
        while next_surrogate in used_numeric:
            next_surrogate += 1
        key_to_numeric[key] = next_surrogate
        used_numeric[next_surrogate] = key
        logger.warning(
            f"Gauge id '{key if key else '<empty>'}' is non-numeric for {context}; "
            f"using surrogate id {next_surrogate}."
        )
        next_surrogate += 1

    return [key_to_numeric["" if raw is None else str(raw).strip()] for raw in raw_ids]


def write_gauges_out(gauges, output_target):
    """Write gauge information to CSV and NetCDF files."""
    write_gauges_to_csv(gauges, output_target.with_suffix(".csv"))
    write_gauges_to_nc(gauges, output_target.with_suffix(".nc"))


def write_gauges_to_csv(gauges, output_target, filename="gauges_info.csv"):
    """Write gauge information to a CSV file.

    Parameters
    ----------
    gauges : Gauge | list[Gauge] | dict | list[dict]
        Gauge objects or dict rows.
    output_target : str | Path
        Either a target file path or a target directory.
    filename : str
        Filename used when output_target is a directory.

    Notes
    -----
    `distance` is the shift of the outlet in km, `area` the upstream area at
    the delineated outlet and `old_area` the reference area in km2, and
    `area_error` their relative difference. `score` is the value the method in
    `method` ranked its candidates by and compared against `max_error`: the
    `shape_error` (`1 - IoU`, therefore identical to it) for `shape_iou`, the
    area error for `area_basinex`, and the area error weighed against the
    outlet distance for `area_burek`. Unknown values are written as `nan`.
    """
    if not gauges:
        logger.warning("No gauges to write to CSV.")
        return
    if isinstance(gauges, (Gauge, dict)):
        gauges = [gauges]

    output_target = Path(output_target)
    if output_target.is_dir() or not output_target.suffix:
        output_path = output_target / str(filename)
    else:
        output_path = output_target

    output_path.parent.mkdir(parents=True, exist_ok=True)

    rows = []
    for gauge in gauges:
        if isinstance(gauge, dict):
            row = {
                "id": gauge.get("id", gauge.get("gauge_id")),
                "lon": gauge.get("lon"),
                "lat": gauge.get("lat"),
                "lon_old": gauge.get("lon_old"),
                "lat_old": gauge.get("lat_old"),
                "distance": gauge.get("distance", gauge.get("distance_error", np.nan)),
                "area": gauge.get("area"),
                "old_area": gauge.get("old_area", gauge.get("area_old")),
                "area_error": gauge.get("area_error", gauge.get("error", np.nan)),
                "score": gauge.get("score", np.nan),
                "shape_error": gauge.get("shape_error", np.nan),
                "method": gauge.get("method", gauge.get("used_method")),
            }
        else:
            row = {
                "id": gauge.gauge_id,
                "lon": gauge.lon,
                "lat": gauge.lat,
                "lon_old": gauge.lon_old,
                "lat_old": gauge.lat_old,
                "distance": gauge.distance_error,
                "area": gauge.area,
                "old_area": gauge.area_old,
                "area_error": gauge.area_error,
                "score": gauge.score,
                "shape_error": gauge.shape_error,
                "method": gauge.method,
            }
        rows.append(_fill_missing_numbers(row))

    with output_path.open("w", newline="", encoding="utf-8") as fp:
        writer = csv.DictWriter(fp, fieldnames=GAUGE_INFO_COLUMNS)
        writer.writeheader()
        writer.writerows(rows)
    logger.info(f"Wrote gauge information for {len(rows)} gauges to {output_path}")


def write_gauges_to_nc(gauges, output_target, filename="gauges_info.nc"):
    """Write gauge information to a NetCDF file with CF-style station metadata.

    Parameters
    ----------
    gauges : Gauge | list[Gauge] | dict | list[dict]
        Gauge objects or dict rows.
    output_target : str | Path
        Either a target file path or a target directory.
    filename : str
        Filename used when output_target is a directory.
    """
    if not gauges:
        logger.warning("No gauges to write to NetCDF.")
        return
    if isinstance(gauges, (Gauge, dict)):
        gauges = [gauges]

    output_target = Path(output_target)
    if output_target.is_dir() or not output_target.suffix:
        output_path = output_target / str(filename)
    else:
        output_path = output_target

    output_path.parent.mkdir(parents=True, exist_ok=True)

    station_ids_raw = []
    lons = []
    lats = []
    areas = []
    methods = []
    for gauge in gauges:
        if isinstance(gauge, dict):
            station_id = gauge.get("gauge_id", gauge.get("id"))
            lon = gauge.get("lon")
            lat = gauge.get("lat")
            area = gauge.get("area")
            method = gauge.get("method", gauge.get("used_method"))
        else:
            station_id = gauge.gauge_id
            lon = gauge.lon
            lat = gauge.lat
            area = gauge.area
            method = gauge.method

        methods.append(method)
        station_ids_raw.append(station_id)
        lons.append(np.nan if lon is None else float(lon))
        lats.append(np.nan if lat is None else float(lat))
        areas.append(np.nan if area is None else float(area))

    if not station_ids_raw:
        logger.warning("No gauge ids available for NetCDF output.")
        return
    station_ids = _to_numeric_gauge_ids(station_ids_raw, context="gauges_info.nc")

    station = np.asarray(station_ids, dtype=np.int64)
    ds = xr.Dataset(
        data_vars={
            "lon": ("station", np.asarray(lons, dtype=np.float64)),
            "lat": ("station", np.asarray(lats, dtype=np.float64)),
            "area": ("station", np.asarray(areas, dtype=np.float64)),
        },
        coords={"station": ("station", station)},
        attrs={
            "title": "SCC gauges specification",
            "Conventions": "CF-1.12",
            "institution": "UFZ",
            "source": "Catchment delineation with mhm-tools",
        },
    )

    ds["station"].attrs.update(
        {
            "long_name": "Station ID",
            "coordinates": "lon lat",
        }
    )
    ds["lon"].attrs.update(
        {
            "long_name": "longitude",
            "standard_name": "longitude",
            "units": "degrees_east",
        }
    )
    ds["lat"].attrs.update(
        {
            "long_name": "latitude",
            "standard_name": "latitude",
            "units": "degrees_north",
        }
    )
    used_methods = sorted({method for method in methods if method})
    ds["area"].attrs.update(
        {
            "standard_name": "catchment_area",
            "long_name": "upstream area at the delineated outlet cell",
            "units": "km2",
            "delineation": (
                "outlet matched by "
                + (", ".join(used_methods) if used_methods else "unknown method")
                + "; shape_iou maximizes the overlap with a reference catchment "
                "shape, area_basinex minimizes the upstream area error, "
                "area_burek weighs the area error against the outlet distance "
                "(Burek et al. 2023)"
            ),
        }
    )

    encoding = {
        "station": {"dtype": "int64"},
        "lon": {"dtype": "float64", "_FillValue": np.nan},
        "lat": {"dtype": "float64", "_FillValue": np.nan},
        "area": {"dtype": "float64", "_FillValue": np.nan},
    }
    ds = apply_output_provenance(ds)
    ds.to_netcdf(output_path, engine="netcdf4", format="NETCDF4", encoding=encoding)
    logger.info(
        f"Wrote gauge information for {len(station_ids)} gauges to {output_path}"
    )


# CLASSES


class Gauge:
    """Class to hold gauge information."""

    def __init__(self, gauge_id=None, lat=None, lon=None, area=None, id=None):
        if gauge_id is None:
            gauge_id = id
        self.gauge_id = gauge_id
        # Backward-compatible alias for older call sites using `gauge.id`.
        self.id = gauge_id
        self.lat = lat
        self.lon = lon
        self.area = area
        self.area_old = None
        self.lat_old = None
        self.lon_old = None
        self.distance_error = np.nan
        self.area_error = np.nan
        self.score = np.nan
        self.shape_error = np.nan
        self.method = None

    def update(
        self,
        area=None,
        lat=None,
        lon=None,
        distance_error=None,
        area_error=None,
        score=None,
        shape_error=None,
        method=None,
    ):
        """Update gauge information, preserving old values."""
        if area is not None:
            self.area_old = self.area
            self.area = area
        if lat is not None:
            self.lat_old = self.lat
            self.lat = lat
        if lon is not None:
            self.lon_old = self.lon
            self.lon = lon
        if distance_error is not None:
            self.distance_error = distance_error
        if area_error is not None:
            self.area_error = area_error
        if score is not None:
            self.score = score
        if shape_error is not None:
            self.shape_error = shape_error
        if method is not None:
            self.method = method


class Catchment:
    """Catchment class deliniating catchmetns with pyflowdir."""

    def __init__(
        self,
        ds,
        var_name,
        var="data",
        ftype=None,
        transform=None,
        out_var_name=None,
        do_shift=False,
        resolutions: Resolution = None,
        upscale=False,
        latlon=True,
        l0_precision: int = 12,
    ):
        self.flwdir = None
        self.basin = None
        self.upgrid = None
        self.uparea_grid = None
        self.grdare = None
        self.elevtn = None
        self.cell_area = None
        self._fdir = None
        self.gauge_ids = []
        self.gauge_lats = []
        self.gauge_lons = []
        self.ftype = ftype
        self.catchment_mask = None
        self.touches_domain_edge = False
        # sides where an automatic crop cut the input, set by create_catchment
        self.crop_edge_sides = ()
        self.touches_crop_edge = False
        self.resolutions = resolutions if resolutions is not None else Resolution()
        if self.resolutions.l0 is None:
            # 12 decimals: 9 left 1/600 off by 2e-7, which an upscaling factor of 60
            # turned into a ratio of 59.99999; the value also names gauges_info files
            self.resolutions.l0 = round(
                calculate_coordinate_resolution(ds.lon), l0_precision
            )
        self.upscaled_resolution = self.resolutions.l0
        self.do_upscale = upscale
        self.is_upscaled = False
        self.out_var_name = (
            out_var_name if out_var_name is not None else f"{var_name}.nc"
        )
        self.VARIABLES = {
            "flwdir": {
                "title": f"flow direction ({self.ftype.upper()})",
                "_FillValue": FDIR_FILLVALUE[self.ftype],
                "units": "-",
            },
            "basin": {
                "title": "basin Id",
                "_FillValue": 0,
                "units": "-",
            },
            "uparea_grid": {
                "title": "accumulated data values along the flow directions",
                "_FillValue": FACC_FILLVALUE,
                "units": "-",
            },
            "upgrid": {
                "title": "upstream area",
                "_FillValue": FACC_FILLVALUE,
                "units": "km2",
            },
            "grdare": {
                "title": "rectangular grid area",
                "_FillValue": FILLVALUE,
                "units": "m2",
            },
            "elevtn": {
                "title": "outlet pixel elevation",
                "_FillValue": float(FILLVALUE),
                "units": "m",
            },
        }
        if not isinstance(self.out_var_name, str):
            self.out_var_name = f"{var_name}.nc"
        self.do_shift = do_shift
        self.latlon = latlon
        self.ds = ds
        logger.debug(f"self.ds: {self.ds}")
        self.transform = transform

        data = self._modify_data(self.ds[var_name])

        if self.do_shift:
            transform = list(self.transform)
            transform[2] = 0
            self.transform = tuple(transform)

        self.input_da = data

        self.input_da = data

        if var == "fdir":
            if "nodata_value" in self.input_da.attrs:
                old_no_data_val = self.input_da.attrs["nodata_value"]
            elif "_FillValue" in self.input_da.attrs:
                old_no_data_val = self.input_da.attrs["_FillValue"]
            elif "missing_value" in self.input_da.attrs:
                old_no_data_val = self.input_da.attrs["missing_value"]
            else:
                old_no_data_val = np.nan
            self.input_da.attrs["_FillValue"] = FDIR_FILLVALUE[ftype]
            self.input_da.attrs["nodata_value"] = FDIR_FILLVALUE[ftype]
            self.input_da = self.input_da.where(
                (data != old_no_data_val) & ~np.isnan(data),
                FDIR_FILLVALUE[ftype],
            )
            logger.debug(self.input_da)
            self.add_fdir(latlon=latlon)
        elif var == "dem":
            self.add_dem(latlon=latlon)
        else:
            with ErrorLogger(logger):
                raise NotImplementedError

    def _modify_data(self, data):
        # correct circumspanning data
        if self.do_shift:
            shift = int(data.shape[1] / 2)
            if isinstance(data, xr.DataArray):
                return data.roll({data.dims[1]: shift}, roll_coords=False)
            return np.roll(data, shift, axis=1)
        return data

    def _revert_data(self, data):
        # correct circumspanning data
        if self.do_shift:
            return np.roll(data, int(data.shape[1] / 2), axis=1)
        return data

    def add_dem(self, latlon):
        """Init the FlwdirRaster class from dem."""
        # perform checks
        # self.input_ds = fill_nan_with_neighbors(self.input_ds)
        # pyflwdir needs numpy; .values also loads a dask array from chunked reading
        self.elevtn = self.input_da.values
        if self._fdir is None:
            # Create a flow direction object
            logger.info("add_dem")
            self._fdir = pyflwdir.from_dem(
                data=self.elevtn,
                nodata=np.nan,
                transform=self.transform,
                latlon=latlon,
            )
            self.get_fdir()

    def add_fdir(self, latlon):
        """Init the FlwdirRaster class from fdir."""
        # pyflwdir needs numpy; .values also loads a dask array from chunked reading
        data = self.input_da.values
        if self._fdir is None:
            data = data.astype(np.uint8)
            self._fdir = pyflwdir.from_array(
                data=data, ftype=self.ftype, transform=self.transform, latlon=latlon
            )
        self.get_fdir()

    def get_current_coordinates(self):
        """Build L1 coordinate arrays based on the dataset extent and L1 resolution."""
        lon_coords = self.ds.lon.data
        lat_coords = self.ds.lat.data
        input_resolution = self.resolutions.l0
        if (
            self.resolutions.l1 is not None
            and input_resolution != self.resolutions.l1
            and self.do_upscale
            and self.is_upscaled
        ):
            # Rebuild coordinates for the coarser L1 grid
            lon_coords = np.arange(
                lon_coords.min() - input_resolution / 2 + self.resolutions.l1 / 2,
                lon_coords.max() + self.resolutions.l1 / 2,
                self.resolutions.l1,
            )
            lat_coords = np.arange(
                lat_coords.max() + input_resolution / 2 - self.resolutions.l1 / 2,
                lat_coords.min() - self.resolutions.l1 / 2,
                -self.resolutions.l1,
            )
        logger.debug(
            f"Computed L1 coords: lon={len(lon_coords)}, lat={len(lat_coords)}"
        )
        return lon_coords, lat_coords

    def compute_cell_area(self):
        """Create a cell area data array in km2."""
        logger.info("Create cell area data array.")
        lon, lat = self.get_current_coordinates()
        if not self.latlon:
            # projected coordinates are taken as metres, like max_distance_m,
            # which makes every cell a plain rectangle of height times width
            cell_heights_km = np.abs(np.gradient(lat)) / 1000
            cell_widths_km = np.abs(np.gradient(lon)) / 1000
            self.cell_area = np.outer(cell_heights_km, cell_widths_km)
            return
        # calculate cellsize in kilometers
        R = EARTH_RADIUS_KM
        lat_rad = np.deg2rad(lat)
        lon_rad = np.deg2rad(lon)
        dlat = np.abs(np.gradient(lat_rad))
        dlon = np.abs(np.gradient(lon_rad))
        # create 2D arrays for lat and lon
        dlat_2d, dlon_2d = np.meshgrid(dlat, dlon, indexing="ij")
        lat_2d = np.tile(lat_rad[:, np.newaxis], (1, len(lon)))
        # calculate area
        cell_areas = R**2 * dlat_2d * dlon_2d * np.cos(lat_2d)
        self.cell_area = cell_areas

    def calc_upstream_area(self):
        """Use pyflwdir to calculate the upstream area from flow direction by providing cell areas."""
        if self._fdir is None:
            logger.error("Flow direction is not initialized.")
            return None
        if self.cell_area is None:
            self.compute_cell_area()
        if self.cell_area.shape != self._fdir.shape:
            msg = (
                f"cell_area shape {self.cell_area.shape} does not match "
                f"flow-direction shape {self._fdir.shape}."
            )
            with ErrorLogger(logger):
                raise ValueError(msg)
        return self._fdir.accuflux(self.cell_area, nodata=-9999)

    def check_candidate_basins_reach_crop_edge(
        self, gauge_coords, max_distance_cells=None, max_distance_m=None
    ):
        """Check whether a crop edge cuts the basin of any outlet candidate of a gauge.

        Args:
            gauge_coords (tuple): Gauge coordinates as (lat, lon), or (y, x).
            max_distance_cells (int): Search radius in cells, or None.
            max_distance_m (float): Search radius in meters, or None.

        Returns
        -------
            bool: True if a basin of a cell in the search window reaches one of
            the ``crop_edge_sides``.
        """
        if not self.crop_edge_sides or gauge_coords is None:
            return False
        gauge_row, gauge_col = self._coord_to_index(gauge_coords[0], gauge_coords[1])
        row_min, _, col_min, _, distance_mask, _ = get_candidate_search_window(
            self.ds.lat.data,
            self.ds.lon.data,
            gauge_row,
            gauge_col,
            max_distance_cells=max_distance_cells,
            max_distance_m=max_distance_m,
            latlon=self.latlon,
        )
        window_rows, window_cols = np.nonzero(distance_mask)
        candidate_idxs = np.ravel_multi_index(
            (window_rows + row_min, window_cols + col_min), self._fdir.shape
        )
        candidate_basins = self._fdir.basins(idxs=candidate_idxs.astype(np.int64))
        return bool(
            np.any(_get_domain_edge_values(candidate_basins, self.crop_edge_sides))
        )

    def _coord_to_index(self, lat, lon, lat_vals=None, lon_vals=None):
        """Map latitude/longitude or indices to integer grid indices."""
        if "lat" not in self.ds.coords or "lon" not in self.ds.coords:
            msg = "Dataset is missing latitude/longitude coordinates."
            with ErrorLogger(logger):
                raise ValueError(msg)
        lat_vals = self.ds.lat.data if lat_vals is None else lat_vals
        lon_vals = self.ds.lon.data if lon_vals is None else lon_vals

        if isinstance(lat, (int, np.integer)):
            i = int(lat)
            logger.debug(
                f"Was given latitude index {i} directly. Corresponding lat_value {lat_vals[i]}"
            )
        elif lat < min(lat_vals) or lat > max(lat_vals):
            logger.error(
                f"Given latitude {lat} is outside dataset bounds ({min(lat_vals)}, {max(lat_vals)}). Clipping to bounds."
            )
            i = None
        else:
            i = int(np.abs(lat_vals - float(lat)).argmin())
            logger.debug(
                f"Mapped latitude {float(lat)} to index {i} with lat_value {lat_vals[i]}"
            )

        if isinstance(lon, (int, np.integer)):
            j = int(lon)
            logger.debug(
                f"Was given longitude index {j} directly. Corresponding lon_value {lon_vals[j]}"
            )
        elif lon < min(lon_vals) or lon > max(lon_vals):
            logger.error(
                f"Given longitude {lon} is outside dataset bounds ({min(lon_vals)}, {max(lon_vals)}). Clipping to bounds."
            )
            j = None
        else:
            j = int(np.abs(lon_vals - float(lon)).argmin())
            logger.debug(
                f"Mapped longitude {float(lon)} to index {j} with lon_value {lon_vals[j]}"
            )
        if i is None or j is None:
            msg = (
                "Could not map given coordinates to valid indices within "
                "dataset bounds."
            )
            with ErrorLogger(logger):
                raise ValueError(msg)
        i = int(np.clip(i, 0, len(lat_vals) - 1))
        j = int(np.clip(j, 0, len(lon_vals) - 1))

        return i, j

    def _coords_in_domain(self, gauge_coords, lat_vals=None, lon_vals=None):
        """Check whether gauge coordinates can be mapped to the active domain."""
        if gauge_coords is None:
            return False
        lat_vals = self.ds.lat.data if lat_vals is None else lat_vals
        lon_vals = self.ds.lon.data if lon_vals is None else lon_vals
        lat, lon = gauge_coords
        lat_valid = (
            0 <= lat < len(lat_vals)
            if isinstance(lat, (int, np.integer))
            else min(lat_vals) <= lat <= max(lat_vals)
        )
        lon_valid = (
            0 <= lon < len(lon_vals)
            if isinstance(lon, (int, np.integer))
            else min(lon_vals) <= lon <= max(lon_vals)
        )
        return lat_valid and lon_valid

    def _coords_l1(self):
        """Build L1 coordinate arrays based on the dataset extent and L1 resolution."""
        lon_coords = self.ds.lon.data
        lat_coords = self.ds.lat.data
        input_resolution = self.resolutions.l0
        if (
            self.resolutions.l1 is not None
            and input_resolution != self.resolutions.l1
            and self.do_upscale
        ):
            # Rebuild coordinates for the coarser L1 grid
            lon_coords = np.arange(
                lon_coords.min() - input_resolution / 2 + self.resolutions.l1 / 2,
                lon_coords.max() + self.resolutions.l1 / 2,
                self.resolutions.l1,
            )
            lat_coords = np.arange(
                lat_coords.max() + input_resolution / 2 - self.resolutions.l1 / 2,
                lat_coords.min() - self.resolutions.l1 / 2,
                -self.resolutions.l1,
            )
        logger.debug(
            f"Computed L1 coords: lon={len(lon_coords)}, lat={len(lat_coords)}"
        )
        return lon_coords, lat_coords

    def update_gauge_coords(self, gauge_id, gauge_lat, gauge_lon):
        """Update stored gauge coordinates for a gauge_id or add it if missing."""
        if gauge_id is None:
            return
        if gauge_id in self.gauge_ids:
            gauge_index = self.gauge_ids.index(gauge_id)
            self.gauge_lats[gauge_index] = gauge_lat
            self.gauge_lons[gauge_index] = gauge_lon
            logger.debug(f"Updated gauge {gauge_id} to {gauge_lat}/{gauge_lon}")
        else:
            self.gauge_ids.append(gauge_id)
            self.gauge_lats.append(gauge_lat)
            self.gauge_lons.append(gauge_lon)
            logger.debug(f"Added gauge {gauge_id} at {gauge_lat}/{gauge_lon}")

    def correct_gauge_location_l1_from_shape(
        self,
        l0_shape_gdf,
        gauge_coords,
        max_distance_cells=None,
        max_distance_m=None,
        max_error=0.5,
        use_max_error=True,
        ref_catchment_area=None,
        reference_upstream_area=None,
    ):
        """Correct gauge coordinates at L1 using L0 shape similarity and upstream area."""
        if max_distance_cells is None and max_distance_m is None:
            max_distance_cells = 5
        if ref_catchment_area is None and reference_upstream_area is not None:
            ref_catchment_area = reference_upstream_area
        if l0_shape_gdf is None or l0_shape_gdf.empty:
            return None
        if self._fdir is None:
            return None
        lon_coords, lat_coords = self._coords_l1()
        if (
            len(lat_coords) != self._fdir.shape[0]
            or len(lon_coords) != self._fdir.shape[1]
        ):
            lon_coords, lat_coords = _coords_from_transform(
                getattr(self._fdir, "transform", self.transform), self._fdir.shape
            )

        l1_upstream_area = self.uparea_grid
        if l1_upstream_area is None:
            logger.warning(
                "L1 upstream area grid missing; cannot apply shape correction."
            )
            return None
        l1_result = self.find_best_gauge_location_shape(
            upstream_area=l1_upstream_area,
            gauge_coords=gauge_coords,
            ref_catchment_area=ref_catchment_area,
            shape_folder=None,
            gauge_id=None,
            max_distance_cells=max_distance_cells,
            max_distance_m=max_distance_m,
            max_error=max_error,
            use_max_error=use_max_error,
            reference_shape_gdf=l0_shape_gdf,
            lat_values=lat_coords,
            lon_values=lon_coords,
        )
        if l1_result is None:
            logger.warning("No L1 candidate basins matched the L0 shape.")
            return None

        def _iou_for_index(row_idx, col_idx):
            try:
                linear_idx = np.ravel_multi_index((row_idx, col_idx), self._fdir.shape)
                basin = self._fdir.basins(idxs=np.array([linear_idx], dtype=np.int64))
                candidate_mask = basin > 0
                gdf = _vectorize_mask_to_gdf(
                    candidate_mask,
                    getattr(self._fdir, "transform", self.transform),
                    _shape_crs(self.latlon),
                )
                return _shape_iou(l0_shape_gdf, gdf)
            except Exception as exc:
                logger.debug(
                    f"Could not compute L1 shape IoU for outlet candidate: {exc}"
                )
                return np.nan

        best_candidate_index = l1_result[0]
        candidate_iou = _iou_for_index(
            int(best_candidate_index[0]), int(best_candidate_index[1])
        )

        gauge_row = int(np.abs(lat_coords - float(gauge_coords[0])).argmin())
        gauge_col = int(np.abs(lon_coords - float(gauge_coords[1])).argmin())
        naive_iou = _iou_for_index(gauge_row, gauge_col)

        if (
            np.isfinite(candidate_iou)
            and np.isfinite(naive_iou)
            and candidate_iou < naive_iou
        ):
            logger.info(
                f"L1 shape candidate IoU {candidate_iou:.4f} is worse than naive "
                f"IoU {naive_iou:.4f}; keeping naive L1 gauge location."
            )
            return float(lat_coords[gauge_row]), float(lon_coords[gauge_col])

        new_lat = float(lat_coords[int(best_candidate_index[0])])
        new_lon = float(lon_coords[int(best_candidate_index[1])])
        logger.info(
            f"L1 shape-based correction selected {new_lat:.4f}/{new_lon:.4f} "
            "using L0 shape reference."
        )
        return new_lat, new_lon

    def derive_gauge_coords_from_shape(
        self,
        upstream_area,
        reference_shape,
        lat_values=None,
        lon_values=None,
        shape_label="reference shape",
    ):
        """Use the highest upstream area inside a shape as initial gauge location."""
        if upstream_area is None:
            logger.warning(
                "Upstream area grid missing; cannot derive gauge from shape."
            )
            return None
        if lat_values is None or lon_values is None:
            lat_values = self.ds.lat.data
            lon_values = self.ds.lon.data
        shape_mask = _rasterize_shape_to_mask(
            reference_shape,
            upstream_area.shape,
            getattr(self._fdir, "transform", self.transform),
        )
        if shape_mask is None or not np.any(shape_mask):
            logger.warning(f"Could not rasterize {shape_label} onto the active grid.")
            return None
        candidates = shape_mask & np.isfinite(upstream_area)
        if not np.any(candidates):
            logger.warning(f"No finite upstream-area cells inside {shape_label}.")
            return None
        values = np.where(candidates, upstream_area, -np.inf)
        row_idx, col_idx = np.unravel_index(np.nanargmax(values), values.shape)
        gauge_lat = float(lat_values[int(row_idx)])
        gauge_lon = float(lon_values[int(col_idx)])
        logger.info(
            f"Derived gauge location {gauge_lat:.6f}/{gauge_lon:.6f} from highest "
            f"upstream area inside {shape_label}."
        )
        return gauge_lat, gauge_lon

    def calculate_shape_area_on_current_grid(
        self,
        reference_shape,
        shape_label="reference shape",
    ):
        """Calculate the area covered by a shape on the current grid in km2."""
        if reference_shape is None or getattr(reference_shape, "empty", False):
            return None
        if self._fdir is None:
            logger.warning(
                "Flow direction is not initialized; cannot calculate shape area."
            )
            return None
        if self.cell_area is None:
            self.compute_cell_area()
        shape_area = _calculate_shape_area_on_grid(
            reference_shape,
            self.cell_area,
            self._fdir.shape,
            getattr(self._fdir, "transform", self.transform),
        )
        if shape_area is None:
            logger.warning(
                f"Could not calculate area covered by {shape_label} on the current "
                "grid."
            )
            return None
        logger.info(
            f"Calculated {shape_area:.2f} km2 covered by {shape_label} on the "
            "current grid."
        )
        return shape_area

    def find_best_gauge_location_shape(  # noqa: PLR0911, PLR0912, PLR0915
        self,
        upstream_area,
        gauge_coords,
        ref_catchment_area,
        shape_folder,
        gauge_id,
        max_distance_cells=None,
        max_distance_m=None,
        max_error=0.25,
        reference_shape_gdf=None,
        lat_values=None,
        lon_values=None,
        use_max_error=True,
        started_from_shape=False,
        rejected_candidate=None,
    ):
        """Find best gauge location using shape similarity.

        If the best candidate is rejected for exceeding max_error, its shape
        error and areas are written to the dict passed as rejected_candidate.
        """
        if max_distance_cells is None and max_distance_m is None:
            max_distance_cells = 2
        if upstream_area is None:
            logger.warning("Upstream area grid missing for shape-based correction.")
            return None
        if reference_shape_gdf is None:
            reference_shape, shape_path = _read_reference_shape(
                shape_folder, gauge_id, self.latlon
            )
            if reference_shape is None:
                logger.debug(f"No reference shapefile found for gauge_id {gauge_id}")
                return None
            shape_label = shape_path.name
            crs = _shape_crs(self.latlon)
        else:
            reference_shape = reference_shape_gdf
            shape_label = "reference shape"
            crs = reference_shape.crs if hasattr(reference_shape, "crs") else None

        if lat_values is None or lon_values is None:
            lat_values = self.ds.lat.data
            lon_values = self.ds.lon.data

        if ref_catchment_area is None:
            ref_catchment_area = self.calculate_shape_area_on_current_grid(
                reference_shape,
                shape_label=shape_label,
            )
        if gauge_coords is None:
            started_from_shape = True
            gauge_coords = self.derive_gauge_coords_from_shape(
                upstream_area,
                reference_shape,
                lat_values=lat_values,
                lon_values=lon_values,
                shape_label=shape_label,
            )
            if gauge_coords is None:
                return None

        try:
            gauge_row, gauge_col = self._coord_to_index(
                gauge_coords[0],
                gauge_coords[1],
                lat_vals=lat_values,
                lon_vals=lon_values,
            )
        except ValueError:
            logger.warning(
                f"Gauge coordinates {gauge_coords} are outside the active domain; "
                f"deriving gauge from {shape_label}."
            )
            started_from_shape = True
            gauge_coords = self.derive_gauge_coords_from_shape(
                upstream_area,
                reference_shape,
                lat_values=lat_values,
                lon_values=lon_values,
                shape_label=shape_label,
            )
            if gauge_coords is None:
                return None
            gauge_row, gauge_col = self._coord_to_index(
                gauge_coords[0],
                gauge_coords[1],
                lat_vals=lat_values,
                lon_vals=lon_values,
            )
        row_min, row_max, col_min, col_max, distance_mask, distances_m = (
            get_candidate_search_window(
                lat_values,
                lon_values,
                gauge_row,
                gauge_col,
                max_distance_cells=max_distance_cells,
                max_distance_m=max_distance_m,
                latlon=self.latlon,
            )
        )

        # Limit candidate search to a local neighborhood around the gauge
        sub = upstream_area[row_min : row_max + 1, col_min : col_max + 1]
        candidate_mask = distance_mask & np.isfinite(sub)
        if ref_catchment_area is not None and not use_max_error:
            # Limit candidates to those with upstream area within a factor of the reference area
            # reduce runtime
            area_min = ref_catchment_area * CANDIDATE_AREA_AGREEMENT_FACTOR
            area_max = ref_catchment_area / CANDIDATE_AREA_AGREEMENT_FACTOR
            plausible_mask = candidate_mask & (sub > area_min) & (sub < area_max)
            if np.any(plausible_mask):
                candidate_mask = plausible_mask
                logger.debug(
                    f"Restricted candidates to an upstream area between "
                    f"{area_min:.2f} and {area_max:.2f} km2 (reference "
                    f"{ref_catchment_area:.2f} km2)."
                )
            else:
                logger.warning(
                    f"No candidate drains between {area_min:.2f} and "
                    f"{area_max:.2f} km2; keeping every candidate within the "
                    "search distance."
                )
        if ref_catchment_area is not None and use_max_error:
            delimited_mask = (
                candidate_mask
                & (sub >= ref_catchment_area * (1 - max_error))
                & (sub <= ref_catchment_area * (1 + max_error))
            )
            if np.any(delimited_mask):
                candidate_mask = delimited_mask
            else:
                logger.warning(
                    "No candidates within area error bounds; expanding search to all finite upstream area values."
                )
        candidate_indices = np.where(candidate_mask)

        logger.debug(
            f"Shape-based candidate count: {len(candidate_indices[0])}",
        )

        best_candidate_index = None
        best_candidate_score = np.inf
        best_candidate_shape_iou = 0.0
        best_candidate_upstream_area = None
        best_candidate_distance_100m = None
        logger.debug(
            f"Using resolution {self.upscaled_resolution} for shape-based distance scoring."
        )
        lat_deg = float(lat_values[gauge_row]) if self.latlon else None
        for cand_row, cand_col in zip(candidate_indices[0], candidate_indices[1]):
            row_idx = int(cand_row + row_min)
            col_idx = int(cand_col + col_min)
            linear = np.ravel_multi_index((row_idx, col_idx), self._fdir.shape)
            basin = self._fdir.basins(
                idxs=np.array([linear], dtype=np.int64),
                # streams=streams_mask,
            )
            basin_mask = basin > 0
            if not np.any(basin_mask):
                continue
            basin_transform = getattr(self._fdir, "transform", self.transform)
            gdf = _vectorize_mask_to_gdf(
                basin_mask, basin_transform, crs, value_name="basin"
            )
            shape_overlap_ratio = _shape_iou(reference_shape, gdf)
            upstream_value = upstream_area[row_idx, col_idx]
            distance_100m = (
                distances_m[cand_row, cand_col] / 100
                if distances_m is not None
                else distance_100m_units(
                    row_idx - gauge_row,
                    col_idx - gauge_col,
                    l0_resolution=self.upscaled_resolution,
                    lat_deg=lat_deg,
                )
            )
            # the IoU already carries the area discrepancy, as it can never
            # exceed the ratio of the smaller to the larger of the two areas,
            # so the area only scores candidates where no shape is available
            score = 1 - shape_overlap_ratio
            if (
                best_candidate_index is None
                or score < best_candidate_score
                or (
                    np.isclose(score, best_candidate_score)
                    and best_candidate_distance_100m is not None
                    and distance_100m < best_candidate_distance_100m
                )
            ):
                best_candidate_index = (row_idx, col_idx)
                best_candidate_score = score
                best_candidate_shape_iou = shape_overlap_ratio
                best_candidate_upstream_area = upstream_value
                best_candidate_distance_100m = distance_100m

        if (
            ref_catchment_area is None
            and best_candidate_shape_iou <= 0
            and not started_from_shape
        ):
            derived_coords = self.derive_gauge_coords_from_shape(
                upstream_area,
                reference_shape,
                lat_values=lat_values,
                lon_values=lon_values,
                shape_label=shape_label,
            )
            if derived_coords is None:
                logger.warning(
                    f"No shape-overlap candidate found around {gauge_coords} and no "
                    "shape-derived start could be computed."
                )
                return None
            logger.warning(
                f"No shape-overlap candidate found around gauge coordinates {gauge_coords}; "
                f"retrying from highest upstream-area cell inside {shape_label}.",
            )
            return self.find_best_gauge_location_shape(
                upstream_area,
                derived_coords,
                ref_catchment_area,
                shape_folder,
                gauge_id,
                max_distance_cells=max_distance_cells,
                max_distance_m=max_distance_m,
                max_error=max_error,
                reference_shape_gdf=reference_shape,
                lat_values=lat_values,
                lon_values=lon_values,
                use_max_error=use_max_error,
                started_from_shape=True,
                rejected_candidate=rejected_candidate,
            )
        # the delimiter decides whether a poor overlap disqualifies a candidate
        # or only ranks it, the same role the area error plays in the area based
        # search, and the score is 1 - IoU so the cutoff is a minimum IoU
        min_shape_iou = 1 - max_error
        if best_candidate_index is None or (
            use_max_error and best_candidate_shape_iou < min_shape_iou
        ):
            logger.warning("No suitable candidate found for shape-based correction.")
            logger.warning(
                f"Best IoU {best_candidate_shape_iou:.3f} stays below the required "
                f"{min_shape_iou:.3f} with an upstream area of "
                f"{_format_area(best_candidate_upstream_area)} against a reference "
                f"of {_format_area(ref_catchment_area)}."
            )
            if rejected_candidate is not None and best_candidate_index is not None:
                rejected_candidate.update(
                    shape_error=1 - best_candidate_shape_iou,
                    upstream_area=best_candidate_upstream_area,
                    ref_area=ref_catchment_area,
                )
            return None

        area_error = (
            abs(1 - best_candidate_upstream_area / ref_catchment_area)
            if ref_catchment_area and best_candidate_upstream_area
            else np.nan
        )
        logger.info(
            f"Shape-based gauge correction used {shape_label} with IoU {best_candidate_shape_iou:.3f}; area error {area_error:.3f} and distance {best_candidate_distance_100m/10:.2f}km.",
        )
        used_method = "shape_iou"
        return (
            best_candidate_index,
            area_error,
            best_candidate_distance_100m,
            best_candidate_score,
            1 - best_candidate_shape_iou,
            used_method,
        )

    def get_best_gauge_coordinate(  # noqa: PLR0915
        self,
        upstream_area,
        gauge_coords,
        ref_catchment_area,
        max_distance_cells=None,
        max_distance_m=None,
        max_error=0.25,
        use_max_error=True,
        method="basinex",
        shape_folder=None,
        gauge_id=None,
        raise_on_fallback=True,
    ):
        """Get best gauge coordinates given target catchment area."""
        if max_distance_cells is None and max_distance_m is None:
            max_distance_cells = 5
        shape_result = None
        score = np.nan
        shape_error = np.nan
        used_method = None
        rejected_shape_candidate = {}
        if shape_folder and gauge_id is not None:
            try:
                shape_result = self.find_best_gauge_location_shape(
                    upstream_area,
                    gauge_coords,
                    ref_catchment_area,
                    shape_folder,
                    gauge_id,
                    max_distance_cells=max_distance_cells,
                    max_distance_m=max_distance_m,
                    max_error=max_error,
                    use_max_error=use_max_error,
                    rejected_candidate=rejected_shape_candidate,
                )
            except Exception as exc:
                logger.warning(
                    f"Shape-based gauge correction failed for {gauge_id}: {exc}"
                )
                shape_result = None
        if gauge_coords is not None and not self._coords_in_domain(gauge_coords):
            logger.warning(
                f"Gauge coordinates {gauge_coords} are outside the active domain; "
                "skipping area-only correction."
            )
            gauge_coords = None

        if shape_result is not None:
            (
                outlet_idx,
                error,
                distance_error,
                score,
                shape_error,
                used_method,
            ) = shape_result
            new_lat = float(self.ds.lat.data[outlet_idx[0]])
            new_lon = float(self.ds.lon.data[outlet_idx[1]])
            gauge_lat = new_lat
            gauge_lon = new_lon
            logger.info(
                f"Moved outlet to {new_lat}/{new_lon} using shape similarity "
                f"(distance {distance_error / 10:.2f}km)."
            )
        elif ref_catchment_area is not None and gauge_coords is not None:
            if method != "all":
                outlet_idx, error, distance_error = find_best_gauge_location_by_area(
                    ds=self.ds,
                    upstream_area=upstream_area,
                    gauge_coords=gauge_coords,
                    ref_catchment_area=ref_catchment_area,
                    resolutions=self.resolutions,
                    max_distance_cells=max_distance_cells,
                    max_distance_m=max_distance_m,
                    max_error=max_error,
                    use_max_error=use_max_error,
                    method=method,
                    raise_on_fallback=raise_on_fallback,
                    latlon=self.latlon,
                )
                used_method = f"area_{method}"
                score = error * 100 + 2 * distance_error if method == "burek" else error
            else:
                outlet_idx_bx, error_bx, distance_error_bx = (
                    find_best_gauge_location_by_area(
                        ds=self.ds,
                        upstream_area=upstream_area,
                        gauge_coords=gauge_coords,
                        ref_catchment_area=ref_catchment_area,
                        resolutions=self.resolutions,
                        max_distance_cells=max_distance_cells,
                        max_distance_m=max_distance_m,
                        max_error=max_error,
                        use_max_error=use_max_error,
                        method="basinex",
                        raise_on_fallback=True,
                        latlon=self.latlon,
                    )
                )
                outlet_idx_bu, error_bu, distance_error_bu = (
                    find_best_gauge_location_by_area(
                        ds=self.ds,
                        upstream_area=upstream_area,
                        gauge_coords=gauge_coords,
                        ref_catchment_area=ref_catchment_area,
                        resolutions=self.resolutions,
                        max_distance_cells=max_distance_cells,
                        max_distance_m=max_distance_m,
                        max_error=max_error,
                        use_max_error=use_max_error,
                        method="burek",
                        raise_on_fallback=True,
                        latlon=self.latlon,
                    )
                )
                logger.info("Results of basin correction:")
                logger.info(f"Burek: lat: {float(self.ds.lat.data[outlet_idx_bu[0]])}")
                logger.info(f"Burek: lon: {float(self.ds.lon.data[outlet_idx_bu[1]])}")
                logger.info(f"Burek: error {error_bu}")
                logger.info(f"Burek: distance change {distance_error_bu/10}km")
            if method in ("all", "basinex"):
                if method == "basinex":
                    outlet_idx_bx = outlet_idx
                    error_bx = error
                    distance_error_bx = distance_error
                logger.info(
                    f"BasinEx: lat: {float(self.ds.lat.data[outlet_idx_bx[0]])}"
                )
                logger.info(
                    f"BasinEx: lon: {float(self.ds.lon.data[outlet_idx_bx[1]])}"
                )
                logger.info(f"BasinEx: error {error_bx}")
                logger.info(f"BasinEx: distance change {distance_error_bx/10}km")
            if method == "all":
                score_bx = error_bx
                score_bu = error_bu * 100 + 2 * distance_error_bu
                if error_bx < error_bu:
                    logger.info("using BasinEx location")
                    outlet_idx = outlet_idx_bx
                    error = error_bx
                    distance_error = distance_error_bx
                    score = score_bx
                    used_method = "area_basinex"
                else:
                    logger.info("Using Burek location")
                    outlet_idx = outlet_idx_bu
                    error = error_bu
                    distance_error = distance_error_bu
                    score = score_bu
                    used_method = "area_burek"
            new_lat = float(self.ds.lat.data[outlet_idx[0]])
            new_lon = float(self.ds.lon.data[outlet_idx[1]])
            gauge_lat = new_lat
            gauge_lon = new_lon
            logger.info(
                f"Moved outlet {distance_error/10:.2}km shifting latitude {float(gauge_coords[0])} to {new_lat} and longitude {float(gauge_coords[1])} to {new_lon}."
            )
        elif shape_result is None and shape_folder and gauge_id is not None:
            error_msg = f"Shape-based correction failed for gauge_id {gauge_id}"
            if rejected_shape_candidate:
                error_msg += (
                    f": the lowest shape error "
                    f"{rejected_shape_candidate['shape_error']:.3f} exceeds the max "
                    f"error {max_error:.3f} (upstream area "
                    f"{_format_area(rejected_shape_candidate['upstream_area'])}, "
                    f"reference {_format_area(rejected_shape_candidate['ref_area'])})"
                )
            error_msg += ", and no area-based correction applied."
            with ErrorLogger(logger):
                raise ValueError(error_msg)
        else:
            logger.warning(
                "No catchment area or shape provided; falling back to original gauge coordinates."
            )
            if gauge_coords is None:
                msg = "Gauge coordinates are required when neither shape-based nor area-based correction succeeds."
                with ErrorLogger(logger):
                    raise ValueError(msg)
            outlet_idx = coord_to_index(self.ds, gauge_coords[0], gauge_coords[1])
            gauge_lat = float(gauge_coords[0])
            gauge_lon = float(gauge_coords[1])
            error = np.nan
            distance_error = 0.0
        return (
            outlet_idx,
            error,
            gauge_lat,
            gauge_lon,
            distance_error / 10,
            score,
            shape_error,
            used_method,
        )

    def delineation_sanity_check(
        self,
        catchment_mask,
        basin,
        uparea_at_outlet,
        ref_catchment_area,
        max_error,
        raise_on_sanity_check,
        gauge_id,
        use_max_error=True,
    ):
        """Perform sanity checks on the delineated basin."""
        try:
            mean_cell_area = (
                float(np.mean(self.cell_area[catchment_mask]))
                if self.cell_area is not None
                else np.nan
            )
            unique_vals = np.unique(basin[catchment_mask])
            cell_count = int(np.sum(catchment_mask))
            delineated_area = (
                float(np.sum(self.cell_area[catchment_mask]))
                if self.cell_area is not None
                else np.nan
            )

            logger.info(
                f"Basin unique values: {unique_vals} | cells in basin: {cell_count} "
                f"| mean cell area: {mean_cell_area:.6f} km2"
            )

            area_difference = delineated_area - uparea_at_outlet
            area_difference_percent = (
                area_difference / uparea_at_outlet * 100.0
                if uparea_at_outlet != 0
                else np.nan
            )
            logger.info(
                f"Upstream area reported at selected outlet cell = "
                f"{uparea_at_outlet:.2f} km2. Difference (sum_cells - "
                f"upstream_at_outlet) = {area_difference:.2f} km2 "
                f"({area_difference_percent:.2f}%)."
            )
            if ref_catchment_area is not None:
                area_error = (delineated_area - ref_catchment_area) / ref_catchment_area
                logger.info(
                    f"Delineated basin area (sum of cell_area[basin>0]) = "
                    f"{delineated_area:.2f} km2; reference area = "
                    f"{ref_catchment_area:.2f} km2; error = {area_error * 100.0:.2f}%"
                )
                if use_max_error and abs(area_error) > max_error * 2:
                    with ErrorLogger(logger):
                        msg = f"Delineated basin area ({delineated_area:2f} km2) differs from reference area ({ref_catchment_area:2f} km2) by more than twice the max error {max_error*100:.2f}%. Adjust max_error or the maximum distance."
                        if raise_on_sanity_check:
                            raise ValueError(msg)
                        logger.warning(msg)
                        return True
                    # warn if the two area measures disagree substantially
            else:
                logger.warning(
                    "No reference catchment area provided; skipping area consistency check."
                )
            if not np.isclose(delineated_area, uparea_at_outlet, rtol=0.02, atol=1e-6):
                with ErrorLogger(logger):
                    msg = f"Gauge ID {gauge_id}: " if gauge_id is not None else ""
                    msg += f"Sum of cell areas inside the basin ({delineated_area:2f} km2) differs from "
                    msg += f"upstream area at outlet ({uparea_at_outlet:2f} km2). Investigate flow-direction "
                    msg += "masking, nodata handling or area units."
                    if raise_on_sanity_check:
                        raise ValueError(msg)
                    logger.warning(msg)
                    return True
            return False
        except Exception as e:
            logger.exception(f"Sanity check failed: {e}")
            if raise_on_sanity_check:
                raise e
            return True

    def delineate_basin(
        self,
        gauge,
        max_distance_cells=None,
        max_distance_m=None,
        max_error=0.25,
        use_max_error=True,
        raise_on_sanity_check=True,
        upstream_area=None,
        mask_catchment: Optional[bool] = True,
        save_coords: Optional[bool] = True,
        gauge_opti_method: Optional[str] = "basinex",
        shape_folder: Optional[str] = None,
        raise_on_fallback: Optional[bool] = True,
    ):
        """Delineate the basin for a given lat and lon."""
        # Target area in km2 we want to match (can be adjusted/replaced by caller later)
        ref_catchment_area = gauge.area
        gauge_coords = (
            (gauge.lat, gauge.lon)
            if gauge.lat is not None and gauge.lon is not None
            else None
        )
        gauge_id = getattr(gauge, "gauge_id", getattr(gauge, "id", None))
        # Compute upstream area (in km2) using accuflux and cell areas
        if self.cell_area is None:
            self.compute_cell_area()
        if upstream_area is None:
            try:
                upstream_area = self.calc_upstream_area()
            except Exception:
                logger.exception("Failed to compute upstream area (accuflux).")
            if upstream_area is None:
                msg = "Could not calculate upstream area. Flow direction may be uninitialized."
                with ErrorLogger(logger):
                    raise ValueError(msg)

        gauge_str = f" (ID: {gauge_id})" if gauge_id is not None else ""
        logger.info(
            f"Delineating basin {gauge_str} for gauge coordinates {gauge_coords} and reference catchment area {ref_catchment_area} km2."
        )
        (
            outlet_idx,
            error,
            gauge_lat,
            gauge_lon,
            distance_error,
            score,
            shape_error,
            used_method,
        ) = self.get_best_gauge_coordinate(
            upstream_area=upstream_area,
            gauge_coords=gauge_coords,
            ref_catchment_area=ref_catchment_area,
            max_distance_cells=max_distance_cells,
            max_distance_m=max_distance_m,
            max_error=max_error,
            use_max_error=use_max_error,
            method=gauge_opti_method,
            shape_folder=shape_folder,
            gauge_id=gauge_id,
            raise_on_fallback=raise_on_fallback,
        )
        outlet_linear_idx = np.ravel_multi_index(outlet_idx, self._fdir.shape)

        try:
            basin = self._fdir.basins(
                idxs=np.array([outlet_linear_idx], dtype=np.int64),
            )
        except Exception as e:
            logger.exception(f"pyflwdir.basins(idxs=...) failed for {outlet_idx}: {e}")
            try:
                all_basins = self._fdir.basins()
                basin_id = int(all_basins[outlet_idx])
                basin = np.where(all_basins == basin_id, basin_id, 0)
            except Exception as e2:
                logger.exception(f"Fallback basins() also failed: {e2}")
                return gauge

        catchment_mask = basin > 0
        logger.debug(
            f"mask statistics: min={basin.min()}, max={basin.max()}, all true? {np.all(catchment_mask)}"
        )
        # set before the sanity check, so a failing cut off basin can be detected
        self.touches_domain_edge = bool(np.any(_get_domain_edge_values(catchment_mask)))
        self.touches_crop_edge = bool(
            np.any(_get_domain_edge_values(catchment_mask, self.crop_edge_sides))
        )

        uparea_at_outlet = (
            upstream_area[outlet_idx] if upstream_area is not None else np.nan
        )
        failed_sanity_check = self.delineation_sanity_check(
            catchment_mask,
            basin,
            uparea_at_outlet,
            ref_catchment_area,
            max_error,
            raise_on_sanity_check,
            gauge_id,
            use_max_error=use_max_error,
        )

        if np.all(catchment_mask):
            logger.error("No catchment found for the given coordinates")
            return gauge

        if mask_catchment:
            self.catchment_mask = catchment_mask
            self.basin = basin
            try:
                fillv = self.VARIABLES["basin"]["_FillValue"]
                self.basin = np.where(self.catchment_mask, self.basin, fillv)
            except Exception:
                logger.debug("Could not set basin fill values")

        if not failed_sanity_check:
            if save_coords:
                self.save_coords(gauge_id, gauge_lat, gauge_lon)

            gauge.update(
                lat=gauge_lat,
                lon=gauge_lon,
                area=uparea_at_outlet,
                distance_error=distance_error,
                area_error=error,
                score=score,
                shape_error=shape_error,
                method=used_method,
            )
        return gauge

    def save_coords(self, gauge_id, gauge_lat, gauge_lon):
        """Save gauge coordinates."""
        if gauge_id is not None:
            self.gauge_ids.append(gauge_id)
        self.gauge_lats.append(gauge_lat)
        self.gauge_lons.append(gauge_lon)

    def write_basin_shape(self, out_dir, gauge_id=None, basin_mask=None):
        """Write a basin shapefile from a basin mask."""
        if basin_mask is None:
            basin_mask = self.catchment_mask
        if basin_mask is None or not np.any(basin_mask):
            return
        try:
            gdf = _vectorize_mask_to_gdf(
                basin_mask, self.transform, _shape_crs(self.latlon), value_name="basin"
            )
        except Exception as exc:
            logger.warning(f"Could not write basin shapefile: {exc}")
            return
        output_dir = Path(out_dir)
        output_dir.mkdir(parents=True, exist_ok=True)
        suffix = f"_{gauge_id}" if gauge_id is not None else ""
        out_path = output_dir / f"basin{suffix}.shp"
        try:
            gdf.to_file(out_path)
            logger.info(f"Wrote basin shapefile to {out_path}")
        except Exception as exc:
            logger.warning(f"Failed to write basin shapefile {out_path}: {exc}")

    def get_upscaling_factor(self, max_resolution=False, l1=False, l2=True):
        """Create upscaling factor."""
        return get_upscaling_factor(
            self.resolutions, max_resolution=max_resolution, l1=l1, l2=l2
        )

    def upscale(self, var):
        """Upscale flow direction to l1_resolution if that is int multipe of data resolution."""
        factor, upscaled_resolution = get_upscaling_factor(self.resolutions, l1=True)

        if factor == 1:
            self.get_facc()
            return
        # if we upscale the do_upscale flag should be true
        self.do_upscale = True
        logger.info(
            f"Upscaling flow direction to {upscaled_resolution} with the fator {factor}."
        )
        fdir_upscaled, upscaling_indices = self._fdir.upscale(factor, method="ihu")

        subareas = self._fdir.ucat_area(idxs_out=upscaling_indices, unit="km2")[1]
        uparea1 = fdir_upscaled.accuflux(subareas)

        flwerr = self._fdir.upscale_error(fdir_upscaled, upscaling_indices)
        percentage_error = np.sum(flwerr == 0) / np.sum(flwerr != 255) * 100
        logger.info(f"upscaling error in {percentage_error:.2f}% of cells")
        logger.debug(f"Upscaled form {self._fdir.shape} to {fdir_upscaled.shape}")
        self._fdir = fdir_upscaled
        self.get_fdir()
        self.uparea_grid = uparea1  # replaces self.get_facc
        self.cell_area = (
            None  # reset cell area to be recalculated at new resolution when needed
        )
        self.is_upscaled = True
        self.upscaled_resolution = upscaled_resolution
        if var == "dem":
            lat_size, lon_size = self.input_da.shape
            # Ensure the dimensions are evenly divisible by the factor
            if lat_size % factor != 0 or lon_size % factor != 0:
                msg = f"Data dimensions must be divisible by the upscaling factor of {factor}. Lat ({lat_size}/{factor})={lat_size / factor:.2f}; Lon ({lon_size}/{factor})={lon_size / factor:.2f}"
                with ErrorLogger(logger):
                    raise ValueError(msg)

            # Reshape and aggregate data
            reshaped = self.input_da.values.reshape(
                lat_size // factor, factor, lon_size // factor, factor
            )
            aggregated = reshaped.mean(axis=(1, 3))  # Conservative mean over each block
            # Create new DataArray
            self.elevtn = aggregated

    def get_basins(self):
        """Perform the calculation of the catchment ids."""
        self.basin = self._fdir.basins()

    def get_fdir(self):
        """Perform the calculation of the flow direction."""
        logger.debug("Get flwdir as array.")
        self.flwdir = self._fdir.to_array(ftype=self.ftype or OUTPUT_FTYPE)

    def get_upstream_area(self):
        """Perform the calculation of the upstream catchment area."""
        # upgrid = self._fdir.upstream_area(unit="km2").astype(int)
        self.upgrid = self.calc_upstream_area().astype(int)

    def get_grid_area(self):
        """Perform the calculation of the catchment area."""
        self.get_upstream_area()
        self.grdare = self._fdir.area.astype(int)

    def get_facc(self):
        """Get the flow accumulation area."""
        logger.info("Calculate flow accumulation...")
        data = np.ones_like(self.flwdir).astype(np.uint32)
        data[~self._fdir.mask.reshape(data.shape)] = 0
        self.uparea_grid = self._fdir.accuflux(data, nodata=0)

    @staticmethod
    def create_frame(ds, frame=0, frame_value=0):
        """Set the outermost ``frame`` rows and columns of every variable to a value.

        The frame replaces the outer cells of the grid, it does not add cells.

        Args:
            ds (xr.Dataset): Dataset whose 2D variables get the frame, changed in place.
            frame (int): Width of the frame in cells; 0 leaves the dataset unchanged.
            frame_value (float or dict): Value written into the frame of every
                variable, or a dict with one value per variable name.

        Returns
        -------
            xr.Dataset: The dataset with the frame.
        """
        logger.info(f"Creating a frame of {frame} cells around the domain.")
        if frame > 0:
            for var in ds.data_vars:
                value = (
                    frame_value[var] if isinstance(frame_value, dict) else frame_value
                )
                data = ds.variables[var].data[:]
                data[:frame, :] = value
                data[-frame:, :] = value
                data[:, :frame] = value
                data[:, -frame:] = value
                ds.variables[var].data[:] = data
        return ds

    def fill_adjacent_missing_with_sink(self, da, fill_value, sink_value):
        """Replace all missing values adjacent to non-missing values with 0 in an xarray Dataset.

        Parameters
        ----------
            da (xr.Dataset): Input dataset.

        Returns
        -------
            xr.Dataset: Dataset with adjacent missing values replaced with 0.
        """
        # Mask of missing values
        missing_mask = da == fill_value

        # Mask of non-missing values
        non_missing_mask = ~missing_mask

        # Dilate the non-missing mask to include adjacent cells
        adjacent_mask = binary_dilation(
            non_missing_mask, structure=np.array([[1, 1, 1], [1, 1, 1], [1, 1, 1]])
        )

        # Identify adjacent missing values
        adjacent_missing = adjacent_mask & missing_mask

        # Replace adjacent missing values with 0
        return xr.where(adjacent_missing, sink_value, da)

    @log_arguments()
    def write(
        self,
        out_path,
        single_file=True,
        format="nc",
        cellsize=None,
        cut_by_basin=False,
        mask_file=None,
        frame=0,
        buffer=0,
        variables=None,
        id_gauges_out_path=None,
    ):
        """Write the produced data to one or multiple files.

        The outermost ``frame`` rows and columns become pits in ``flwdir`` and no
        data in every other variable and in the mask (see ``create_frame``). The
        frame replaces cells instead of adding them: with ``cut_by_basin`` the
        ``buffer`` around the basin has to be at least ``frame``, otherwise the
        frame overwrites the outer cells of the domain, basin cells included.
        """
        data_vars = {}
        out_path = Path(out_path)
        if not out_path.is_dir():
            out_path.mkdir(parents=True, exist_ok=True)
        gauges_out_path = (
            Path(id_gauges_out_path) if id_gauges_out_path is not None else out_path
        )
        gauges_out_path.mkdir(parents=True, exist_ok=True)
        selected_vars = _normalize_output_vars(variables)
        lat_slice_idx, lon_slice_idx = None, None
        lat_slice, lon_slice = None, None
        if cut_by_basin:
            lat_slice_idx, lon_slice_idx = cut_to_filled_area(
                ds=self.ds,
                resolutions=self.resolutions,
                catchment_mask=self.catchment_mask,
                buffer=buffer,
            )
        elif self.latlon:
            # the global mHM domain ends at 84 N and 56 S, a projected grid in
            # metres has no such limits and is written in full
            lat_slice, lon_slice = slice(84, -56), slice(None)

        for var_name in (v for v in self.VARIABLES if v in selected_vars):
            data_var = self.processing_data_variable(
                var_name,
                cut_by_basin,
                lat_slice,
                lon_slice,
                lat_slice_idx,
                lon_slice_idx,
            )
            if data_var is None:
                continue
            if single_file:
                data_vars[var_name] = data_var
            else:
                self.write_single_variable_file(
                    data_var, var_name, out_path, cellsize, format
                )
        if single_file:
            if not data_vars:
                msg = "No data variables available to write."
                with ErrorLogger(logger):
                    raise ValueError(msg)
            ds = self.write_basin_id_file(data_vars, frame, out_path)
            # use basin_id to create a mask file
            if "basin" in ds.data_vars:
                self.write_mask_file(ds, mask_file)
                if self.gauge_ids:
                    logger.info("Writing gauges file.")
                    # create empty ds with mask l0 extend and fill the data_var called data with -9999 values
                    id_da = xr.DataArray(
                        np.full(ds.basin.shape, -9999, dtype=int),
                        coords={"lat": ds.lat, "lon": ds.lon},
                        dims=["lat", "lon"],
                    )
                    id_ds = id_da.to_dataset(name="idgauges")
                    gauge_ids_numeric = _to_numeric_gauge_ids(
                        self.gauge_ids,
                        context="idgauges",
                    )
                    id_ds = write_gauge_id(
                        ds=id_ds,
                        id=gauge_ids_numeric,
                        lat=self.gauge_lats,
                        lon=self.gauge_lons,
                        data_var="idgauges",
                    )
                    write_xarray_to_file(
                        id_ds, gauges_out_path / "idgauges.nc", "idgauges"
                    )
                    write_xarray_to_file(
                        id_ds,
                        gauges_out_path / "idgauges.asc",
                        "idgauges",
                        resolution=self.upscaled_resolution,
                    )
                else:
                    logger.info("No gauges to write, skipping gauges file.")
            else:
                logger.info("No basin variable written; skipping mask/gauge files.")

    def write_single_variable_file(
        self, data_var, var_name, out_path, cellsize, format
    ):
        """Write a single data variable to a specified file path."""
        # set some attributes
        for coord in data_var.coords:
            data_var[coord].attrs = self.ds[coord].attrs
        data_var.attrs = {
            "title": self.VARIABLES[var_name]["title"],
            "units": self.VARIABLES[var_name]["units"],
            "creator": "Department of Computational Hydrosystems",
            "institution": "Helmholtz Centre for Environmental Research - UFZ",
        }
        fname = out_path / f"{var_name}.{format}"
        if format == "nc":
            write_xarray_to_file(
                data_var,
                fname,
                encoding={
                    var_name: {
                        "dtype": get_dtype(data_var[var_name]),
                        "_FillValue": self.VARIABLES[var_name]["_FillValue"],
                    }
                },
            )
        elif format == "asc":
            cellsize = cellsize or abs(float(data_var["lon"][1] - data_var["lon"][0]))
            is_ascending = bool(data_var["lat"][0] < data_var["lat"][-1])
            with fname.open("w") as file_object:
                file_object.write(f"ncols {data_var[var_name].shape[1]}\n")
                file_object.write(f"nrows {data_var[var_name].shape[0]}\n")
                file_object.write(
                    f"xllcorner {float(data_var['lon'][0] - cellsize / 2)}\n"
                )
                if is_ascending:
                    file_object.write(
                        f"yllcorner {float(data_var['lat'][0] - cellsize / 2)}\n"
                    )
                else:
                    file_object.write(
                        f"yllcorner {float(data_var['lat'][-1] - cellsize / 2)}\n"
                    )
                file_object.write(f"cellsize {cellsize}\n")
                file_object.write(
                    f"nodata_value {self.VARIABLES[var_name]['_FillValue']}\n"
                )
                if is_ascending:
                    vals = data_var[var_name].values[::-1, :]
                else:
                    vals = data_var[var_name].values
                np.savetxt(file_object, vals, delimiter=" ", fmt="%s")
        else:
            with ErrorLogger(logger):
                msg = f'Format "{format}" unknown, use one of ["nc", "asc"]'
                raise Exception(msg)

    def processing_data_variable(
        self,
        var_name,
        cut_by_basin,
        lat_slice=None,
        lon_slice=None,
        lat_slice_idx=None,
        lon_slice_idx=None,
    ):
        """Process data variable, masking it and croping it spatial dimensions."""
        logger.info(f"Processing {var_name}")
        data = getattr(self, var_name)
        if data is None:
            logger.warning(f"No data for {var_name}")
            return None
        if cut_by_basin:
            data[~self.catchment_mask] = self.VARIABLES[var_name]["_FillValue"]
        if data is None:
            logger.warning(f"No data for {var_name}")
            return None
        lon, lat = self._coords_l1()
        logger.debug(
            f"lon_min {np.min(lon):.3f}, lon_max {np.max(lon):.3f}, resulution: {self.resolutions.l1}"
        )
        logger.debug(f"{var_name} - mean {np.nanmean(data)}, max {np.nanmax(data)}")
        logger.debug(f"Shape {data.shape},  lon {len(lon)}, lat {len(lat)}")
        data_var = xr.Dataset(
            {var_name: (["lat", "lon"], self._revert_data(data))},
            coords={
                "lon": lon,  # [slice(3555, 3565)],
                "lat": lat,  # [slice(860, 870)],
            },
        )
        if lat_slice is not None and lon_slice is not None:
            logger.info(f"Cutting {var_name} data to correct spatial dimensions")
            data_var = data_var.sel(lat=lat_slice, lon=lon_slice)
        elif lat_slice_idx is not None and lon_slice_idx is not None:
            logger.info(f"Cutting {var_name} data to correct spatial dimensions")
            data_var = data_var.isel(lat=lat_slice_idx, lon=lon_slice_idx)
        logger.debug(data_var)
        return data_var

    def write_basin_id_file(self, data_vars, frame, out_path):
        """Write the basin_id file to specified path and set a sink value frame if specified."""
        logger.info("Write to single file.")
        logger.debug(f"data_vars: {data_vars}")
        ds = xr.merge(data_vars.values())
        # set some attributes
        for coord in ds.coords:
            ds[coord].attrs = self.ds[coord].attrs
        ds.attrs = {
            "title": "Hydrologic information",
            "creator": "Department of Computational Hydrosystems",
            "institution": "Helmholtz Centre for Environmental Research - UFZ",
        }
        for var_name in ds.data_vars:
            ds[var_name].attrs = {
                "long_name": self.VARIABLES[var_name]["title"],
                "standard_name": self.VARIABLES[var_name]["title"],
                "units": self.VARIABLES[var_name]["units"],
            }

        # logger.debug(f"lat_slice: {lat_slice}, lon_slice: {lon_slice}")
        logger.debug(f"ds: {ds}")
        # routing stops at the pits in flwdir, every other variable is no data there
        frame_values = {
            var_name: (
                FDIR_SINKVALUE[self.ftype]
                if var_name == "flwdir"
                else self.VARIABLES[var_name]["_FillValue"]
            )
            for var_name in ds.data_vars
        }
        ds = self.create_frame(ds, frame, frame_values)
        # For the flow dir map fill masked cells adjecent to filled cells with sink instead of missing value
        # fdir_filled = self.fill_adjacent_missing_with_sink(
        #     ds["flwdir"], FDIR_FILLVALUE[self.ftype], FDIR_SINKVALUE[self.ftype]
        # )
        # ds["flwdir"].data[:] = fdir_filled.data[:]
        write_xarray_to_file(
            ds,
            out_path / self.out_var_name,
            encoding={
                var_name: {
                    "dtype": get_dtype(ds[var_name]),
                    "_FillValue": self.VARIABLES[var_name]["_FillValue"],
                }
                for var_name in ds.data_vars
            },
        )
        logger.info(f"Basin Id has been written to {out_path / self.out_var_name}")
        return ds

    def _cell_edges(self, centers: np.ndarray) -> np.ndarray:
        """Compute edges (len=N+1) from center coords (len=N) on a regular grid."""
        c = np.asarray(centers)
        d = np.diff(c)
        left = c[0] - 0.5 * d[0]
        right = c[-1] + 0.5 * d[-1]
        mids = (c[:-1] + c[1:]) / 2.0
        return np.concatenate(([left], mids, [right]))

    def _coarse_centers_from_edges(
        self, edges: np.ndarray, k: int, n_blocks: int, ascending: bool
    ) -> np.ndarray:
        """
        Given fine-grid edges, build coarse-grid centers for block size k.

        Ensures coarse edges == fine edges over the cropped window.
        """
        # we assume you've cropped L0 so len(fine_centers) is divisible by k
        # The window's left edge and right edge are edges[0] and edges[k*n_blocks]
        left_edge = edges[0]
        dx_coarse = edges[k] - edges[0]  # = k * dx_fine (works for asc/desc)
        # centers are midpoints of each coarse cell
        n = np.arange(n_blocks)
        centers = left_edge + (n + 0.5) * dx_coarse
        if not ascending and centers[0] < centers[-1]:
            centers = centers[::-1]
        return centers

    def upscale_mask_with_correct_coords(
        self,
        da: xr.DataArray,
        factor: Optional[int] = None,
        lon_name: str = "lon",
        lat_name: str = "lat",
    ) -> xr.DataArray:
        """
        Coarsen a 2D mask-like field by integer factor and assign correct coarse coords.

        so that coarse *edges* equal fine *edges* of the cropped window.
        """
        if factor is None:
            factor, upscaled_resolution = get_upscaling_factor(
                self.resolutions, input_res=self.upscaled_resolution, l2=True
            )
        else:
            # the mask arrives at the current working resolution, so coarsening
            # it by the factor is what gives the target cell width
            upscaled_resolution = self.upscaled_resolution * factor
        if factor < 1:
            msg = "factor must be >= 1"
            with ErrorLogger(logger):
                raise ValueError(msg)
        if factor == 1:
            # nothing to coarsen, and the edge arithmetic below needs a
            # neighbour to derive a cell width from, which a one cell wide
            # domain does not have
            return da

        logger.info(f"Upscaling mask with factor {factor} to {upscaled_resolution}.")

        # coarsening trims a partial block away, so an axis shorter than the
        # factor would leave nothing behind
        for name in (lat_name, lon_name):
            if name in da.dims and da.sizes[name] < factor:
                msg = (
                    f"Cannot upscale to {upscaled_resolution} from "
                    f"{self.upscaled_resolution}: the domain spans "
                    f"{da.sizes[name]} cell(s) along {name!r} but a factor of "
                    f"{factor} needs at least {factor}. The catchment is "
                    "narrower than a single target cell."
                )
                with ErrorLogger(logger):
                    raise ValueError(msg)

        # 1) coarsen over lon/lat windows
        kx = ky = int(factor)
        coarsen_map = {}
        if lon_name in da.dims:
            coarsen_map[lon_name] = kx
        if lat_name in da.dims:
            coarsen_map[lat_name] = ky

        # Treat only explicit mask=1 (or True) as land; ignore fill values and NaNs.
        if da.dtype == bool:
            cond = da
        else:
            fillv = da.attrs.get("_FillValue", da.encoding.get("_FillValue"))
            da_clean = da
            if fillv is not None:
                da_clean = da.where(da != fillv)
            cond = da_clean == 1
        out = cond.coarsen(coarsen_map, boundary="trim").any().astype("int8")

        # 2) compute correct coarse coordinates from fine edges
        lon_f = da[lon_name].values
        lat_f = da[lat_name].values

        lon_edges = self._cell_edges(lon_f)
        lat_edges = self._cell_edges(lat_f)

        asc_lon = lon_f[0] < lon_f[-1]
        asc_lat = lat_f[0] < lat_f[-1]
        logger.debug(f"asc_lon: {asc_lon}, asc_lat: {asc_lat}")

        n_lon_blocks = out.sizes.get(lon_name, 1)
        n_lat_blocks = out.sizes.get(lat_name, 1)

        # figure out which portion of edges we used after boundary="trim":
        # Since you cropped L0 to a multiple of factor, the coarsen starts at index 0
        # and uses exactly n_blocks*k cells. So we can take edges[0 : n_blocks*k + 1].
        lon_edges_win = (
            lon_edges[: n_lon_blocks * kx + 1]
            if asc_lon
            else lon_edges[-(n_lon_blocks * kx + 1) :]
        )
        lat_edges_win = (
            lat_edges[: n_lat_blocks * ky + 1]
            if asc_lat
            else lat_edges[-(n_lat_blocks * ky + 1) :]
        )
        lon_coarse = self._coarse_centers_from_edges(
            lon_edges_win, kx, n_lon_blocks, asc_lon
        )
        lat_coarse = self._coarse_centers_from_edges(
            lat_edges_win, ky, n_lat_blocks, asc_lat
        )
        asc_lat_coarse = lat_coarse[0] < lat_coarse[-1]
        if asc_lat != asc_lat_coarse:
            logger.warning(
                "Coarse lat coordinate ascending order does not match fine grid; check calculations."
            )

        out = out.assign_coords({lon_name: lon_coarse, lat_name: lat_coarse})
        out.name = "mask_L2"

        # 3) (optional) log edges for verification
        try:
            lon_edges_coarse = self._cell_edges(out[lon_name].values)
            lat_edges_coarse = self._cell_edges(out[lat_name].values)
            logger.info(
                f"Coarse lon edges: {lon_edges_coarse[0]:.6f} .. {lon_edges_coarse[-1]:.6f} "
                f"(should equal fine window edges: {lon_edges_win[0]:.6f} .. {lon_edges_win[-1]:.6f})"
            )
            logger.info(
                f"Coarse lat edges: {lat_edges_coarse[0]:.6f} .. {lat_edges_coarse[-1]:.6f} "
                f"(should equal fine window edges: {lat_edges_win[0]:.6f} .. {lat_edges_win[-1]:.6f})"
            )
        except IndexError:
            logger.debug("Could not log coarse edges for verification.")
            logger.debug(f"lon_coarse: {out[lon_name].values}")
            logger.debug(f"lat_coarse: {out[lat_name].values}")
        return out

    def write_mask_file(self, ds, mask_file):
        """Write basin mask to specified path."""
        if mask_file is not None:
            logger.info("Writing mask file")
            # name the variable mask
            mask = np.where(
                ds.basin > 0, 1, 0
            )  # if self.catchment_mask is None else self.catchment_mask
            mask_file = Path(mask_file)
            mask_da = xr.DataArray(
                mask, coords={"lat": ds.lat, "lon": ds.lon}, dims=["lat", "lon"]
            )
            mask_da["lat"].attrs.update(
                {
                    "units": "degrees_north",
                    "long_name": "latitude",
                    "standard_name": "latitude",
                    "axis": "Y",
                }
            )
            mask_da["lon"].attrs.update(
                {
                    "units": "degrees_east",
                    "long_name": "longitude",
                    "standard_name": "longitude",
                    "axis": "X",
                }
            )
            mask_da.attrs.update(
                {
                    "units": "1",
                    "long_name": "catchment mask",
                    "flag_values": np.array([0, 1], dtype=mask_da.dtype),
                    "flag_meanings": "outside_catchment inside_catchment",
                }
            )
            logger.debug(
                f"Created mask dataarray with shape {mask_da.shape} and stats min {mask_da.min().item()}, max {mask_da.max().item()}"
            )
            mask_ds = xr.Dataset({"mask": mask_da})

            if self.resolutions.l2 is not None:
                mask_upscaled = self.upscale_mask_with_correct_coords(mask_da)
                mask_upscaled = mask_upscaled.rename({"lat": "lat_l2", "lon": "lon_l2"})
                mask_upscaled.attrs.update(
                    {
                        "units": "1",
                        "long_name": "catchment mask at L2 resolution",
                        "flag_values": np.array([0, 1], dtype=mask_upscaled.dtype),
                        "flag_meanings": "outside_catchment inside_catchment",
                    }
                )
                mask_ds["mask_l2"] = mask_upscaled
            dims = set(mask_ds.dims)
            all_coords = set(mask_ds.coords)
            dim_coords = all_coords & dims  # intersection
            for var in dim_coords:
                bounds_name = f"{var}_bnds"
                if var.endswith("_l2"):
                    res = self.resolutions.l2
                else:
                    res = self.upscaled_resolution
                try:
                    mask_ds.coords[bounds_name] = generate_bounds(mask_ds[var], res=res)
                    mask_ds[var].attrs["bounds"] = bounds_name
                except (IndexError, ValueError):
                    logger.info(f"Could not generate bounds for coord {var}")
            encoding = {v: dict(NC_ENCODE_MASK) for v in mask_ds.data_vars}
            write_xarray_to_file(mask_ds, mask_file, encoding=encoding)
            add_variable_hard_link(
                mask_file, existing_var="mask", alias_var="land_mask"
            )
            logger.info(f"Mask file has been written to {mask_file}")
        else:
            logger.info("No mask file path specified.")

    def cut_to_filled_area(
        self, buffer=0, repeat=False, raise_on_l2_alignment_mismatch=False
    ):
        """Create lat and lon slices to cut the data to the filled area."""
        return cut_to_filled_area(
            ds=self.ds,
            resolutions=self.resolutions,
            catchment_mask=self.catchment_mask,
            buffer=buffer,
            repeat=repeat,
            raise_on_l2_alignment_mismatch=raise_on_l2_alignment_mismatch,
        )


def merge_catchment(path1, path2, out_path):
    """Merge the rolled and non-rolled file."""
    # read the rolled and non-rolled files
    ds1 = get_xarray_ds_from_file(path1, engine="netcdf4")
    ds2 = get_xarray_ds_from_file(path2, engine="netcdf4")

    # select all the basins in the border area
    border_cells = (ds1.lon > CUTOFF_THRESHOLD) | (ds1.lon < (CUTOFF_THRESHOLD * -1))
    mask_ids = np.unique(ds1["basin"].where(border_cells))
    mask_ids = mask_ids[np.isfinite(mask_ids)]
    mask_ids = mask_ids[mask_ids != ds1["basin"].attrs.get("_FillValue", 0)]
    mask_ids = mask_ids[mask_ids != 0]
    # get a mask of all the border area basins
    mask = ds1["basin"].isin(mask_ids)
    # modify the ids to avoid overlaps
    ds2["basin"] = ds2["basin"] + ds1["basin"].max().item() + 1

    # in the border area, use the rolled data, else the original
    var_attrs = {var: dict(ds1[var].attrs) for var in ds1.data_vars}
    merged = xr.where(mask, ds2.reindex_like(ds1, method="nearest"), ds1)
    for var, attrs in var_attrs.items():
        if var in merged.data_vars:
            merged[var].attrs = attrs
    write_xarray_to_file(merged, out_path)


def get_transformation_matrix_nc(ds, var_name):
    """Get Transformation Matrix from input file dimensions and resolution."""
    da = ds[var_name]

    # Get attributes for geotransformation
    lat = da.coords["lat"].values  # Assuming 'lat' and 'lon' are dimensions
    lon = da.coords["lon"].values
    logger.info(f"lat: {lat.max()} | {lat.min()}")
    logger.info(f"lon: {lon.min()} | {lon.max()}")

    # Assuming uniform spacing, calculate resolution
    lat_res = abs(lat[1] - lat[0]) if len(lat) > 1 else 0.0
    lon_res = abs(lon[1] - lon[0]) if len(lon) > 1 else 0.0
    # logger.info(f"lat_res {lat_res}; lon_res {lon_res}")

    # Get the corner coordinate of the dataset
    x_min, y_max = lon.min(), lat.max()
    return (
        np.float64(lon_res),
        np.float64(0.0),
        np.float64(x_min - lon_res / 2),
        np.float64(0.0),
        np.float64(-lat_res),
        np.float64(y_max + lat_res / 2),
    )


def is_data_global(ds, coordinate_slice):
    """Check if the longitude data is global."""
    if coordinate_slice is not None:
        ds_sliced = ds.sel(lon=coordinate_slice["lon"])
    else:
        ds_sliced = ds
    try:
        return (
            "lon" in ds_sliced.coords
            and ds_sliced.lon.min() < (CUTOFF_THRESHOLD * -1)
            and ds_sliced.lon.max() > CUTOFF_THRESHOLD
        )
    except Exception as e:
        logger.warning(e)
        return False


def _is_list_of_float_tuples(a):
    return isinstance(a, list) and all(
        isinstance(x, tuple) and len(x) == 2 and all(isinstance(v, float) for v in x)
        for x in a
    )


@log_arguments()
@_retry_with_larger_crop
def create_catchment(  # noqa: PLR0913, PLR0912, PLR0915
    input_file,
    output_path,
    var_name,
    var,
    ftype,
    gauge_coords=None,
    coordinate_slices=None,
    mask_file=None,
    resolutions: Resolution = None,
    frame=0,
    upscale=False,
    latlon=True,
    available_mem=None,
    ref_catchment_area=None,
    max_distance_cells=None,
    max_distance_m=None,
    max_distance_auto=False,
    max_error=0.1,
    use_max_error=True,
    gauge_ids=None,
    ncpus=1,
    output_vars=None,
    gauge_opti_method="basinex",
    shape_folder=None,
    gauge_info_file="gauges_info",
    id_gauges_out_path=None,
    raise_on_fallback=True,
    crop_bounds=None,
    crop_retries_left=CROP_RETRY_LIMIT,
):
    """Delineate global or local catchments from flow direction/DEM data.

    Supports full-domain basin mapping, single- or multi-gauge delineation from
    coordinates and area, and optional shape-based outlet matching. Writes
    basin IDs, gauge ID files, masks, and optional gauge metadata/shapes.
    crop_bounds and crop_retries_left are set internally when a basin reaching
    the edge of the automatic crop reruns the delineation with a larger crop.

    frame (default 0) turns the outermost frame rows and columns of the output
    into pits in flwdir and no data in every other variable and in the mask, so
    Ulysses mRM, which joins the eastern and western grid edges, can't route
    across the border of a regional domain. The frame replaces cells instead of
    adding them: a single-gauge run pads the basin by frame cells first, so only
    a basin closer than that to the input edge loses cells, while a region or
    multi-gauge run loses its outer frame cells, basin cells included. Global
    runs that write basin ids ignore the frame.
    """
    logger.info(
        f"Creating catchment file for {var_name} using {var} and {ftype} from {input_file}"
    )
    output_path = Path(output_path)
    id_gauges_out_path = (
        output_path if id_gauges_out_path is None else Path(id_gauges_out_path)
    )
    id_gauges_out_path.mkdir(parents=True, exist_ok=True)
    if _is_list_of_float_tuples(gauge_coords) and len(gauge_coords) == 1:
        gauge_coords = gauge_coords[0]
    if isinstance(ref_catchment_area, list) and len(ref_catchment_area) == 1:
        ref_catchment_area = ref_catchment_area[0]
        if isinstance(ref_catchment_area, list):
            if len(ref_catchment_area) != 1:
                msg = "If gauge_coords is a list of one tuple, ref_catchment_area (if provided) must be a single value or a list of one value."
                with ErrorLogger(logger):
                    raise ValueError(msg)
            ref_catchment_area = ref_catchment_area[0]
    if resolutions is None:
        resolutions = Resolution()
    if max_distance_cells is not None and max_distance_m is not None:
        msg = "Only one of max_distance_cells and max_distance_m may be provided."
        with ErrorLogger(logger):
            raise ValueError(msg)
    if max_distance_cells is not None and max_distance_cells < 0:
        msg = "max_distance_cells must be non-negative."
        with ErrorLogger(logger):
            raise ValueError(msg)
    if max_distance_m is not None and max_distance_m < 0:
        msg = "max_distance_m must be non-negative."
        with ErrorLogger(logger):
            raise ValueError(msg)
    if max_distance_auto and (
        max_distance_cells is not None or max_distance_m is not None
    ):
        msg = "max_distance_auto cannot be combined with max_distance_cells or max_distance_m."
        with ErrorLogger(logger):
            raise ValueError(msg)
    auto_max_distances_m = None
    if max_distance_auto and (gauge_coords is not None or gauge_ids is not None):
        auto_max_distances_m = [
            _calculate_auto_max_distance_m(gauge_id, shape_folder, area, latlon)
            for gauge_id, _, area in zip(
                *_get_gauge_lists(gauge_ids, gauge_coords, ref_catchment_area)
            )
        ]
        # the crop has to fit the largest search distance of all gauges
        max_distance_m = max(auto_max_distances_m)
    if max_distance_cells is None and max_distance_m is None:
        max_distance_cells = 5
    if var not in {"fdir", "dem"}:
        with ErrorLogger(logger):
            msg = f"Unexpected value for var={var}, must be 'fdir' or 'dem'"
            raise ValueError(msg)
    output_vars = _normalize_output_vars(output_vars)
    chunking = available_mem is not None
    with get_xarray_ds_from_file(
        input_file,
        var_name,
        normalize_latlon_coords=True,
        force_decending_y=True,
        available_mem_gib=available_mem,
        chunking=chunking,
        drop_auxiliary_coords=True,
    ) as input_ds:
        coord_slices_default = False
        if coordinate_slices is None:
            coordinate_slices = {"lat": slice(None, None), "lon": slice(None, None)}
            coord_slices_default = True
        search_buffer, search_buffer_m = _outlet_search_buffer(
            max_distance_m, max_distance_cells, resolutions.l0, latlon
        )
        bounds = None
        if coord_slices_default and crop_bounds is not None:
            bounds = crop_bounds
        elif coord_slices_default and (shape_folder or ref_catchment_area is not None):
            bounds = _get_gauge_crop_bounds(
                shape_folder,
                gauge_ids,
                gauge_coords,
                ref_catchment_area,
                latlon,
                min_buffer=search_buffer,
                min_buffer_m=search_buffer_m,
            )
        if bounds is not None:
            slices = _slices_from_bounds(bounds, input_ds.lat.data)
            if slices is not None:
                coordinate_slices = slices
        # transform
        transform = get_transformation_matrix_nc(input_ds, var_name)

        logger.info(transform)
        if coordinate_slices is None:
            if shape_folder:
                bounds = _shape_bounds_from_folder(
                    shape_folder,
                    gauge_ids,
                    min_buffer=search_buffer,
                    min_buffer_m=search_buffer_m,
                )
                logger.debug(f"Extracted bounds from shape_folder: {bounds}")
                if bounds is not None:
                    slices = _slices_from_bounds(bounds, input_ds.lat.data)
                    logger.debug(f"Calculated slices from bounds: {slices}")
                    if slices is not None:
                        coordinate_slices = slices
                        logger.info(
                            f"Updated coordinate_slices based on shape_folder: {coordinate_slices}"
                        )
            else:
                logger.debug("No shape_folder provided, using no coordinate slices.")
                coordinate_slices = {"lat": slice(None, None), "lon": slice(None, None)}
        logger.debug(f"Using coordinate_slices: {coordinate_slices}")

        def _compute_requested_outputs(catchment):
            needs_uparea_grid = "uparea_grid" in output_vars
            needs_upgrid = "upgrid" in output_vars
            needs_grdare = "grdare" in output_vars
            needs_basin = "basin" in output_vars

            if resolutions.l1 is not None and upscale:
                catchment.upscale(var)
            elif needs_uparea_grid:
                catchment.get_facc()

            if needs_basin and catchment.basin is None:
                catchment.get_basins()

            if needs_grdare:
                catchment.get_grid_area()
            elif needs_upgrid:
                catchment.get_upstream_area()

        def _compute_requested_outputs(catchment):
            needs_uparea_grid = "uparea_grid" in output_vars
            needs_upgrid = "upgrid" in output_vars
            needs_grdare = "grdare" in output_vars
            needs_basin = "basin" in output_vars

            if resolutions.l1 is not None and upscale:
                catchment.upscale(var)
            elif needs_uparea_grid:
                catchment.get_facc()

            if needs_basin and catchment.basin is None:
                catchment.get_basins()

            if needs_grdare:
                catchment.get_grid_area()
            elif needs_upgrid:
                catchment.get_upstream_area()

        has_shape_gauges = shape_folder is not None and gauge_ids is not None
        if (
            gauge_coords is None
            and not has_shape_gauges
            and is_data_global(input_ds, coordinate_slices)
        ):
            logger.info("Creating global basin id file...")
            if "basin" in output_vars:
                temp_file1 = "hydro1.nc"
                global_catchments = Catchment(
                    ds=input_ds,
                    var_name=var_name,
                    var=var,
                    ftype=ftype,
                    transform=transform,
                    latlon=latlon,
                    out_var_name=temp_file1,
                    do_shift=False,
                    resolutions=resolutions,
                    upscale=upscale,
                )
                # create a shifted version of the catchment to avoid border effects
                temp_file2 = "hydro2.nc"
                global_catchments_shifted = Catchment(
                    ds=input_ds,
                    var_name=var_name,
                    var=var,
                    ftype=ftype,
                    transform=transform,
                    latlon=latlon,
                    out_var_name=temp_file2,
                    do_shift=True,
                    resolutions=resolutions,
                    upscale=upscale,
                )
                catchments = [global_catchments, global_catchments_shifted]

                for c in catchments:
                    _compute_requested_outputs(c)
                    # no frame: it would set the basins of the first and last
                    # longitude column to 0 in both files, so the date line
                    # merge could not restore them
                    c.write(
                        output_path,
                        single_file=True,
                        frame=0,
                        mask_file=mask_file,
                        variables=output_vars,
                        id_gauges_out_path=id_gauges_out_path,
                    )
                # add paths to the temp files
                temp_file1 = Path(output_path, "hydro1.nc")
                temp_file2 = Path(output_path, "hydro2.nc")
                logger.info("Merging catchment files")
                merge_catchment(
                    temp_file1,
                    temp_file2,
                    Path(output_path, "basin_ids.nc"),
                )
                # remove the temporary files
                temp_file1.unlink()
                temp_file2.unlink()
            else:
                global_catchments = Catchment(
                    ds=input_ds,
                    var_name=var_name,
                    var=var,
                    ftype=ftype,
                    transform=transform,
                    latlon=latlon,
                    out_var_name="basin_ids.nc",
                    do_shift=False,
                    resolutions=resolutions,
                    upscale=upscale,
                )
                _compute_requested_outputs(global_catchments)
                global_catchments.write(
                    output_path,
                    single_file=True,
                    frame=frame,
                    mask_file=mask_file,
                    variables=output_vars,
                    id_gauges_out_path=id_gauges_out_path,
                )
            return
        input_ds_sliced = input_ds.sel(
            lat=coordinate_slices["lat"], lon=coordinate_slices["lon"]
        )
        logger.info("Cropped input dataset:")
        logger.info(
            f"        lat {input_ds_sliced.lat.data[0]}, {input_ds_sliced.lat.data[-1]}"
        )
        logger.info(
            f"        lon {input_ds_sliced.lon.data[0]}, {input_ds_sliced.lon.data[-1]}"
        )
        sliced_transform = get_transformation_matrix_nc(input_ds_sliced, var_name)
        # the sides where the crop cuts the input; a basin reaching the edge of
        # the input itself gains nothing from a larger crop
        crop_edge_sides = [
            side
            for side, sliced_value, input_value in (
                ("north", input_ds_sliced.lat.data[0], input_ds.lat.data[0]),
                ("south", input_ds_sliced.lat.data[-1], input_ds.lat.data[-1]),
                ("west", input_ds_sliced.lon.data[0], input_ds.lon.data[0]),
                ("east", input_ds_sliced.lon.data[-1], input_ds.lon.data[-1]),
            )
            if sliced_value != input_value
        ]
        # only an automatic crop that does not cover the whole input yet is enlarged
        can_enlarge_crop = (
            bounds is not None and crop_retries_left > 0 and bool(crop_edge_sides)
        )

        def _raise_crop_too_small(gauge_ids_cut):
            """Raise _CropTooSmallError with the crop scaled by CROP_GROWTH_FACTOR.

            Args:
                gauge_ids_cut (list): Ids of the gauges whose basin the crop cuts off.

            Raises
            ------
                _CropTooSmallError: Always, to rerun after the input is closed.
            """
            raise _CropTooSmallError(
                gauge_ids_cut,
                _scale_bounds(bounds, CROP_GROWTH_FACTOR),
                crop_retries_left - 1,
            )

        single_shape_gauge = (
            gauge_coords is None
            and shape_folder is not None
            and gauge_ids is not None
            and not isinstance(gauge_ids, list)
        )
        if (
            gauge_coords is not None and isinstance(gauge_coords, tuple)
        ) or single_shape_gauge:
            logger.info(f"Creating catchment for gauge coordinates {gauge_coords}")
            c = Catchment(
                ds=input_ds_sliced,
                var_name=var_name,
                var=var,
                ftype=ftype,
                transform=sliced_transform,
                latlon=latlon,
                out_var_name="basin_ids.nc",
                do_shift=False,
                resolutions=resolutions,
                upscale=upscale,
            )
            c.crop_edge_sides = crop_edge_sides
            single_ref_area = (
                ref_catchment_area[0]
                if isinstance(ref_catchment_area, list) and ref_catchment_area
                else ref_catchment_area
            )
            gauge = Gauge(
                gauge_id=gauge_ids if not isinstance(gauge_ids, list) else gauge_ids[0],
                lat=gauge_coords[0] if gauge_coords is not None else None,
                lon=gauge_coords[1] if gauge_coords is not None else None,
                area=single_ref_area,
            )
            try:
                gauge = c.delineate_basin(
                    gauge,
                    max_distance_cells=max_distance_cells,
                    max_distance_m=max_distance_m,
                    max_error=max_error,
                    use_max_error=use_max_error,
                    gauge_opti_method=gauge_opti_method,
                    shape_folder=shape_folder,
                    raise_on_fallback=raise_on_fallback,
                )
            except ValueError:
                # a basin cut off by the crop can fail the outlet search or the
                # area sanity check, so retry it with a larger crop
                cut_by_crop = (
                    c.touches_crop_edge
                    or c.check_candidate_basins_reach_crop_edge(
                        gauge_coords, max_distance_cells, max_distance_m
                    )
                )
                if not (cut_by_crop and can_enlarge_crop):
                    raise
                _raise_crop_too_small([gauge.gauge_id])
            if c.touches_crop_edge and can_enlarge_crop:
                _raise_crop_too_small([gauge.gauge_id])
            if c.touches_domain_edge:
                logger.warning(
                    f"Basin of gauge {gauge.gauge_id} reaches the edge of the domain "
                    "and may be cut off."
                )
            l0_shape_gdf = None
            if upscale and c.catchment_mask is not None:
                # the plain name keeps the L1 gauges written after the upscaling
                write_gauges_out(
                    gauge, id_gauges_out_path / f"{Path(gauge_info_file).stem}_l0"
                )
                try:
                    l0_shape_gdf = _vectorize_mask_to_gdf(
                        c.catchment_mask,
                        c.transform,
                        _shape_crs(c.latlon),
                        value_name="basin",
                    )
                except Exception as exc:
                    logger.warning(f"Could not build L0 basin shape: {exc}")
            else:
                write_gauges_out(gauge, id_gauges_out_path / gauge_info_file)
            c.write_basin_shape(
                output_path / "shapes",
                gauge_id=gauge_ids if not isinstance(gauge_ids, list) else gauge_ids[0],
            )

            _compute_requested_outputs(c)
            if upscale and c.is_upscaled and l0_shape_gdf is not None and c.gauge_lats:
                logger.info("Applying L1 correction using L0 basin shape.")
                new_coords = c.correct_gauge_location_l1_from_shape(
                    l0_shape_gdf,
                    (c.gauge_lats[-1], c.gauge_lons[-1]),
                    max_distance_cells=max_distance_cells,
                    max_distance_m=max_distance_m,
                    max_error=max_error,
                    use_max_error=use_max_error,
                    ref_catchment_area=ref_catchment_area,
                )
                if new_coords is not None:
                    c.update_gauge_coords(
                        gauge_ids if not isinstance(gauge_ids, list) else gauge_ids[0],
                        new_coords[0],
                        new_coords[1],
                    )
                    gauge.update(lat=new_coords[0], lon=new_coords[1])
                write_gauges_out(gauge, id_gauges_out_path / gauge_info_file)
            c.write(
                output_path,
                single_file=True,
                cut_by_basin=True,
                mask_file=mask_file,
                frame=frame,
                buffer=frame,
                variables=output_vars,
                id_gauges_out_path=id_gauges_out_path,
            )
            return
        logger.info("Creating basin id file for region.")

        c = Catchment(
            ds=input_ds_sliced,
            var_name=var_name,
            var=var,
            ftype=ftype,
            transform=sliced_transform,
            latlon=latlon,
            out_var_name="basin_ids.nc",
            do_shift=False,
            resolutions=resolutions,
            upscale=upscale,
        )
        c.crop_edge_sides = crop_edge_sides
        gauge_infos = None
        gauges = []
        shape_only_multi_gauges = (
            gauge_coords is None
            and shape_folder is not None
            and isinstance(gauge_ids, list)
        )
        if (
            _is_list_of_float_tuples(gauge_coords)
            and isinstance(gauge_ids, list)
            and len(gauge_coords) == len(gauge_ids)
        ) or shape_only_multi_gauges:
            logger.info(f"Creating catchments for gauge coordinates {gauge_coords}")
            upstream_area = c.calc_upstream_area()

            lon = get_coord_values(input_ds_sliced, lon=True)
            lat = get_coord_values(input_ds_sliced, lat=True)

            def _process_gauge(i, gc, lon, lat):
                ref_area = (
                    ref_catchment_area[i]
                    if isinstance(ref_catchment_area, list)
                    else ref_catchment_area
                )
                if gc is not None and not (
                    lon.min() <= gc[1] <= lon.max() and lat.min() <= gc[0] <= lat.max()
                ):
                    logger.warning(
                        f"Gauge coordinate {gc} is outside the domain lon: [{lon.min()}, {lon.max()}], lat: [{lat.min()}, {lat.max()}]"
                    )
                    if shape_folder is None:
                        return None
                    gc = None
                gauge_max_distance_m = (
                    auto_max_distances_m[i] if auto_max_distances_m else max_distance_m
                )

                try:
                    (
                        outlet_idx,
                        error,
                        gauge_lat,
                        gauge_lon,
                        distance_error,
                        score,
                        shape_error,
                        used_method,
                    ) = c.get_best_gauge_coordinate(
                        upstream_area=upstream_area,
                        gauge_coords=gc,
                        ref_catchment_area=ref_area,
                        max_distance_cells=max_distance_cells,
                        max_distance_m=gauge_max_distance_m,
                        max_error=max_error,
                        use_max_error=use_max_error,
                        method=gauge_opti_method,
                        shape_folder=shape_folder,
                        gauge_id=gauge_ids[i],
                        raise_on_fallback=raise_on_fallback,
                    )
                except ValueError as exc:
                    if can_enlarge_crop and c.check_candidate_basins_reach_crop_edge(
                        gc, max_distance_cells, gauge_max_distance_m
                    ):
                        return {"gauge_id": gauge_ids[i], "cut_by_crop": True}
                    # an unmatched gauge is dropped like one outside the domain,
                    # so it does not abort the delineation of all other gauges
                    logger.warning(f"Dropping gauge {gauge_ids[i]}: {exc}")
                    return None
                return {
                    "gauge_id": gauge_ids[i],
                    "gauge_lat": gauge_lat,
                    "gauge_lon": gauge_lon,
                    "lat_old": gc[0] if gc is not None else np.nan,
                    "lon_old": gc[1] if gc is not None else np.nan,
                    "area_old": ref_area,
                    "outlet_idx": outlet_idx,
                    "error": error,
                    "distance_error": distance_error,
                    "score": score,
                    "shape_error": shape_error,
                    "method": used_method,
                    "ref_area": ref_area,
                    "max_distance_m": gauge_max_distance_m,
                }

            gauge_infos = Parallel(n_jobs=ncpus, prefer="threads")(
                delayed(_process_gauge)(
                    i,
                    None if gauge_coords is None else gc,
                    lon,
                    lat,
                )
                for i, gc in enumerate(
                    gauge_ids if gauge_coords is None else gauge_coords
                )
            )

            gauge_infos = [gi for gi in gauge_infos if gi is not None]
            gauge_ids_cut = [
                gi["gauge_id"] for gi in gauge_infos if gi.get("cut_by_crop")
            ]
            if gauge_ids_cut:
                _raise_crop_too_small(gauge_ids_cut)
            if not gauge_infos:
                logger.warning("No valid gauge coordinates found inside domain.")
            else:
                logger.info(
                    f"Found {len(gauge_infos)} valid gauge coordinates inside domain."
                )
                shape_dir = Path(output_path) / "shapes"
                outlet_idxs = [gi["outlet_idx"] for gi in gauge_infos]
                outlet_linear = np.array(
                    [np.ravel_multi_index(idx, c._fdir.shape) for idx in outlet_idxs],
                    dtype=np.int64,
                )
                # combine all river masks
                streams_mask = None
                logger.info("Delineating basins for all gauges.")
                # if streams_mask is None or not np.any(streams_mask):
                # logger.warning("No river mask found for any gauge.")
                # streams_mask = np.asarray(c._fdir.stream_order() >= 4, dtype=bool)
                try:
                    basins = c._fdir.basins(
                        idxs=outlet_linear,
                        streams=streams_mask,
                    )
                except Exception as exc:
                    logger.exception(f"pyflwdir.basins(idxs=...) failed: {exc}")
                    with ErrorLogger(logger):
                        raise exc
                crop_edge_basin_ids = set(
                    _get_domain_edge_values(basins, crop_edge_sides).tolist()
                ) - {0}
                gauge_ids_at_crop_edge = [
                    gi["gauge_id"]
                    for gi in gauge_infos
                    if int(basins[gi["outlet_idx"]]) in crop_edge_basin_ids
                ]
                if gauge_ids_at_crop_edge and can_enlarge_crop:
                    _raise_crop_too_small(gauge_ids_at_crop_edge)
                edge_basin_ids = set(_get_domain_edge_values(basins).tolist()) - {0}
                gauge_ids_at_edge = [
                    gi["gauge_id"]
                    for gi in gauge_infos
                    if int(basins[gi["outlet_idx"]]) in edge_basin_ids
                ]
                if gauge_ids_at_edge:
                    logger.warning(
                        f"Basins of gauges {gauge_ids_at_edge} reach the edge of the "
                        "domain and may be cut off."
                    )
                logger.info("Performing sanity checks for all delineated basins.")
                gauges = []
                for gi in gauge_infos:
                    outlet_idx = gi["outlet_idx"]
                    basin_id = int(basins[outlet_idx])
                    if basin_id == 0:
                        logger.warning(
                            f"No basin id found for gauge_id {gi['gauge_id']} at "
                            f"outlet {outlet_idx}"
                        )
                        continue
                    catchment_mask = basins == basin_id
                    uparea_at_outlet = (
                        upstream_area[outlet_idx]
                        if upstream_area is not None
                        else np.nan
                    )
                    failed = c.delineation_sanity_check(
                        catchment_mask,
                        basins,
                        uparea_at_outlet,
                        gi["ref_area"],
                        max_error,
                        False,
                        gi["gauge_id"],
                        use_max_error=use_max_error,
                    )
                    if failed:
                        continue
                    if upscale:
                        try:
                            gi["l0_shape_gdf"] = _vectorize_mask_to_gdf(
                                catchment_mask,
                                c.transform,
                                _shape_crs(c.latlon),
                                value_name="basin",
                            )
                        except Exception as exc:
                            logger.warning(
                                f"Could not build L0 basin shape for gauge "
                                f"{gi['gauge_id']}: {exc}"
                            )
                            gi["l0_shape_gdf"] = None
                    c.save_coords(gi["gauge_id"], gi["gauge_lat"], gi["gauge_lon"])
                    gauge = Gauge(
                        gauge_id=gi["gauge_id"],
                        lat=gi["lat_old"],
                        lon=gi["lon_old"],
                        area=gi["area_old"],
                    )
                    gauge.update(
                        lat=gi["gauge_lat"],
                        lon=gi["gauge_lon"],
                        area=uparea_at_outlet,
                        distance_error=gi["distance_error"],
                        area_error=gi["error"],
                        score=gi["score"],
                        shape_error=gi["shape_error"],
                        method=gi["method"],
                    )
                    gauges.append(gauge)
                    c.write_basin_shape(
                        shape_dir,
                        gauge_id=gi["gauge_id"],
                        basin_mask=catchment_mask,
                    )
                if upscale:
                    # the plain name keeps the L1 gauges written after the upscaling
                    write_gauges_out(
                        gauges,
                        id_gauges_out_path / f"{Path(gauge_info_file).stem}_l0",
                    )
                else:
                    write_gauges_out(gauges, id_gauges_out_path / gauge_info_file)

        _compute_requested_outputs(c)
        if upscale and c.is_upscaled and gauges:
            logger.info(f"Applying L1 correction for {len(gauge_infos)} gauges.")
            for gauge in gauges:
                gi = next(
                    (
                        item
                        for item in gauge_infos
                        if item["gauge_id"] == gauge.gauge_id
                    ),
                    None,
                )
                if gi is None:
                    continue
                l0_shape_gdf = gi.get("l0_shape_gdf")
                if l0_shape_gdf is None:
                    continue
                new_coords = c.correct_gauge_location_l1_from_shape(
                    l0_shape_gdf,
                    (gauge.lat, gauge.lon),
                    max_distance_cells=max_distance_cells,
                    max_distance_m=gi["max_distance_m"],
                    max_error=max_error,
                    use_max_error=use_max_error,
                    ref_catchment_area=gi.get("ref_area"),
                )
                if new_coords is not None:
                    c.update_gauge_coords(
                        gi["gauge_id"],
                        new_coords[0],
                        new_coords[1],
                    )
                    gauge.update(lat=new_coords[0], lon=new_coords[1])
            write_gauges_out(gauges, id_gauges_out_path / gauge_info_file)
        c.write(
            output_path,
            single_file=True,
            mask_file=mask_file,
            frame=frame,
            variables=output_vars,
            id_gauges_out_path=id_gauges_out_path,
        )
    return
